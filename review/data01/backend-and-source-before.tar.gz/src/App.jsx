import ExperienceContext from "@/components/systemHealth/ExperienceContext";
import './App.css'
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import VisualEditAgent from '@/lib/VisualEditAgent'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AccountSuspendedScreen from '@/components/AccountSuspendedScreen';
import AccountNotActivatedScreen from '@/components/AccountNotActivatedScreen';
import AccountExpiredScreen from '@/components/AccountExpiredScreen';
import AdminAccounts from './pages/AdminAccounts';
import AdminAccountAccess from './pages/AdminAccountAccess';
import AccountDashboard from './pages/AccountDashboard';
import AdminDashboard from './pages/AdminDashboard';
import AdminCommercialIntelligence from './pages/AdminCommercialIntelligence';
import AdminSystemHealth from './pages/AdminSystemHealth';
import AdminPlaceholderPage from './pages/AdminPlaceholderPage';
import AdminPublicationContent from './pages/AdminPublicationContent';
import AdminProposalDiagnostics from './pages/AdminProposalDiagnostics';
import AdminAdiDesignKnowledge from './pages/AdminAdiDesignKnowledge';
import AdminDesignIntentPreview from './pages/AdminDesignIntentPreview';
import AdminDatasetManager from './pages/AdminDatasetManager';
import AdminProjectLicensing from './pages/AdminProjectLicensing';
import AdminProjectIntelligence from './pages/AdminProjectIntelligence';
import AdminDesignIntelligence from './pages/AdminDesignIntelligence';
import AdminUserLicensingDetail from './pages/AdminUserLicensingDetail';
import AdminRicherSounds from './pages/AdminRicherSounds';
import AdminSpeakerDatabase from './pages/AdminSpeakerDatabase';
import AdminSpeakerProductDetail from './pages/AdminSpeakerProductDetail';
import AdminAddSpeaker from './pages/AdminAddSpeaker';
import AdminModelFirstSpeaker from './pages/AdminModelFirstSpeaker';
import AdminSpeakerLibraryUpdate from './pages/AdminSpeakerLibraryUpdate';
import AdminSpeakerPublicationReconciliation from './pages/AdminSpeakerPublicationReconciliation';
import RP22ClientReport from './pages/RP22ClientReport';
import DesignReviewPage from './pages/DesignReviewPage';
import ProposalCentre from './pages/ProposalCentre';
import ProjectProposalAssets from './pages/ProjectProposalAssets';
import ProposalEditor from './pages/ProposalEditor';
import ProposalDirectLink from '@/components/proposal/ProposalDirectLink';
import PurchaseProjects from './pages/PurchaseProjects';
import PriceList from './pages/PriceList';
import AccountUsers from './pages/AccountUsers';
import AboutSoundProof from './pages/AboutSoundProof';
import DealerBranding from './pages/DealerBranding';
import AccessGate from '@/components/AccessGate';
import AccessDeniedScreen from '@/components/AccessDeniedScreen';
import AdminOnlyRoute from '@/components/AdminOnlyRoute';
import { defaultPathForUser } from '@/lib/accountAccess';
import ProjectHydrationProvider from '@/components/state/ProjectHydrationProvider';
import ProjectGate from '@/components/state/ProjectGate';

// Pages that render saved project design state. They are gated on the canonical
// project hydration state, so placeholder or previous-project data can never be
// displayed as the current project.
const DESIGN_DEPENDENT_PAGES = new Set(['RoomDesigner', 'RP22Report']);

const withProjectGate = (path, Page) => (
  DESIGN_DEPENDENT_PAGES.has(path)
    ? <ProjectGate><Page /></ProjectGate>
    : <Page />
);

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AccessHome = () => {
  const { user } = useAuth();
  return <Navigate replace to={defaultPathForUser(user)} />;
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, isAuthenticated, navigateToLogin, checkAppState } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'account_suspended') {
      return <AccountSuspendedScreen />;
    } else if (authError.type === 'account_not_activated') {
      return <AccountNotActivatedScreen />;
    } else if (authError.type === 'account_expired') {
      return <AccountExpiredScreen />;
    } else if (authError.type === 'access_denied') {
      return (
        <AccessDeniedScreen
          title="Account access not available"
          message={authError.message}
          reason={authError.reason}
          identity={authError.identity}
          onRetry={authError.retryable ? checkAppState : null}
          correlationId={authError.correlationId}
        />
      );
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    } else {
      return (
        <AccessDeniedScreen
          title="Sound Proof could not verify this login"
          onRetry={authError.retryable ? checkAppState : null}
          correlationId={authError.correlationId}
          message={authError.message || 'Please try again or contact your account administrator.'}
        />
      );
    }
  }

  if (!isAuthenticated) {
    navigateToLogin();
    return null;
  }

  return (
    <LayoutWrapper currentPageName={mainPageKey}>
      <Routes>
        <Route path="/" element={<AccessHome />} />
        {Object.entries(Pages)
          .filter(([path]) => path !== "SPLCalculator" && path !== "SPLCalculatorV2")
          .map(([path, Page]) => (
            <Route
              key={path}
              path={`/${path}`}
              element={<AccessGate capability="soundProof">{withProjectGate(path, Page)}</AccessGate>}
            />
          ))}
        <Route path="/SPLCalculator" element={<AccessGate capability="soundProof"><Pages.SPLCalculator /></AccessGate>} />
        <Route path="/SPLCalculatorV2" element={<AdminOnlyRoute redirectTo="/Projects"><Pages.SPLCalculatorV2 /></AdminOnlyRoute>} />
        <Route path="/RP22ClientReport" element={<AccessGate capability="soundProof"><ProjectGate><RP22ClientReport /></ProjectGate></AccessGate>} />
        <Route path="/DesignReview" element={<AccessGate capability="soundProof"><ProjectGate><DesignReviewPage /></ProjectGate></AccessGate>} />
        <Route path="/ProposalCentre" element={<AccessGate capability="soundProof"><ProposalCentre /></AccessGate>} />
        <Route path="/ProjectProposalAssets" element={<AccessGate capability="soundProof"><ProjectGate requiresDesign={false}><ProjectProposalAssets /></ProjectGate></AccessGate>} />
        <Route path="/ProposalEditor" element={<AccessGate capability="soundProof"><ProposalEditor /></AccessGate>} />
        <Route path="/proposal/:proposalId" element={<AccessGate capability="soundProof"><ProposalDirectLink /></AccessGate>} />
        <Route path="/PurchaseProjects" element={<AccessGate capability="commercial"><PurchaseProjects /></AccessGate>} />
        <Route path="/PriceList" element={<AccessGate capability="priceList"><PriceList /></AccessGate>} />
        <Route path="/account/users" element={<AccessGate capability="manageUsers"><AccountUsers /></AccessGate>} />
        <Route path="/AboutSoundProof" element={<AboutSoundProof />} />
        <Route path="/DealerBranding" element={<AccessGate capability="soundProof"><DealerBranding /></AccessGate>} />
        <Route path="/admin" element={<AccessGate masterAdmin><AdminDashboard /></AccessGate>} />
        <Route path="/admin/commercial-intelligence" element={<AccessGate masterAdmin><AdminCommercialIntelligence /></AccessGate>} />
        <Route path="/admin/design-intelligence" element={<AccessGate masterAdmin><AdminDesignIntelligence /></AccessGate>} />
        <Route path="/admin/accounts" element={<AccessGate masterAdmin><AdminAccounts /></AccessGate>} />
        <Route path="/admin/richer-sounds" element={<AccessGate masterAdmin capability="richerSoundsAdmin"><AdminRicherSounds /></AccessGate>} />
        <Route path="/admin/accounts/:accountId" element={<AccessGate masterAdmin><AccountDashboard /></AccessGate>} />
        <Route path="/admin/access" element={<AccessGate masterAdmin><AdminAccountAccess /></AccessGate>} />
        <Route path="/admin/system-health" element={<AccessGate masterAdmin><AdminSystemHealth /></AccessGate>} />
        <Route path="/admin/datasets" element={<AccessGate masterAdmin><AdminDatasetManager /></AccessGate>} />
        <Route path="/admin/project-licensing" element={<AccessGate masterAdmin><AdminProjectLicensing /></AccessGate>} />
        <Route path="/admin/project-licensing/:userId" element={<AccessGate masterAdmin><AdminUserLicensingDetail /></AccessGate>} />
        <Route path="/admin/project-intelligence" element={<AccessGate masterAdmin><AdminProjectIntelligence /></AccessGate>} />
        <Route path="/admin/pricing" element={<AccessGate masterAdmin><AdminPlaceholderPage title="Pricing" description="Price lists, discounts and difficulty multipliers." /></AccessGate>} />
        <Route path="/admin/product-prices" element={<AccessGate masterAdmin><Navigate to="/PriceList" replace /></AccessGate>} />
        <Route path="/admin/rp22-config" element={<AccessGate masterAdmin><AdminPlaceholderPage title="RP22 Configuration" description="Compliance parameters and grading thresholds." /></AccessGate>} />
        <Route path="/admin/content" element={<AccessGate masterAdmin><AdminPublicationContent /></AccessGate>} />
        <Route path="/admin/proposal-diagnostics" element={<AccessGate masterAdmin><AdminProposalDiagnostics /></AccessGate>} />
        <Route path="/admin/adi-design-knowledge" element={<AccessGate masterAdmin><AdminAdiDesignKnowledge /></AccessGate>} />
        <Route path="/admin/design-intent-preview" element={<AccessGate masterAdmin><AdminDesignIntentPreview /></AccessGate>} />
        <Route path="/admin/speaker-database" element={<AccessGate masterAdmin><Navigate to="/SPLCalculator" replace /></AccessGate>} />
        <Route path="/admin/speaker-database/advanced" element={<AccessGate masterAdmin><AdminSpeakerDatabase /></AccessGate>} />
        <Route path="/admin/speaker-database/product/:productId" element={<AccessGate masterAdmin><AdminSpeakerProductDetail /></AccessGate>} />
        <Route path="/admin/speaker-database/add-speaker" element={<AccessGate masterAdmin><AdminAddSpeaker /></AccessGate>} />
        <Route path="/admin/speaker-database/model-first" element={<AccessGate masterAdmin><AdminModelFirstSpeaker /></AccessGate>} />
        <Route path="/admin/speaker-library-update" element={<AccessGate masterAdmin><Navigate to="/SPLCalculator" replace /></AccessGate>} />
        <Route path="/admin/speaker-publication-reconciliation" element={<AccessGate masterAdmin><AdminSpeakerPublicationReconciliation /></AccessGate>} />
        <Route path="/admin/audit-log" element={<AccessGate masterAdmin><AdminPlaceholderPage title="Audit Log" description="Track changes made across the platform." /></AccessGate>} />
        <Route path="/admin/billing" element={<AccessGate masterAdmin><AdminPlaceholderPage title="Billing" description="Subscription plans and payment configuration." /></AccessGate>} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </LayoutWrapper>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <ExperienceContext />
          <ProjectHydrationProvider>
            <AuthenticatedApp />
          </ProjectHydrationProvider>
        </Router>
        <Toaster />
        <VisualEditAgent />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App