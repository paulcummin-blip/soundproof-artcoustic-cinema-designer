import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Canonical seed dataset — mirrors the current runtime price constants exactly:
//   FIXED_RETAIL_PRICES_EX_VAT  (usePriceCalculation.jsx:10-38)
//   SOUNDBAR_PRICE_OPTIONS     (usePriceCalculation.jsx:40-73)
//   CPH_1000D_PRICE_EX_VAT     (usePriceCalculation.jsx:8)
// Product Master migration source.
// Missing SKUs are created. Existing commercial fields (name, category, price,
// active state) are NEVER overwritten. Only absent Product Master linkage fields
// are backfilled, preserving every Admin decision.
const SEED_DATA = [
  // ── Fixed retail prices (LCR + surrounds + architect + center + subs + amp + abfuser) ──
  { sku: "q4-3",             label: "Q4-3",                     category: "Loudspeaker",        price_ex_vat: 1516.67 },
  { sku: "q4-3_s",           label: "Q4-3 (Surround)",         category: "Loudspeaker",        price_ex_vat: 1516.67 },
  { sku: "q6-3",             label: "Q6-3",                     category: "Loudspeaker",        price_ex_vat: 1741.67 },
  { sku: "q6-3_s",           label: "Q6-3 (Surround)",         category: "Loudspeaker",        price_ex_vat: 1741.67 },
  { sku: "q4-5",             label: "Q4-5",                     category: "Loudspeaker",        price_ex_vat: 3258.33 },
  { sku: "q4-5_s",           label: "Q4-5 (Surround)",         category: "Loudspeaker",        price_ex_vat: 3258.33 },
  { sku: "q8-5",             label: "Q8-5",                     category: "Loudspeaker",        price_ex_vat: 4775 },
  { sku: "q8-5_s",           label: "Q8-5 (Surround)",         category: "Loudspeaker",        price_ex_vat: 4775 },
  { sku: "evolve-2-1",       label: "EVOLVE 2-1",               category: "Loudspeaker",        price_ex_vat: 650 },
  { sku: "evolve-2-1_s",     label: "EVOLVE 2-1 (Surround)",   category: "Loudspeaker",        price_ex_vat: 650 },
  { sku: "evolve-3-1",       label: "EVOLVE 3-1",               category: "Loudspeaker",        price_ex_vat: 975 },
  { sku: "evolve-3-1_s",     label: "EVOLVE 3-1 (Surround)",   category: "Loudspeaker",        price_ex_vat: 975 },
  { sku: "evolve-4-2",       label: "EVOLVE 4-2",               category: "Loudspeaker",        price_ex_vat: 1483.33 },
  { sku: "evolve-4-2_s",     label: "EVOLVE 4-2 (Surround)",   category: "Loudspeaker",        price_ex_vat: 1483.33 },
  { sku: "evolve-6-3",       label: "EVOLVE 6-3",               category: "Loudspeaker",        price_ex_vat: 1875 },
  { sku: "evolve-6-3_s",     label: "EVOLVE 6-3 (Surround)",   category: "Loudspeaker",        price_ex_vat: 1875 },
  { sku: "evolve-8-4",       label: "EVOLVE 8-4",               category: "Loudspeaker",        price_ex_vat: 2266.67 },
  { sku: "evolve-8-4_s",     label: "EVOLVE 8-4 (Surround)",   category: "Loudspeaker",        price_ex_vat: 2266.67 },
  { sku: "architect-2-1",    label: "ARCHITECT 2-1",           category: "Loudspeaker",        price_ex_vat: 616.67 },
  { sku: "architect-4-2",    label: "ARCHITECT 4-2",           category: "Loudspeaker",        price_ex_vat: 1025 },
  { sku: "architect-pas2-2", label: "ARCHITECT PAS2-2",       category: "Loudspeaker",        price_ex_vat: 1000 },
  { sku: "c-1",              label: "C-1",                      category: "Loudspeaker",        price_ex_vat: 766.67 },
  { sku: "sub2-12",          label: "SUB2-12",                  category: "Subwoofer",          price_ex_vat: 1825 },
  { sku: "sub3-12",          label: "SUB3-12",                  category: "Subwoofer",          price_ex_vat: 3116.67 },
  { sku: "sub4-12",          label: "SUB4-12",                  category: "Subwoofer",          price_ex_vat: 5500 },
  { sku: "cph-1000d",        label: "CPH-1000D",                category: "Amplifier",          price_ex_vat: 675 },
  { sku: "500027",           label: "Artcoustic Abfuser, Black", category: "Acoustic Treatment", price_ex_vat: 466.67 },

  // ── Soundbar size variants (composite key model:value, matching getCommercialPrice lineKey) ──
  { sku: "c4-1:1222",           label: "C4-1 — 1222mm",            category: "Loudspeaker", price_ex_vat: 1616.67 },
  { sku: "c4-1:1441",           label: "C4-1 — 1441mm",            category: "Loudspeaker", price_ex_vat: 1733.33 },
  { sku: "c4-1:1711",           label: "C4-1 — 1711mm",            category: "Loudspeaker", price_ex_vat: 1825 },
  { sku: "c4-1:1842",           label: "C4-1 — 1842mm",            category: "Loudspeaker", price_ex_vat: 1991.67 },
  // 1094 mm Multi variant — valid cabinet size, selectable in designs, but its
  // commercial price is pending: price_ex_vat stays null until entered, so it is
  // never included in a priced quotation and is shown as "price not set".
  { sku: "multi-lcr:1094-xs",   label: "Multi (LCR) — 1094 XS (price pending)",  category: "Loudspeaker", price_ex_vat: null },
  { sku: "multi-lcr:1222-m",    label: "Multi (LCR) — 1222 M",     category: "Loudspeaker", price_ex_vat: 2383.33 },
  { sku: "multi-lcr:1441-l",    label: "Multi (LCR) — 1441 L",     category: "Loudspeaker", price_ex_vat: 2650 },
  { sku: "multi-lcr:1711-xl",   label: "Multi (LCR) — 1711 XL",   category: "Loudspeaker", price_ex_vat: 2866.67 },
  { sku: "multi-lcr:1842-xxl",  label: "Multi (LCR) — 1842 XXL",   category: "Loudspeaker", price_ex_vat: 3366.67 },
  { sku: "multi-lcr:2230-xxxl", label: "Multi (LCR) — 2230 XXXL",  category: "Loudspeaker", price_ex_vat: 4641.67 },
  { sku: "multi-mono:1094-xs",  label: "Multi (Mono) — 1094 XS (price pending)", category: "Loudspeaker", price_ex_vat: null },
  { sku: "multi-mono:1222-m",   label: "Multi (Mono) — 1222 M",   category: "Loudspeaker", price_ex_vat: 2383.33 },
  { sku: "multi-mono:1441-l",   label: "Multi (Mono) — 1441 L",   category: "Loudspeaker", price_ex_vat: 2650 },
  { sku: "multi-mono:1711-xl",  label: "Multi (Mono) — 1711 XL",   category: "Loudspeaker", price_ex_vat: 2866.67 },
  { sku: "multi-mono:1842-xxl", label: "Multi (Mono) — 1842 XXL",  category: "Loudspeaker", price_ex_vat: 3366.67 },
  { sku: "multi-mono:2230-xxxl", label: "Multi (Mono) — 2230 XXXL", category: "Loudspeaker", price_ex_vat: 4641.67 },
  { sku: "hspl-lcr:1669-1800",  label: "HSPL (LCR) — 1669–1800mm",  category: "Loudspeaker", price_ex_vat: 4141.67 },
  { sku: "hspl-lcr:1801-2000",  label: "HSPL (LCR) — 1801–2000mm",  category: "Loudspeaker", price_ex_vat: 4400 },
  { sku: "hspl-lcr:2001-2200",  label: "HSPL (LCR) — 2001–2200mm",  category: "Loudspeaker", price_ex_vat: 6150 },
  { sku: "hspl-lcr:2201-2600",  label: "HSPL (LCR) — 2201–2600mm",  category: "Loudspeaker", price_ex_vat: 6808.33 },
  { sku: "hspl-mono:1669-1800", label: "HSPL (Mono) — 1669–1800mm", category: "Loudspeaker", price_ex_vat: 4141.67 },
  { sku: "hspl-mono:1801-2000", label: "HSPL (Mono) — 1801–2000mm", category: "Loudspeaker", price_ex_vat: 4400 },
  { sku: "hspl-mono:2001-2200", label: "HSPL (Mono) — 2001–2200mm", category: "Loudspeaker", price_ex_vat: 6150 },
  { sku: "hspl-mono:2201-2600", label: "HSPL (Mono) — 2201–2600mm", category: "Loudspeaker", price_ex_vat: 6808.33 },

  // ── Selectable products with no current runtime price (price_ex_vat = null) ──
  // These are selectable in the app but have no entry in the runtime price constants.
  // Seeded as null so Admin can identify and set a price via the Admin Product Prices page.
  { sku: "architect-mikro",   label: "MIKRO Ci",              category: "Loudspeaker", price_ex_vat: null },
  // Standalone MIKRO is deliberately seeded without a selector role.
  // Admin chooses its tested application(s) in Product Master before it enters a design selector.
  { sku: "mikro",             label: "MIKRO",                 category: "Loudspeaker", price_ex_vat: null, roles: [] },
  { sku: "spitfire-cloud",    label: "SPITFIRE CLOUD",        category: "Loudspeaker", price_ex_vat: null },
  { sku: "architect-4-2-mk2", label: "ARCHITECT 4-2 mk II",   category: "Loudspeaker", price_ex_vat: null },
  { sku: "evolve-1-1_s",      label: "EVOLVE 1-1 (Surround)", category: "Loudspeaker", price_ex_vat: null },
  { sku: "sl-evolve-1-1",      label: "SL EVOLVE 1-1",            category: "Loudspeaker", price_ex_vat: 400 },
  { sku: "sl-evolve-1-1_s",    label: "SL EVOLVE 1-1 (Surround)", category: "Loudspeaker", price_ex_vat: 400 },
];

const SURROUND_ROLES = ['surround', 'rear_surround', 'front_wide'];
const SOUNDBAR_MODELS = new Set(['c-1', 'c4-1', 'multi-lcr', 'multi-mono', 'hspl-lcr', 'hspl-mono']);
const OVERHEAD_MODELS = new Set(['architect-mikro', 'architect-2-1', 'spitfire-cloud', 'architect-4-2-mk2']);

// Master display order — mirrors the registry DISPLAY_ORDER map so DB selector_order
// stays consistent with the engineering catalogue's single source of truth.
const DISPLAY_ORDER: Record<string, number> = {
  'q4-3': 1, 'q4-3_s': 1,
  'q6-3': 2, 'q6-3_s': 2,
  'q4-5': 3, 'q4-5_s': 3,
  'q8-5': 4, 'q8-5_s': 4,
  'mikro': 5,
  'evolve-1': 6,
  'evolve-1-1': 7, 'evolve-1-1_s': 7,
  'sl-evolve-1-1': 7, 'sl-evolve-1-1_s': 7,
  'evolve-2-1': 8, 'evolve-2-1_s': 8,
  'evolve-3-1': 9, 'evolve-3-1_s': 9,
  'evolve-4-2': 10, 'evolve-4-2_s': 10,
  'evolve-6-3': 11, 'evolve-6-3_s': 11,
  'evolve-8-4': 12, 'evolve-8-4_s': 12,
  'architect-mikro': 13,
  'architect-2-1': 14,
  'architect-4-2-mk2': 15,
  'spitfire-cloud': 16,
  'c-1': 20,
  'c4-1': 21,
  'multi-lcr': 22,
  'multi-mono': 23,
  'hspl-lcr': 24,
  'hspl-mono': 25,
  'sub2-12': 50,
  'sub3-12': 51,
  'sub4-12': 52,
  'architect-4-2': 100,
  'architect-pas2-2': 101,
};

function engineeringKey(sku) {
  const key = String(sku || '').split(':')[0];
  return key.endsWith('_s') ? key.slice(0, -2) : key;
}

function defaultRoles(seed) {
  if (Array.isArray(seed.roles)) return [...new Set(seed.roles)];
  const key = String(seed.sku || '').split(':')[0];
  const linkedKey = engineeringKey(seed.sku);
  if (seed.category === 'Subwoofer') return ['subwoofer'];
  if (key.endsWith('_s')) return SURROUND_ROLES;
  if (SOUNDBAR_MODELS.has(linkedKey)) return ['centre_soundbar'];
  if (OVERHEAD_MODELS.has(linkedKey)) return ['overhead'];
  if (seed.category === 'Loudspeaker') {
    // Legacy ARCHITECT 4-2 and PAS2-2 were deliberately hidden from selectors.
    if (linkedKey === 'architect-4-2' || linkedKey === 'architect-pas2-2') return [];
    return ['lcr'];
  }
  return [];
}

function masterDefaults(seed, selectorOrder) {
  const acousticProduct = seed.category === 'Loudspeaker' || seed.category === 'Subwoofer';
  return {
    engineering_key: acousticProduct ? engineeringKey(seed.sku) : null,
    roles: defaultRoles(seed),
    selector_order: selectorOrder,
    catalog_version: 1,
    role_migration_version: 1,
  };
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden — admin only' }, { status: 403 });

    // Service-role: seed is an admin migration op, must bypass per-user RLS.
    const existing = await base44.asServiceRole.entities.ProductPrice.list('-created_date', 500);
    const existingBySku = new Map();
    for (const rec of existing) {
      if (rec.sku) existingBySku.set(rec.sku, rec);
    }

    let created = 0;
    let updated = 0;
    let unchanged = 0;
    const details = [];

    // ── One-time SKU correction: C4-1 1449 mm → 1441 mm ──────────────────────
    // The 1449 mm C4-1 cabinet was a catalogue typo for the verified 1441 mm
    // product (1441 × 120 × 81 mm). Rename the existing ProductPrice record in
    // place so the corrected SKU is the single C4-1 14xx entry — no duplicate
    // product is created and the existing retail price is preserved. A saved
    // project that explicitly recorded 1449 mm keeps drawing at 1449 mm (its
    // own recorded length is preserved by the variant authority); only the
    // commercial SKU identity is corrected.
    const C41_OLD_SKU = 'c4-1:1449';
    const C41_NEW_SKU = 'c4-1:1441';
    if (existingBySku.has(C41_OLD_SKU) && !existingBySku.has(C41_NEW_SKU)) {
      const oldRec = existingBySku.get(C41_OLD_SKU)!;
      await base44.asServiceRole.entities.ProductPrice.update(oldRec.id, {
        sku: C41_NEW_SKU,
        label: 'C4-1 — 1441mm',
      });
      existingBySku.delete(C41_OLD_SKU);
      existingBySku.set(C41_NEW_SKU, { ...oldRec, sku: C41_NEW_SKU, label: 'C4-1 — 1441mm' });
      updated++;
      details.push({ sku: C41_OLD_SKU, action: 'renamed_to', to: C41_NEW_SKU });
    }

    // ── One-time SKU correction: C4-1 1672 mm → 1711 mm ──────────────────────
    // The 1672 mm C4-1 cabinet was a catalogue typo for the verified 1711 mm
    // product (1711 × 120 × 81 mm, matching the tv77 preset width). Rename the
    // existing ProductPrice record in place so the corrected SKU is the single
    // C4-1 17xx entry — no duplicate product is created and the existing retail
    // price is preserved. A saved project that explicitly recorded 1672 mm keeps
    // drawing at 1672 mm (its own recorded length is preserved by the variant
    // authority); only the commercial SKU identity is corrected.
    const C41_1672_OLD_SKU = 'c4-1:1672';
    const C41_1672_NEW_SKU = 'c4-1:1711';
    if (existingBySku.has(C41_1672_OLD_SKU) && !existingBySku.has(C41_1672_NEW_SKU)) {
      const oldRec = existingBySku.get(C41_1672_OLD_SKU)!;
      await base44.asServiceRole.entities.ProductPrice.update(oldRec.id, {
        sku: C41_1672_NEW_SKU,
        label: 'C4-1 — 1711mm',
      });
      existingBySku.delete(C41_1672_OLD_SKU);
      existingBySku.set(C41_1672_NEW_SKU, { ...oldRec, sku: C41_1672_NEW_SKU, label: 'C4-1 — 1711mm' });
      updated++;
      details.push({ sku: C41_1672_OLD_SKU, action: 'renamed_to', to: C41_1672_NEW_SKU });
    }

    // ── One-time SKU correction: C4-1 1904 mm → 1842 mm ──────────────────────
    // The 1904 mm C4-1 cabinet was a catalogue typo for the verified 1842 mm
    // product (1842 × 120 × 81 mm, matching the Multi LCR/Mono 1842 mm length).
    // Rename the existing ProductPrice record in place so the corrected SKU is
    // the single C4-1 18xx entry — no duplicate product is created and the
    // existing retail price is preserved. A saved project that explicitly
    // recorded 1904 mm keeps drawing at 1904 mm (its own recorded length is
    // preserved by the variant authority); only the commercial SKU identity is
    // corrected.
    const C41_1904_OLD_SKU = 'c4-1:1904';
    const C41_1904_NEW_SKU = 'c4-1:1842';
    if (existingBySku.has(C41_1904_OLD_SKU) && !existingBySku.has(C41_1904_NEW_SKU)) {
      const oldRec = existingBySku.get(C41_1904_OLD_SKU)!;
      await base44.asServiceRole.entities.ProductPrice.update(oldRec.id, {
        sku: C41_1904_NEW_SKU,
        label: 'C4-1 — 1842mm',
      });
      existingBySku.delete(C41_1904_OLD_SKU);
      existingBySku.set(C41_1904_NEW_SKU, { ...oldRec, sku: C41_1904_NEW_SKU, label: 'C4-1 — 1842mm' });
      updated++;
      details.push({ sku: C41_1904_OLD_SKU, action: 'renamed_to', to: C41_1904_NEW_SKU });
    }

    for (let index = 0; index < SEED_DATA.length; index++) {
      const seed = SEED_DATA[index];
      const desiredOrder = DISPLAY_ORDER[seed.sku] ?? index;
      const defaults = masterDefaults(seed, desiredOrder);
      const existingRec = existingBySku.get(seed.sku);
      if (existingRec) {
        const patch = {};
        const needsRoleMigration = Number(existingRec.role_migration_version) !== 1;
        if (needsRoleMigration) {
          patch.engineering_key = existingRec.engineering_key || defaults.engineering_key;
          patch.roles = defaults.roles;
          patch.selector_order = Number.isFinite(Number(existingRec.selector_order))
            ? Number(existingRec.selector_order)
            : defaults.selector_order;
          patch.role_migration_version = 1;
        }
        // Sync selector_order to master display_order if drifted
        if (Number(existingRec.selector_order) !== desiredOrder) {
          patch.selector_order = desiredOrder;
        }
        if (!Number.isFinite(Number(existingRec.catalog_version))) patch.catalog_version = defaults.catalog_version;

        if (Object.keys(patch).length > 0) {
          await base44.asServiceRole.entities.ProductPrice.update(existingRec.id, patch);
          updated++;
          details.push({ sku: seed.sku, action: 'migrated', fields: Object.keys(patch) });
        } else {
          unchanged++;
          details.push({ sku: seed.sku, action: 'unchanged' });
        }
      } else {
        await base44.asServiceRole.entities.ProductPrice.create({
          sku: seed.sku,
          label: seed.label,
          category: seed.category,
          price_ex_vat: seed.price_ex_vat,
          active: true,
          ...defaults,
        });
        created++;
        details.push({ sku: seed.sku, action: 'created' });
      }
    }

    return Response.json({
      status: 'ok',
      seed_count: SEED_DATA.length,
      created,
      updated,
      unchanged,
      total_in_db: existing.length,
      details,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}