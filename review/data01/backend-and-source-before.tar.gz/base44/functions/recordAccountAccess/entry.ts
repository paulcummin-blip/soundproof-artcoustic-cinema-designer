import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { recordAuthIncident, safeAuthCorrelation, expectedAuthFailure } from '../../shared/systemHealth/authIncident.js';
import { resolveAccountAccess } from '../../shared/accountAccessAuthority.js';

/**
 * Records a successful Sound Proof access for the authenticated user.
 *
 * - Admin users: no-op (always retain access).
 * - No account_id: no-op (user not linked to an organisation).
 * - Account status "suspended": returns suspended — NO update, NO auto-reactivation.
 * - Account status "inactive": returns not_activated — NO update, NO auto-activation.
 *   An inactive account must NEVER be enabled by login. Only the
 *   manageSoundProofAccess backend function (called by an administrator) may
 *   set an account to active.
 * - Account status "active" but expired: returns expired — NO update.
 * - Account status "active" and not expired: updates last_access_at only.
 *
 * This function uses the service role to bypass Account RLS (only admins can
 * update Account records via the client SDK; dealer users cannot update their
 * own account).
 */
export default async function(req) {
  let base44, user, correlationId, stage='authenticated_session';
  try {
    base44 = createClientFromRequest(req);
    const body=await req.json().catch(()=>({}));
    correlationId=safeAuthCorrelation(body.correlation_id);
    user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const accessContext = await resolveAccountAccess(base44, user, {onStage:value=>{stage=value;}});

    // Master admin users bypass dealer account status checks entirely.
    if (accessContext.isMasterAdmin) {
      return Response.json({ status: 'ok', admin: true });
    }

    if (!accessContext.allowed) {
      if (accessContext.reason === 'ACCOUNT_SUSPENDED') {
        return Response.json({ status: 'suspended' });
      }
      if (accessContext.reason === 'ACCOUNT_NOT_ACTIVATED') {
        return Response.json({ status: 'not_activated' });
      }
      if (accessContext.reason === 'ACCOUNT_EXPIRED') {
        return Response.json({ status: 'expired' });
      }
      return Response.json({ status: 'forbidden' }, { status: 403 });
    }

    const accountId = accessContext.user?.account_id;
    if (!accountId) {
      return Response.json({ status: 'forbidden' }, { status: 403 });
    }

    // Fetch account via service role (bypasses RLS).
    const accounts = await base44.asServiceRole.entities.Account.filter({ id: accountId });
    const account = (accounts || [])[0];
    if (!account) {
      return Response.json({ status: 'ok', no_account: true });
    }

    stage='recordAccountAccess';
    const now = new Date().toISOString();

    // SUSPENDED — do NOT update, do NOT auto-reactivate.
    if (account.status === 'suspended') {
      return Response.json({ status: 'suspended' });
    }

    // INACTIVE — do NOT auto-activate. Only an administrator may enable.
    if (account.status === 'inactive') {
      return Response.json({ status: 'not_activated' });
    }

    // EXPIRED — account is active but the 90-day term has passed.
    // The authenticated Lovable renewal mechanism is now implemented
    // (portalSoundProofAccess with purpose "renew"), so expiry is enforced.
    // The dealer renews through the Partner Portal.
    if (
      account.status === 'active'
      && account.soundproof_access_expires_at
    ) {
      const expiresAtMs = new Date(account.soundproof_access_expires_at).getTime();
      if (Number.isFinite(expiresAtMs) && expiresAtMs < Date.now()) {
        return Response.json({ status: 'expired' });
      }
    }

    // ACTIVE — update last_access_at and record per-user successful login.
    if (account.status === 'active') {
      await base44.asServiceRole.entities.Account.update(accountId, {
        last_access_at: now,
      });

      // Per-user successful-login tracking for the Sound Proof Admin Dashboard.
      // Records each authorised dealer login as an append-only audit entry so
      // the admin can see each user's last login and 30-day usage count.
      try {
        await base44.asServiceRole.entities.AccountUserAudit.create({
          account_id: accountId,
          actor_user_id: String(user.id),
          actor_email: user.email || '',
          action: 'USER_LOGIN_RECORDED',
          target_email: user.email || '',
          occurred_at: now,
          details: { source: 'recordAccountAccess' },
        });
      } catch {
        // Non-blocking: login recording is diagnostic, not access-critical.
      }

      return Response.json({ status: 'active' });
    }

    // Any other status — record access without changing status.
    await base44.asServiceRole.entities.Account.update(accountId, {
      last_access_at: now,
    });
    return Response.json({ status: account.status || 'ok' });
  } catch (error) {
    const status=Number(error?.response?.status||error?.status||0);
    if(stage==='authenticated_session' && [401,403].includes(status)) return Response.json({error:'UNAUTHENTICATED'},{status:401});
    if(!expectedAuthFailure(error)) await recordAuthIncident(base44,{user,stage,correlationId,error,operation:'recordAccountAccess'});
    return Response.json({error:'ACCESS_RECORD_FAILED',correlation_id:correlationId},{status:500});
  }
}