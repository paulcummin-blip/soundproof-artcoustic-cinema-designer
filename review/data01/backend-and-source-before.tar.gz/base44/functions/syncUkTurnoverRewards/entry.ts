import { getCapacityLedgerEntries } from '../../shared/capacityAuthority.js';
import { acquireCreationLock, releaseCreationLock } from '../../shared/projectCreationLock.js';
import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { secrets } from "base44:runtime";
import {
  buildThresholdReconciliationPlan,
  validateEntitlementContract,
} from "../../shared/turnoverRewardReconciliationAuthority.js";

const SOURCE_SYSTEM = "ARTCOUSTIC_PARTNER_PORTAL";
const CONTRACT_VERSION = 1;
function summarizeError(error) {
  return String(error?.message || error || "Unknown error").slice(0, 500);
}

function latestMilestoneByThreshold(milestones) {
  const map = new Map();
  for (const milestone of Array.isArray(milestones) ? milestones : []) {
    const threshold = Number(milestone?.milestone_value_gbp);
    if (!Number.isFinite(threshold)) continue;
    const prior = map.get(threshold);
    if (!prior || String(milestone?.updated_date || milestone?.created_date || "")
      > String(prior?.updated_date || prior?.created_date || "")) {
      map.set(threshold, milestone);
    }
  }
  return map;
}

async function updateSyncRun(base44, syncRunId, data) {
  if (!syncRunId) return;
  await base44.asServiceRole.entities.TurnoverRewardSyncRun.update(syncRunId, data);
}

export default async function syncUkTurnoverRewards(req) {
  let base44;
  let syncRunId = null;

  try {
    base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    if (user.role !== "admin") {
      return Response.json({ error: "Forbidden — admin only" }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    if (body.bootstrap === true) {
      return Response.json({
        status: "BOOTSTRAP_DISABLED",
        message: "External entitlement sync never creates or links Sound Proof accounts.",
      }, { status: 400 });
    }

    const dryRun = body.dry_run === true;
    const calendarYear = Number(body.calendar_year) || new Date().getFullYear();
    if (!Number.isInteger(calendarYear) || calendarYear < 2020 || calendarYear > 2100) {
      return Response.json({ status: "INVALID_YEAR" }, { status: 400 });
    }

    const entitlementUrl = secrets.get("PARTNER_PORTAL_TURNOVER_URL");
    const bridgeKey = secrets.get("PARTNER_PORTAL_TURNOVER_API_KEY");
    if (!entitlementUrl || !bridgeKey) {
      return Response.json({
        status: "SECRETS_MISSING",
        message: "PARTNER_PORTAL_TURNOVER_URL and PARTNER_PORTAL_TURNOVER_API_KEY must be configured.",
        dry_run: dryRun,
      }, { status: 503 });
    }

    let validatedEntitlementUrl;
    try {
      const parsed = new URL(entitlementUrl);
      if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.hash) {
        throw new Error("invalid endpoint");
      }
      validatedEntitlementUrl = parsed.toString();
    } catch {
      return Response.json({
        status: "CONFIGURATION_INVALID",
        message: "PARTNER_PORTAL_TURNOVER_URL must be a valid HTTPS URL.",
        dry_run: dryRun,
      }, { status: 503 });
    }

    const startedAt = new Date().toISOString();
    const syncRun = await base44.asServiceRole.entities.TurnoverRewardSyncRun.create({
      started_at: startedAt,
      calendar_year: calendarYear,
      contract_version: CONTRACT_VERSION,
      status: dryRun ? "DRY_RUN" : "RUNNING",
      dry_run: dryRun,
      dealers_received: 0,
      dealers_matched: 0,
      dealers_unmatched: 0,
      dealers_updated: 0,
      dealers_reconciled: 0,
      milestones_awarded: 0,
      projects_awarded: 0,
      milestones_reversed: 0,
      projects_reversed: 0,
      milestones_reinstated: 0,
      projects_reinstated: 0,
      turnover_snapshots_appended: 0,
      discrepancy_count: 0,
      error_count: 0,
      error_summary: "",
    });
    syncRunId = syncRun.id;

    let rawContract;
    try {
      const response = await fetch(validatedEntitlementUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-sound-proof-api-key": bridgeKey,
        },
        body: JSON.stringify({ calendar_year: calendarYear }),
        signal: AbortSignal.timeout(15000),
      });
      if (!response.ok) throw new Error(`Entitlement endpoint HTTP ${response.status}`);
      rawContract = await response.json();
    } catch (error) {
      await updateSyncRun(base44, syncRunId, {
        status: "FAILED",
        finished_at: new Date().toISOString(),
        error_count: 1,
        error_summary: `Entitlement fetch failed: ${summarizeError(error)}`,
      });
      return Response.json({
        status: "ENTITLEMENT_FETCH_FAILED",
        sync_run_id: syncRunId,
      }, { status: 502 });
    }

    let contract;
    try {
      contract = validateEntitlementContract(rawContract, calendarYear);
    } catch (error) {
      await updateSyncRun(base44, syncRunId, {
        status: "FAILED",
        finished_at: new Date().toISOString(),
        error_count: 1,
        error_summary: `Contract rejected: ${summarizeError(error)}`,
      });
      return Response.json({
        status: "CONTRACT_REJECTED",
        sync_run_id: syncRunId,
      }, { status: 422 });
    }

    const [allLinks, allMilestones, existingTurnoverRecords] = await Promise.all([
      base44.asServiceRole.entities.ExternalAccountLink.filter({
        source_system: SOURCE_SYSTEM,
        active: true,
      }),
      base44.asServiceRole.entities.TurnoverMilestone.filter({
        calendar_year: calendarYear,
      }),
      base44.asServiceRole.entities.TurnoverRecord.filter({
        calendar_year: calendarYear,
      }),
    ]);

    const linksByDealerId = new Map();
    const linksByAccountId = new Map();
    for (const link of Array.isArray(allLinks) ? allLinks : []) {
      const dealerId = String(link?.partner_user_id || "").trim().toLowerCase();
      if (!dealerId) continue;
      const accountId = String(link?.account_id || "").trim();
      const priorDealerLink = linksByDealerId.get(dealerId);
      const priorAccountDealerId = linksByAccountId.get(accountId);
      if (priorDealerLink || (accountId && priorAccountDealerId && priorAccountDealerId !== dealerId)) {
        const message = priorDealerLink
          ? `Duplicate active stable dealer link: ${dealerId}`
          : `Sound Proof account ${accountId} has multiple active dealer identities`;
        await updateSyncRun(base44, syncRunId, {
          status: "FAILED",
          finished_at: new Date().toISOString(),
          error_count: 1,
          error_summary: message,
        });
        return Response.json({
          status: "DUPLICATE_ACCOUNT_LINK",
          sync_run_id: syncRunId,
        }, { status: 422 });
      }
      linksByDealerId.set(dealerId, link);
      if (accountId) linksByAccountId.set(accountId, dealerId);
    }

    const milestonesByAccount = new Map();
    for (const milestone of Array.isArray(allMilestones) ? allMilestones : []) {
      if (!milestonesByAccount.has(milestone.account_id)) {
        milestonesByAccount.set(milestone.account_id, []);
      }
      milestonesByAccount.get(milestone.account_id).push(milestone);
    }

    // Dedup keys for turnover snapshots: (account_id, source_last_updated).
    // A new snapshot is appended only when the source timestamp differs from
    // every existing record for that account+year — historical records are
    // never overwritten.
    // Dedup keys for turnover snapshots: (account_id, source_last_updated).
    // A new snapshot is appended only when the source timestamp differs from
    // every existing record for that account+year — historical records are
    // never overwritten. Null (Unknown) source timestamps are normalised to a
    // stable sentinel so a repeated null-timestamp payload does not append a
    // duplicate record on every sync.
    const NULL_TS_SENTINEL = "\u0000UNKNOWN";
    const normaliseTsKey = (ts) => (ts ? String(ts) : NULL_TS_SENTINEL);
    const existingTurnoverKeys = new Set();
    for (const r of Array.isArray(existingTurnoverRecords) ? existingTurnoverRecords : []) {
      existingTurnoverKeys.add(`${r.account_id}|${normaliseTsKey(r.source_last_updated)}`);
    }

    let dealersMatched = 0;
    let dealersUnmatched = 0;
    let dealersUpdated = 0;
    let dealersReconciled = 0;
    let milestonesAwarded = 0;
    let projectsAwarded = 0;
    let milestonesReversed = 0;
    let projectsReversed = 0;
    let milestonesReinstated = 0;
    let projectsReinstated = 0;
    let turnoverSnapshotsAppended = 0;
    let errorCount = 0;
    const errors = [];
    const dealerResults = [];

    for (const dealerEntitlement of contract.dealers) {
      const dealerId = dealerEntitlement.dealer_account_id;
      const link = linksByDealerId.get(dealerId);
      if (!link?.account_id) {
        dealersUnmatched += 1;
        dealerResults.push({
          dealer_account_id: dealerId,
          match_status: "UNMATCHED",
          planned_actions: 0,
        });
        continue;
      }

      dealersMatched += 1;
      const accountId = link.account_id;
      // Query per account so app-wide ledger growth cannot truncate old threshold
      // events and accidentally make a previously credited threshold look missing.
      const service = base44.asServiceRole;
      const lock = dryRun ? null : await acquireCreationLock(service, accountId);
      if (!dryRun && !lock.acquired) {
        errorCount += 1;
        errors.push(`Account ${accountId}: REWARD_SYNC_BUSY`);
        dealerResults.push({ dealer_account_id: dealerId, sound_proof_account_id: accountId, match_status: 'RETRY_REQUIRED', planned_actions: 0 });
        continue;
      }
      let safeToRelease = true;
      try {
      // The project-creation mutex also serializes reward reconciliations.
      // Read the complete ledger after acquiring it; never act on an old plan.
      const accountLedger = await getCapacityLedgerEntries(service, accountId);
      const latestRewardTime = accountLedger.reduce((latest, entry) =>
        entry.source_ref?.reward_program === 'UK_TURNOVER_REWARD'
          ? Math.max(latest, Date.parse(entry.source_ref?.entitlement_calculated_at || '') || 0)
          : latest, 0);
      if (Date.parse(contract.calculated_at) < latestRewardTime) {
        errorCount += 1;
        errors.push(`Account ${accountId}: STALE_ENTITLEMENT`);
        dealerResults.push({ dealer_account_id: dealerId, sound_proof_account_id: accountId, match_status: 'STALE_ENTITLEMENT', planned_actions: 0 });
        continue;
      }
      let actions;
      try {
        actions = buildThresholdReconciliationPlan({
          accountId,
          calendarYear,
          earnedThresholds: dealerEntitlement.earned_thresholds_gbp,
          ledgerEntries: accountLedger,
        });
      } catch (error) {
        errorCount += 1;
        errors.push(`Account ${accountId}: ${summarizeError(error)}`);
        dealerResults.push({
          dealer_account_id: dealerId,
          sound_proof_account_id: accountId,
          match_status: "LEDGER_INCONSISTENT",
          planned_actions: 0,
        });
        continue;
      }

      dealersReconciled += 1;
      const currentMilestones = await service.entities.TurnoverMilestone.filter({ account_id: accountId, calendar_year: calendarYear }, '-created_date', 5000);
      const milestoneMap = latestMilestoneByThreshold(currentMilestones);
      const appliedActions = [];

      for (const action of actions) {
        if (dryRun) {
          appliedActions.push({ kind: action.kind, threshold_gbp: action.threshold });
        } else {
          const duplicate = await base44.asServiceRole.entities.CapacityLedger.filter({
            idempotency_key: action.idempotency_key,
          });
          if (Array.isArray(duplicate) && duplicate.length > 0) continue;

          safeToRelease = false; // An unconfirmed write must retain the mutex for reconciliation.
          let ledgerEntry;
          const ledgerPayload = {
            account_id: accountId,
            transaction_type: action.kind === "REVERSE" ? "REVERSAL" : "UK_TURNOVER_REWARD",
            delta: action.delta,
            idempotency_key: action.idempotency_key,
            source_system: SOURCE_SYSTEM,
            source_ref: {
              reward_program: "UK_TURNOVER_REWARD",
              dealer_account_id: dealerId,
              calendar_year: calendarYear,
              milestone_value_gbp: action.threshold,
              contract_version: contract.contract_version,
              entitlement_calculated_at: contract.calculated_at,
              previous_event_id: action.previous_event_id,
            },
            reason: action.kind === "REVERSE"
              ? `UK turnover reward reversal £${action.threshold.toLocaleString()} milestone (${calendarYear})`
              : action.kind === "REINSTATE"
                ? `UK turnover reward reinstated £${action.threshold.toLocaleString()} milestone (${calendarYear})`
                : `UK turnover reward £${action.threshold.toLocaleString()} milestone (${calendarYear})`,
            reversal_of: action.reversal_of,
          };
          try {
            ledgerEntry = await service.entities.CapacityLedger.create(ledgerPayload);
          } catch (writeError) {
            const confirmed = await service.entities.CapacityLedger.filter({ idempotency_key: action.idempotency_key });
            if (!Array.isArray(confirmed) || confirmed.length !== 1
              || confirmed[0].account_id !== accountId || confirmed[0].delta !== action.delta
              || confirmed[0].transaction_type !== ledgerPayload.transaction_type) throw writeError;
            ledgerEntry = confirmed[0];
          }
          if (!ledgerEntry?.id) throw new Error('REWARD_WRITE_UNCONFIRMED');
          safeToRelease = true;
          accountLedger.push(ledgerEntry);

          const nowIso = new Date().toISOString();
          const existingMilestone = milestoneMap.get(action.threshold);
          const milestoneFields = {
            account_id: accountId,
            calendar_year: calendarYear,
            milestone_value_gbp: action.threshold,
            reward_projects: Math.abs(action.delta),
            status: action.kind === "REVERSE" ? "REVERSED" : "ACTIVE",
            latest_ledger_entry_id: ledgerEntry.id,
            last_reconciled_at: nowIso,
            source_calculated_at: contract.calculated_at,
          };

          if (existingMilestone) {
            await base44.asServiceRole.entities.TurnoverMilestone.update(existingMilestone.id, {
              ...milestoneFields,
              reward_ledger_entry_id:
                existingMilestone.reward_ledger_entry_id
                || (action.delta > 0 ? ledgerEntry.id : null),
              reversal_ledger_entry_id:
                action.kind === "REVERSE"
                  ? ledgerEntry.id
                  : existingMilestone.reversal_ledger_entry_id || null,
              reinstatement_count:
                Number(existingMilestone.reinstatement_count || 0)
                + (action.kind === "REINSTATE" ? 1 : 0),
              reversal_count:
                Number(existingMilestone.reversal_count || 0)
                + (action.kind === "REVERSE" ? 1 : 0),
            });
          } else {
            const milestone = await base44.asServiceRole.entities.TurnoverMilestone.create({
              ...milestoneFields,
              reward_ledger_entry_id: action.delta > 0 ? ledgerEntry.id : null,
              reversal_ledger_entry_id: action.kind === "REVERSE" ? ledgerEntry.id : null,
              reinstatement_count: action.kind === "REINSTATE" ? 1 : 0,
              reversal_count: action.kind === "REVERSE" ? 1 : 0,
            });
            milestoneMap.set(action.threshold, milestone);
          }
          appliedActions.push({ kind: action.kind, threshold_gbp: action.threshold });
        }

        if (action.kind === "AWARD") {
          milestonesAwarded += 1;
          projectsAwarded += action.delta;
        } else if (action.kind === "REVERSE") {
          milestonesReversed += 1;
          projectsReversed += Math.abs(action.delta);
        } else if (action.kind === "REINSTATE") {
          milestonesReinstated += 1;
          projectsReinstated += action.delta;
        }
      }

      if (appliedActions.length > 0) dealersUpdated += 1;

      // Append a turnover snapshot for the dealer's current annual figure.
      // A new TurnoverRecord is created only when the source timestamp differs
      // from every existing record for this account+year — preserving history.
      if (!dryRun && dealerEntitlement.current_turnover_gbp !== undefined) {
        const turnoverKey = `${accountId}|${normaliseTsKey(dealerEntitlement.turnover_source_updated_at)}`;
        const currentSnapshots = await service.entities.TurnoverRecord.filter({
          account_id: accountId, calendar_year: calendarYear,
          source_last_updated: dealerEntitlement.turnover_source_updated_at ?? null,
        }, '-created_date', 1);
        if (!currentSnapshots?.length) {
          await base44.asServiceRole.entities.TurnoverRecord.create({
            account_id: accountId,
            external_account_link_id: link.id,
            calendar_year: calendarYear,
            eligible_turnover_gbp: dealerEntitlement.current_turnover_gbp,
            source_currency: "GBP",
            source_turnover: dealerEntitlement.current_turnover_gbp,
            source_system: SOURCE_SYSTEM,
            source_last_updated: dealerEntitlement.turnover_source_updated_at,
            sync_date: new Date().toISOString(),
          });
          existingTurnoverKeys.add(turnoverKey);
          turnoverSnapshotsAppended += 1;
        }
      }

      dealerResults.push({
        dealer_account_id: dealerId,
        sound_proof_account_id: accountId,
        match_status: "MATCHED",
        entitlement_threshold_count: dealerEntitlement.earned_thresholds_gbp.length,
        planned_actions: appliedActions,
      });
      } finally {
        if (lock?.acquired && safeToRelease) await releaseCreationLock(service, accountId, lock.token);
      }
    }

    const finalStatus = dryRun
      ? "DRY_RUN"
      : (errorCount > 0 || dealersUnmatched > 0 ? "PARTIAL" : "SUCCESS");
    const finishedAt = new Date().toISOString();

    await updateSyncRun(base44, syncRunId, {
      finished_at: finishedAt,
      source_last_updated: contract.calculated_at,
      status: finalStatus,
      dealers_received: contract.dealers.length,
      dealers_matched: dealersMatched,
      dealers_unmatched: dealersUnmatched,
      dealers_updated: dealersUpdated,
      dealers_reconciled: dealersReconciled,
      milestones_awarded: milestonesAwarded,
      projects_awarded: projectsAwarded,
      milestones_reversed: milestonesReversed,
      projects_reversed: projectsReversed,
      milestones_reinstated: milestonesReinstated,
      projects_reinstated: projectsReinstated,
      turnover_snapshots_appended: turnoverSnapshotsAppended,
      discrepancy_count: errorCount,
      error_count: errorCount,
      error_summary: errors.join("; ").slice(0, 2000),
    });

    return Response.json({
      status: finalStatus,
      dry_run: dryRun,
      calendar_year: calendarYear,
      contract_version: contract.contract_version,
      entitlement_calculated_at: contract.calculated_at,
      sync_run_id: syncRunId,
      summary: {
        dealers_received: contract.dealers.length,
        dealers_matched: dealersMatched,
        dealers_unmatched: dealersUnmatched,
        dealers_reconciled: dealersReconciled,
        dealers_updated: dealersUpdated,
        milestones_awarded: milestonesAwarded,
        projects_awarded: projectsAwarded,
        milestones_reversed: milestonesReversed,
        projects_reversed: projectsReversed,
        milestones_reinstated: milestonesReinstated,
        projects_reinstated: projectsReinstated,
        turnover_snapshots_appended: turnoverSnapshotsAppended,
        error_count: errorCount,
      },
      dealers: dealerResults,
    });
  } catch (error) {
    if (base44 && syncRunId) {
      try {
        await updateSyncRun(base44, syncRunId, {
          status: "FAILED",
          finished_at: new Date().toISOString(),
          error_count: 1,
          error_summary: summarizeError(error),
        });
      } catch {
        // Preserve the original failure response.
      }
    }
    return Response.json({
      status: "FAILED",
      error: summarizeError(error),
      sync_run_id: syncRunId,
    }, { status: 500 });
  }
}