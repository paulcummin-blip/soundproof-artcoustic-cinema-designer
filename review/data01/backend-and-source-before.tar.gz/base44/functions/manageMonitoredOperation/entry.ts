import { handleReportUpload } from '../../shared/reportUploadRecovery.js';
import {loadOwnedProject,loadOwnedProjectVersion} from "../../shared/publishedEngineeringRead.js";
import {safeDiagnostic} from "../../shared/systemHealth/clientIncidentPolicy.js";
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import {
  startOperation,
  reportOperationProgress,
  completeOperation,
  failOperation,
  cancelOperation,
} from '../../shared/systemHealth/operationMonitor.js';

/**
 * manageMonitoredOperation
 * ------------------------
 * Frontend-facing endpoint for reporting operation lifecycle events to the
 * durable MonitoredOperation record. Used by browser-based operations (report
 * export) that need to report progress to the backend so the watchdog can
 * detect stalls when the browser tab closes.
 *
 * All actions are fail-open: a monitoring failure returns an error but never
 * blocks the dealer's operation.
 */
export default async function(req) {
  let reportRegistration=false, registrationWriteAttempted=false;
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const multipart = req.headers.get('content-type')?.includes('multipart/form-data');
    const form = multipart ? await req.formData() : null;
    const body = form ? Object.fromEntries(form.entries()) : await req.json().catch(() => ({}));
    const { action } = body;
    reportRegistration=action==='start' && body.operation_type==='report_export';
    if (['report_upload_prepare', 'report_upload_status', 'report_upload_put', 'report_upload_recover', 'report_record_status', 'report_record_put'].includes(action)) {
      // Storage is fail-closed. Existing monitoring actions remain fail-open.
      try {
        return Response.json(await handleReportUpload({ service: base44.asServiceRole, caller: base44, user, body, file: form?.get('file') }));
      } catch (error) {
        return Response.json({ error: error?.code || 'REPORT_UPLOAD_RECONCILIATION_UNAVAILABLE' }, { status: error?.status || 503 });
      }
    }

    if (!/^[a-zA-Z0-9:_-]{8,160}$/.test(String(body.operation_id || ''))) return Response.json({error:'Invalid operation ID'},{status:400});
    if (action === 'start') {
      if (!['proposal_generation','report_export','client_request'].includes(body.operation_type)) return Response.json({error:'Invalid operation type'},{status:400});
      body.account_id=user.account_id || null;
      if (body.project_id) {
        const access={isMasterAdmin:user.role==='admin',user};
        const owned=body.version_id
          ? await loadOwnedProjectVersion(base44.asServiceRole,body.project_id,body.version_id,access)
          : await loadOwnedProject(base44.asServiceRole,body.project_id,access);
        body.account_id=owned.projectAccountId;
      }
    } else {
      const rows=await base44.asServiceRole.entities.MonitoredOperation.filter({operation_id:body.operation_id}, '-started_at', 1);
      const record=(Array.isArray(rows)?rows:rows?.items||[])[0];
      if (!record) return Response.json({recorded:false,reason:'not_found'});
      if (user.role!=='admin' && record.initiated_by!==user.id && (!record.account_id || record.account_id!==user.account_id))
        return Response.json({error:'Forbidden'},{status:403});
    }
    if(reportRegistration) {
      const result=await base44.asServiceRole.entities.MonitoredOperation.filter({operation_id:body.operation_id},'-created_date',2);
      const existing=Array.isArray(result)?result:result?.items||[];
      if(existing.length) {
        const row=existing[0];
        const same=existing.length===1 && row.operation_type==='report_export' && row.initiated_by===user.id && row.project_id===body.project_id && row.version_id===body.version_id;
        return Response.json(same ? {recorded:true,operation_id:body.operation_id,reconciled:true} : {recorded:false,registration_outcome:'conflict',error:'REPORT_REGISTRATION_IDENTITY_CONFLICT'});
      }
    }
    body.initial_stage=safeDiagnostic(body.initial_stage,100);
    body.stage=safeDiagnostic(body.stage,100);
    body.diagnostic_summary=safeDiagnostic(body.diagnostic_summary);
    switch (action) {
      case 'start': {
        registrationWriteAttempted=true;
        let registrationOutcome='unknown';
        const monitorClient=reportRegistration ? {asServiceRole:{entities:{MonitoredOperation:{
          create:async data=>{
            try {return await base44.asServiceRole.entities.MonitoredOperation.create(data);}
            catch(error) {
              const status=Number(error?.response?.status || error?.status || 0);
              registrationOutcome=[400,401,403,404,413,415,422].includes(status)?'refused':'unknown';
              throw error;
            }
          },
        }}}} : base44;
        const started=await startOperation(monitorClient, {
          operation_id: body.operation_id,
          operation_type: body.operation_type,
          initiated_by:user.id,
          account_id: body.account_id || null,
          project_id: body.project_id || null,
          version_id: body.version_id || null,
          proposal_id: body.proposal_id || null,
          initial_stage: body.initial_stage || 'started',
        });
        return Response.json({...started,...(reportRegistration && !started.recorded ? {registration_outcome:registrationOutcome}:{})});
      }

      case 'progress':
        return Response.json(await reportOperationProgress(base44, {
          operation_id: body.operation_id,
          stage: body.stage,
        }));

      case 'complete':
        return Response.json(await completeOperation(base44, {
          operation_id: body.operation_id,
          proposal_id: body.proposal_id || null,
        }));

      case 'fail':
        return Response.json(await failOperation(base44, {
          operation_id: body.operation_id,
          error_code: body.error_code || 'UNKNOWN',
          diagnostic_summary: body.diagnostic_summary || null,
          incident_reference: body.incident_reference || null,
        }));

      case 'cancel':
        return Response.json(await cancelOperation(base44, {
          operation_id: body.operation_id,
        }));

      default:
        return Response.json({ error: 'Unknown action' }, { status: 400 });
    }
  } catch (error) {
    // Fail-open: never block the dealer's operation.
    return Response.json({ recorded: false, error: error?.message || 'Monitoring failed', fail_open: true, ...(reportRegistration?{registration_outcome:registrationWriteAttempted?'unknown':'not_started'}:{}) });
  }
}

