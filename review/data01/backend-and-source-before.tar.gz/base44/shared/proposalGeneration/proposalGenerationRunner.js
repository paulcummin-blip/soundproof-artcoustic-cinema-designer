/**
 * proposalGenerationRunner.js (shared)
 * -------------------------------------
 * THE Phase 6 orchestration: one controlled GPT proposal-writing attempt, from
 * the feature flag to the append-only record.
 *
 * The order is the contract, and it is fixed:
 *
 *   1. the feature flag — refused before anything is read or sent;
 *   2. the selection — which versions this proposal covers;
 *   3. the retry target — the attempt a retry points at, when there is one;
 *   4. the saved report evidence — the Phase 1 read path, and the only source;
 *   5. the frozen evidence pack and the Phase 2 writer input, plus the proof that
 *      the input carries no live design state;
 *   6. the provider call (injected — this module holds no client and no key);
 *   7. the Phase 2 validator, against the exact input the writer was given;
 *   8. one appended Phase 3 record, whatever happened.
 *
 * A refusal is a result, not an exception: a switched-off flag, evidence that is
 * missing, stale, incomplete or not current, and a retry whose evidence has moved
 * on all come back as `{ ok: false, code, message }` with nothing written and no
 * provider call made. A provider failure or a rejected draft also never throws —
 * they are recorded, because the record is the audit of what happened.
 *
 * Everything external is injected (the evidence read, the provider call, the
 * clock, the user), so the whole path is exercised in tests without a live
 * project and without a real provider.
 *
 * Pure: no React, no SDK, no runtime-specific APIs.
 */

import { buildProposalEvidence } from '../proposalEvidence/proposalEvidenceBuilder.js';
import { buildProposalNarrativeContext } from '../proposalNarrativeContext.js';
import { buildWriterInput } from '../proposalWriter/writerInputBuilder.js';
import { buildWriterDesignContext } from '../proposalWriter/writerDesignContext.js';
import { assertWriterInputCarriesNoLiveState } from '../proposalWriter/writerPromptBuilder.js';
import { callWriterProvider } from '../proposalWriter/writerProvider.js';
import { validateWriterOutput } from '../proposalWriter/writerOutputValidator.js';
import { buildClientBriefCoverage } from '../proposalWriter/writerClientBriefCoverage.js';
import { isEligibleForWordingCorrection, WORDING_CORRECTION_REASON } from '../proposalWriter/writerCorrectionPolicy.js';
import { buildCorrectionPromptBlock } from '../proposalWriter/writerCorrectionPrompt.js';
import { GENERATION_STATUS } from './generationStatuses.js';
import { createGenerationHistory } from './proposalGenerationRepository.js';

/**
 * The designer's explicit requests, as the evidence pack reads them. The one
 * thing that can admit an assumed parameter (P8, P15, P21) into a proposal is
 * the designer asking for it — never the evidence, and never the writer.
 */
export function proposalRequestContext(proposal = {}) {
  return {
    clientBrief: [proposal?.client_brief, proposal?.narrative_brief].filter(Boolean).join('\n'),
    dealerNotes: proposal?.metadata?.dealer_notes || '',
  };
}

/** Why a generation attempt was refused before it was made. */
export const WRITER_REFUSAL = Object.freeze({
  FLAG_OFF: 'writer_flag_off',
  NO_SELECTION: 'proposal_has_no_selected_versions',
  RETRY_TARGET_UNKNOWN: 'retry_target_unknown',
  RETRY_EVIDENCE_CHANGED: 'retry_evidence_changed',
  EVIDENCE_UNAVAILABLE: 'evidence_unavailable',
  ALREADY_RECORDED: 'attempt_already_recorded',
});

function refusal(code, message) {
  return { ok: false, code, message, record: null };
}

function refusalStatus(code) {
  switch (code) {
    case WRITER_REFUSAL.FLAG_OFF: return 403;
    case WRITER_REFUSAL.NO_SELECTION: return 400;
    case WRITER_REFUSAL.RETRY_TARGET_UNKNOWN: return 404;
    case WRITER_REFUSAL.RETRY_EVIDENCE_CHANGED: return 409;
    case WRITER_REFUSAL.ALREADY_RECORDED: return 409;
    case WRITER_REFUSAL.EVIDENCE_UNAVAILABLE: return 409;
    default: return 400;
  }
}

/** The HTTP status a refusal is reported with. */
export function writerRefusalStatus(code) {
  return refusalStatus(code);
}

/**
 * Which versions a proposal covers, and the proposal type that follows from it.
 * Read from the saved proposal, never from the browser.
 */
export function proposalCopySelection(proposal = {}) {
  const selected = Array.isArray(proposal.selected_version_ids)
    ? proposal.selected_version_ids.filter((id) => typeof id === 'string' && id.length > 0)
    : [];
  const versionIds = selected.length > 0
    ? selected
    : (typeof proposal.version_id === 'string' && proposal.version_id.length > 0 ? [proposal.version_id] : []);

  return {
    versionIds,
    proposalType: proposal.proposal_type || (versionIds.length >= 2 ? 'comparison' : 'single'),
  };
}

/**
 * Run one controlled attempt.
 *
 * @param {Object} input
 * @param {Object} input.proposal — the saved Proposal record
 * @param {string} input.projectId
 * @param {string} [input.accountId]
 * @param {Array<Object>} [input.existingGenerations] — the proposal's stored records
 * @param {Object} input.flag — resolveGptWriterFlag output
 * @param {Function} input.readEvidence — async ({ versionIds, proposal }) => readProposalReportEvidence output
 * @param {Function} [input.readOptionGuidance] — async ({ projectId, proposal }) =>
 *   the designer's own seating or layout alternatives (buildOptionGuidance output),
 *   handed to the writer as a BRIEF. Optional: a project that states none, or a
 *   caller that supplies no reader, writes a document with no options copy.
 * @param {Function} input.invokeLLM — the server-side provider call
 * @param {Object} input.user — the authenticated user ({ full_name, email })
 * @param {string} input.now — ISO timestamp
 * @param {string|null} [input.retryOfGenerationId]
 * @returns {Promise<Object>} a refusal, or the appended attempt's outcome
 */
export async function runProposalCopyGeneration({
  proposal = null,
  projectId = null,
  accountId = null,
  existingGenerations = [],
  flag = null,
  readEvidence = null,
  readOptionGuidance = null,
  invokeLLM = null,
  user = null,
  now = null,
  retryOfGenerationId = null,
  savedInterpretation = null,
  dealerNotes = null,
  clarificationAnswers = null,
} = {}) {
  // 1. The flag. Nothing is read and nothing is sent while it is off.
  if (flag?.enabled !== true) {
    return refusal(
      WRITER_REFUSAL.FLAG_OFF,
      'The GPT proposal writer is not enabled for this login. No evidence was read and no provider call was made.',
    );
  }

  // 2. The selection, taken from the saved proposal.
  const { versionIds, proposalType } = proposalCopySelection(proposal);
  if (versionIds.length === 0) {
    return refusal(
      WRITER_REFUSAL.NO_SELECTION,
      'This proposal covers no version, so there is no report evidence to write from.',
    );
  }

  const generations = Array.isArray(existingGenerations) ? existingGenerations : [];

  // 3. A retry points at the attempt it retries, within this proposal.
  let retryTarget = null;
  if (retryOfGenerationId) {
    retryTarget = generations.find((record) => record?.generation_id === retryOfGenerationId) || null;
    const sameProposal = retryTarget
      && String(retryTarget.proposal_id || '') === String(proposal?.id || '');
    if (!retryTarget || !sameProposal) {
      return refusal(
        WRITER_REFUSAL.RETRY_TARGET_UNKNOWN,
        'That attempt is not part of this proposal, so there is nothing to retry.',
      );
    }
  }

  // 4. The evidence. The read path refuses missing, stale, incomplete and
  //    not-current reports, and its message names the version and the report.
  if (typeof readEvidence !== 'function') {
    return refusal(WRITER_REFUSAL.EVIDENCE_UNAVAILABLE, 'No report-evidence reader was supplied, so nothing could be written from.');
  }

  let versions = null;
  try {
    versions = await readEvidence({ versionIds, proposal });
  } catch (error) {
    return refusal(
      WRITER_REFUSAL.EVIDENCE_UNAVAILABLE,
      error?.message || 'The saved report evidence could not be read.',
    );
  }

  // 4a. The designer's own seating or layout alternatives. These are a BRIEF for
  //     the writer, never published copy. Guidance is editorial, not evidence: a
  //     brief that cannot be read leaves the options section empty rather than
  //     failing a generation the evidence itself supports.
  let optionGuidance = null;
  if (typeof readOptionGuidance === 'function') {
    try {
      optionGuidance = await readOptionGuidance({ projectId, proposal });
    } catch (error) {
      return refusal(WRITER_REFUSAL.EVIDENCE_UNAVAILABLE, error?.message || 'The design instructions could not be read.');
    }
  }

  // 5. The frozen pack, the Phase 2 input, and the proof that the input carries
  //    evidence and contract only.
  let pack = null;
  let writerInput = null;
  try {
    pack = buildProposalEvidence({
      versions,
      generatedAt: now,
      requestContext: proposalRequestContext(proposal),
      // THE PROJECT'S OWN CONTEXT, read from the proposal record and its verified
      // interpretation: the intent, the room type, the designer's brief, the subjects
      // their narrative steer keeps out, the seat scopes and the achieved results the
      // reports state. It decides how much of each pillar is told and what is left
      // out — never a figure, a level or a claim, and never live design state.
      narrativeContext: buildProposalNarrativeContext({ proposal, interpretation: savedInterpretation }),
    });
    // The design context the writer writes FROM: the ADI interpretation Stage 1
    // already produced for this proposal, verified against this frozen evidence,
    // and the designer's own brief. Neither is a source of figures.
    writerInput = buildWriterInput({
      pack,
      optionGuidance,
      designContext: buildWriterDesignContext({
        proposal,
        projectId: projectId ?? proposal?.project_id ?? null,
        versionIds,
        pack,
        savedInterpretation,
        dealerNotes,
        clarificationAnswers,
      }),
      // The designer's narrative steer: soft preferences about what this proposal
      // weighs and what it leaves out, read from the proposal record. They are
      // never required sections, they add no claim, and the designer's own brief
      // outranks them.
      narrativeSteer: proposal?.metadata?.narrative_steer || null,
    });
    assertWriterInputCarriesNoLiveState(writerInput);
  } catch (error) {
    return refusal(
      WRITER_REFUSAL.EVIDENCE_UNAVAILABLE,
      error?.message || 'The frozen evidence pack could not be built.',
    );
  }

  // A retry is made from the same evidence. When the evidence has moved on, this
  // is a new generation rather than a retry of the old one, and saying so is
  // safer than quietly relinking it.
  if (retryTarget && String(retryTarget.evidence_pack_fingerprint || '') !== String(pack.pack_fingerprint || '')) {
    return refusal(
      WRITER_REFUSAL.RETRY_EVIDENCE_CHANGED,
      'The design or its saved reports have changed since that attempt, so it cannot be retried. Generate a new copy instead.',
    );
  }

  // 6. The provider call. A failure comes back as a result.
  const provider = await callWriterProvider({ invokeLLM, input: writerInput, model: flag?.model ?? null });

  // 7. The validator, against the exact input the writer was given. Output that
  //    did not arrive is not validated, and is never called valid.
  const validation = provider.output !== null && provider.output !== undefined
    ? validateWriterOutput({ input: writerInput, output: provider.output })
    : null;

  // 7a. THE BOUNDED WORDING CORRECTION. When the initial draft arrived and
  //     failed validation on wording-only rejections alone, ONE additional
  //     writer call is made: the writer's own draft is handed back with the
  //     exact rejected passages, rule IDs and guidance, and it corrects ONLY
  //     the offending language. The corrected draft is validated by the SAME
  //     complete validator — never a weakened one — and is accepted only when it
  //     passes every existing rule. A correction that touches an engineering
  //     fact, a figure, a level, a product, a scope or a citation is refused.
  //     No loop: exactly one correction attempt, then the attempt is terminal.
  let correction = null;
  let finalOutput = provider.output;
  let finalValidation = validation;

  if (
    provider.output !== null && provider.output !== undefined
    && validation && validation.valid !== true
  ) {
    const eligibility = isEligibleForWordingCorrection(validation.violations);
    if (eligibility.eligible) {
      const correctionBlock = buildCorrectionPromptBlock({
        initialOutput: provider.output,
        violations: validation.violations,
      });
      const correctionProvider = await callWriterProvider({
        invokeLLM,
        input: writerInput,
        model: flag?.model ?? null,
        correction: { needed: true, block: correctionBlock },
      });

      const correctionValidation = correctionProvider.output !== null && correctionProvider.output !== undefined
        ? validateWriterOutput({ input: writerInput, output: correctionProvider.output })
        : null;

      correction = {
        attempted: true,
        reason: WORDING_CORRECTION_REASON,
        eligible_rule_ids: eligibility.eligible_rule_ids,
        initial_output: provider.output,
        initial_validation: validation,
        correction_output: correctionProvider.output,
        correction_validation: correctionValidation,
        correction_provider_error: correctionProvider.provider_error ?? null,
        // The correction succeeded only when the corrected draft arrived AND
        // passed the complete validator. Anything else is a failed correction,
        // and the attempt is terminal: the initial draft stands as the output.
        succeeded: correctionValidation?.valid === true,
      };

      // The corrected draft becomes the final output ONLY when it passes the
      // full validator. A correction that failed validation, or a provider that
      // returned nothing, leaves the initial draft as the recorded output so the
      // rejection is diagnosable.
      if (correction.succeeded) {
        finalOutput = correctionProvider.output;
        finalValidation = correctionValidation;
      }
    }
  }

  // 7b. What the draft did with the designer's own brief: every substantive
  //     request is either addressed in the narrative or flagged here, so nothing is
  //     silently ignored. This is an audit of coverage — it rejects nothing, and it
  //     is never itself published. It reads the FINAL output (the corrected draft
  //     when the correction succeeded, the initial draft otherwise).
  const clientBriefCoverage = buildClientBriefCoverage({
    brief: writerInput.editorial_brief,
    pack,
    interpretation: writerInput.design_interpretation?.view || null,
    sections: finalValidation?.output?.sections || finalOutput?.sections || [],
  });

  // 8. One appended record, whatever happened.
  const history = createGenerationHistory({ records: generations });

  let record = null;
  try {
    record = history.append({
      proposalId: proposal?.id ?? null,
      draftProposalId: proposal?.id ? null : (proposal?.draft_proposal_id ?? null),
      projectId: projectId ?? proposal?.project_id ?? null,
      accountId: accountId ?? proposal?.account_id ?? null,
      proposalType,
      selectedVersionIds: versionIds,
      pack,
      writerInput,
      output: finalOutput,
      validation: finalValidation,
      providerError: provider.provider_error,
      outcome: provider.provider_error ? 'provider_failed' : 'generated',
      provider: provider.provider,
      model: provider.model,
      createdBy: user?.full_name || user?.email || 'Unknown user',
      createdAt: now,
      retryOfGenerationId: retryTarget?.generation_id ?? null,
      correction,
    });
  } catch (error) {
    const message = error?.message || 'The attempt could not be recorded.';
    return refusal(
      /already stored/i.test(message) ? WRITER_REFUSAL.ALREADY_RECORDED : WRITER_REFUSAL.EVIDENCE_UNAVAILABLE,
      message,
    );
  }

  return {
    ok: true,
    code: null,
    message: null,
    record,
    generation_id: record.generation_id,
    generation_number: record.generation_number,
    status: record.status,
    valid: record.status === GENERATION_STATUS.VALID_GENERATED,
    validation_errors: record.validation_errors,
    retry_of_generation_id: record.retry_of_generation_id,
    provider: record.provider,
    model: record.model,
    // What the writer was given beyond the pack, so a caller can log exactly what
    // this attempt was written from.
    design_interpretation: writerInput.design_interpretation,
    editorial_brief_supplied: writerInput.editorial_brief?.supplied === true,
    // The designer's answers to ADI's clarification questions, carried as design
    // intent for the sections they belong to. Never copy, and never evidence.
    clarification_answers_supplied: writerInput.clarification_answers?.supplied === true,
    clarification_questions_passed: writerInput.clarification_answers?.passed_questions || [],
    // What the brief asked for and what the draft did with it, item by item.
    client_brief_coverage: clientBriefCoverage,
    // EDITORIAL COMPLETENESS, reported separately from the engineering validation
    // above: the brief is complete only where every supported request it makes is
    // answered in the finished copy. A document that is valid but not complete is
    // never presentable as ready to issue, and the unanswered requests are named
    // with the section each one belongs to, so they can be returned to the writer
    // through the one controlled revision.
    editorial_completeness: {
      complete: clientBriefCoverage.complete === true,
      outstanding_count: clientBriefCoverage.outstanding_count,
      outstanding: clientBriefCoverage.outstanding,
      revision_requests: clientBriefCoverage.revision_requests,
      rule: 'engineering validity and editorial completeness are separate checks: this one is the designer\'s brief, and it is complete only when every supported request is explained in the copy',
    },
    issue_ready: record.status === GENERATION_STATUS.VALID_GENERATED
      && clientBriefCoverage.complete === true,
    // THE BOUNDED WORDING CORRECTION, reported so a caller can see whether a
    // correction was attempted, whether it succeeded, and what the initial and
    // second validations said. The full audit is on the record itself.
    correction: correction
      ? {
        attempted: true,
        succeeded: correction.succeeded,
        reason: correction.reason,
        eligible_rule_ids: correction.eligible_rule_ids,
        initial_valid: correction.initial_validation?.valid === true,
        initial_violation_count: correction.initial_validation?.violations?.length || 0,
        correction_valid: correction.correction_validation?.valid === true,
        correction_violation_count: correction.correction_validation?.violations?.length || 0,
        correction_provider_error: correction.correction_provider_error,
      }
      : { attempted: false },
    prompt_version: record.prompt_version,
    schema_version: record.schema_version,
    contract_version: record.contract_version,
    evidence_pack_fingerprint: record.evidence_pack_fingerprint,
    duration_ms: provider.duration_ms,
  };
}

export default runProposalCopyGeneration;