/**
 * reportDesignIntentRunner.js (shared)
 * ------------------------------------
 * ONE controlled Astra attempt at a Project Report's Design Intent.
 *
 * The order is the contract and it is short, because nothing here is a new
 * pipeline: the flag, the frozen report evidence, the existing evidence pack, the
 * existing writer input — scoped to the one section — the existing provider, the
 * existing validator, and one record of what happened.
 *
 * The operation is OPTIONAL and FAILURE-ISOLATED. Every way it can fail — the
 * writer switched off, evidence that cannot be read, a provider timeout, an empty
 * answer, or a draft the validator refuses — comes back as `{ ok: false, reason }`
 * with no text accepted and nothing written. It never throws, and it never
 * touches the report: the Project Report generates, renders and prints exactly as
 * it always has, with its own deterministic Design Intent, whether this runs, is
 * refused, or fails.
 *
 * The engineering interpretation is REUSED, not reinvented: when the caller holds
 * the frozen engineering snapshot, the shared ADI interpretation Stage 1 is built
 * from it and carried to the writer; without it the writer is given the frozen
 * pack and the designer's own recorded intent, which is the pack-alone behaviour
 * the existing design context already defines.
 *
 * Everything external is injected — the evidence read, the provider call, the
 * validator, the clock, the user — so the whole path is exercised in tests without
 * a live project and without a real provider.
 *
 * Pure: no React, no SDK, no runtime-specific APIs.
 */

import { buildProposalEvidence } from '../proposalEvidence/proposalEvidenceBuilder.js';
import { buildProjectInterpretation } from '../adiProjectInterpretation.js';
import {
  INTERPRETATION_RULE,
  VERIFIED_INTERPRETATION_SOURCE,
  buildEditorialBrief,
  interpretationView,
} from '../proposalWriter/writerDesignContext.js';
import { assertWriterInputCarriesNoLiveState } from '../proposalWriter/writerPromptBuilder.js';
import { reviewDesignIntentCoverage, CONTEXT_COVERAGE_MISSING } from './designIntentCoverage.js';
import { isEligibleForWordingCorrection } from '../proposalWriter/writerCorrectionPolicy.js';
import { buildCorrectionPromptBlock } from '../proposalWriter/writerCorrectionPrompt.js';
import { callWriterProvider } from '../proposalWriter/writerProvider.js';
import { validateWriterOutput, parseWriterOutput } from '../proposalWriter/writerOutputValidator.js';
import { validatorProvenance } from '../proposalWriter/validatorProvenance.js';
import { DESIGN_INTENT_SECTION } from './designIntentBrief.js';
import { buildDesignIntentWriterInput } from './buildDesignIntentWriterInput.js';
import {
  visualContextIdentity,
  visualContextSources,
} from './reportVisualContext.js';
import {
  DESIGN_INTENT_STATUS,
  buildDesignIntentRecord,
} from './reportDesignIntentRecord.js';

/** Why a Design Intent attempt produced no narrative. */
export const DESIGN_INTENT_REFUSAL = Object.freeze({
  FLAG_OFF: 'writer_flag_off',
  NO_EVIDENCE: 'report_evidence_unavailable',
  PROVIDER_FAILED: 'provider_failed',
  VALIDATION_FAILED: 'validation_failed',
  /**
   * The validator PASSED the draft, but no section text could be read from it.
   * A refusal the validator did not make is never filed as a validation failure:
   * this is an acceptance failure, and it is stated as one.
   */
  ACCEPTED_TEXT_MISSING: 'accepted_text_missing',
});

/**
 * The frozen geometry fingerprint a record is saved against, or null where no
 * usable geometry was supplied. Only an AVAILABLE context carries one: a context
 * that could not be confirmed against the saved report never becomes the geometry a
 * narrative is pinned to.
 */
function geometryFingerprintOf(context) {
  return context?.available === true ? (context.fingerprint ?? null) : null;
}

/**
 * The frozen visual identity a record is saved against, or null where the writer was
 * shown no pictures. Only an AVAILABLE selection carries one: a library with no usable
 * image never becomes the image set a narrative is pinned to.
 */
function visualFingerprintOf(context) {
  return context?.available === true ? (context.fingerprint ?? null) : null;
}

/** A refused attempt: no text, no write. */
function refusal(code, detail) {
  return {
    ok: false,
    code,
    reason: code,
    detail: detail || null,
    text: null,
    record: buildDesignIntentRecord({
      status: code === DESIGN_INTENT_REFUSAL.PROVIDER_FAILED
        ? DESIGN_INTENT_STATUS.FAILED
        : DESIGN_INTENT_STATUS.REJECTED,
      rejection: { code, detail: detail || null },
    }),
  };
}

/**
 * The design context the writer is given: the reused ADI interpretation where the
 * frozen engineering snapshot is held, and the designer's own recorded intent as
 * instructions. Neither is a source of figures, and neither is ever copy.
 */
function buildIntentDesignContext({ engineeringSnapshot, project, versions, clientBrief, designerNotes, recordedIntent = [], pack = null }) {
  let interpretation = null;
  if (engineeringSnapshot && typeof engineeringSnapshot === 'object') {
    const built = buildProjectInterpretation({
      snapshot: engineeringSnapshot,
      project: project || null,
      clientBrief: clientBrief || project?.notes || '',
      reportType: 'single',
      versions,
      reportLabel: 'Project Report',
      // The designer's confirmed explanations of design decisions the engineering
      // evidence does not establish. The interpretation's important_design_decisions
      // carries these, so the writer can explain WHY a decision was made without
      // inventing a motivation.
      recordedIntent: Array.isArray(recordedIntent) ? recordedIntent : [],
    });
    if (built && typeof built === 'object') interpretation = built;
  } else if (Array.isArray(recordedIntent) && recordedIntent.length > 0) {
    // Without a frozen engineering snapshot the full ADI interpretation cannot be
    // derived, but the designer's confirmed explanations are still authoritative:
    // carry them as a partial interpretation so the writer receives them in
    // design_decisions. No figure, level, product or performance claim is derived
    // here — the frozen evidence pack remains the sole authority for those, and
    // the prompt's rules enforce it.
    interpretation = { important_design_decisions: recordedIntent };
  }

  return {
    design_interpretation: interpretation
      ? {
        rule: INTERPRETATION_RULE,
        available: true,
        source: VERIFIED_INTERPRETATION_SOURCE,
        view: interpretationView(interpretation, { pack }),
        }
        : null,
        editorial_brief: buildEditorialBrief({ dealerNotes: designerNotes || project?.notes || null }),
  };
}

/**
 * ONE canonical parsed draft, from whatever the provider returned: an
 * already-parsed object is used exactly as it stands, and JSON text (fenced or
 * not) is parsed with the validator's own parser. No second parser exists here,
 * and nothing in this function validates, accepts or writes anything — it only
 * decides which single representation both the validator and the acceptance read
 * are given, so the two can never disagree about the same response.
 *
 * @param {string|Object|null} output — the provider's own returned output
 * @returns {Object|null} the draft, or null when it is not a usable draft
 */
export function canonicalDesignIntentDraft(output) {
  if (output && typeof output === 'object' && !Array.isArray(output)) return output;
  return parseWriterOutput(output).output;
}

/** The accepted section text, or null when the draft carries none. */
export function designIntentTextFromOutput(output) {
  const sections = Array.isArray(output?.sections) ? output.sections : [];
  const entry = sections.find((row) => row?.section === DESIGN_INTENT_SECTION) || null;
  const text = typeof entry?.text === 'string' ? entry.text.trim() : '';
  return text.length > 0 ? text : null;
}

/**
 * Run one attempt.
 *
 * @param {Object} input
 * @param {Object} input.flag — resolveGptWriterFlag output
 * @param {Function} input.readEvidence — async ({ versionIds }) => the frozen report evidence
 * @param {Array<string>} input.versionIds — the version this report documents
 * @param {Function} input.invokeLLM — the server-side provider call
 * @param {Object} [input.project] — the saved project, for its recorded notes
 * @param {Object} [input.engineeringSnapshot] — the frozen engineering snapshot
 * @param {Object} [input.sourceFingerprints] — the evidence the report stands on
 * @param {Function} [input.readGeometryContext] — async ({ evidence, versionIds }) =>
 *   the frozen report geometry context (buildReportGeometryContext output). It is
 *   read AFTER the evidence, because the geometry is confirmed against the saved
 *   report itself. Optional and failure-isolated: a caller that supplies no reader,
 *   or one whose context cannot be confirmed, writes exactly as before.
 * @param {Object} [input.geometryContext] — a context the caller already holds, used
 *   instead of the reader.
 * @param {Function} [input.readVisualContext] — async ({ evidence, versionIds }) =>
 *   the frozen report visual context (buildReportVisualContext output): the Project
 *   Library pictures this design is represented by, chosen by the shared selection
 *   authority. The pictures are attached to the provider request and described to the
 *   writer as visual context only. Optional and failure-isolated, exactly as the
 *   geometry is: a caller that supplies no reader, or one whose selection is empty or
 *   unavailable, writes the text-only narrative the writer has always written.
 * @param {Object} [input.visualContext] — a context the caller already holds, used
 *   instead of the reader.
 * @param {Object} [input.user]
 * @param {string} [input.now]
 * @param {Function} [input.onEvidencePack] — called once with `{ pack, writerInput }`
 *   after the frozen pack and the scoped writer input have been built and before the
 *   provider is called, so a caller can report the exact evidence an attempt wrote
 *   from. Observability only: its failure is swallowed, nothing it returns is read,
 *   and it can neither accept a draft nor refuse one.
 * @param {Function} [input.validate] — injected for tests; the shared validator otherwise
 * @returns {Promise<Object>} the accepted narrative and its record, or a refusal
 */
export async function runReportDesignIntent({
  flag = null,
  readEvidence = null,
  versionIds = [],
  invokeLLM = null,
  project = null,
  engineeringSnapshot = null,
  sourceFingerprints = null,
  clientBrief = null,
  designerNotes = null,
  readGeometryContext = null,
  geometryContext = null,
  readVisualContext = null,
  visualContext = null,
  user = null,
  now = null,
  onEvidencePack = null,
  // The designer's confirmed explanations of design decisions the engineering
  // evidence does not establish. Passed to the interpretation as recorded
  // intent, so the writer can explain WHY a decision was made without inventing
  // a motivation. Empty where no context has been saved.
  recordedIntent = [],
  // The optional free-text Project Context the designer supplied. Carried to the
  // interpretation as additional recorded intent (semantic input the writer may
  // use to explain the project), but NOT added to required_saved_reasons, so the
  // coverage gate never hard-blocks a generation on a free-text note. Null when
  // the designer supplied none.
  projectContext = null,
  // PREPARE ONLY: build the frozen pack and the scoped writer input and stop,
  // making no provider call and writing nothing. It exists so a caller that needs
  // the very same evidence and the very same contract for another purpose — the
  // ADI editorial pass reads them to revalidate improved wording — reads them from
  // this one authority rather than assembling a second evidence path of its own.
  // Default false: every existing caller runs exactly as it always has.
  prepareOnly = false,
  validate = validateWriterOutput,
} = {}) {
  // 1. The writer's own switch, checked before anything is read or sent.
  if (flag?.enabled !== true) {
    return refusal(
      DESIGN_INTENT_REFUSAL.FLAG_OFF,
      'The Astra writer is not enabled for this login. No evidence was read and no provider call was made.',
    );
  }

  const versions = Array.isArray(versionIds) ? versionIds.filter(Boolean) : [];
  if (versions.length === 0 || typeof readEvidence !== 'function') {
    return refusal(DESIGN_INTENT_REFUSAL.NO_EVIDENCE, 'No saved report was supplied to write from.');
  }

  // 2. The frozen report evidence, through the existing read path.
  let evidence = null;
  try {
    evidence = await readEvidence({ versionIds: versions });
  } catch (error) {
    return refusal(DESIGN_INTENT_REFUSAL.NO_EVIDENCE, error?.message || 'The saved report evidence could not be read.');
  }

  // 3. The frozen pack and the scoped writer input.
  let pack = null;
  let writerInput = null;
  let geometry = geometryContext || null;
  let visual = visualContext || null;
  try {
    pack = buildProposalEvidence({ versions: evidence, generatedAt: now });

    // 3a. THE FROZEN GEOMETRY that produced the saved report and its drawings:
    // where the seating actually sits in this room, so the seating decision can be
    // explained in the room's own terms rather than in general ones. It is read
    // AFTER the evidence, because it is confirmed against that saved report, and it
    // is read on its own so a geometry problem can never fail a writing attempt the
    // frozen evidence already supports: with none, the writer is given the pack and
    // the interpretation exactly as before.
    if (!geometry && typeof readGeometryContext === 'function') {
      try {
        geometry = await readGeometryContext({ evidence, versionIds: versions });
      } catch (error) {
        geometry = null;
      }
    }

    // 3b. THE PROJECT LIBRARY'S OWN PICTURES, where this project already holds any:
    // what the cinema is actually meant to look like, so the writer explains a room
    // it has been shown. Read on its own account, exactly as the geometry is, so a
    // library that cannot be read, or a design with no usable image, leaves the
    // attempt writing from the frozen evidence alone. The pictures are EDITORIAL
    // context: the engineering remains the only source of every figure, level,
    // product and result.
    if (!visual && typeof readVisualContext === 'function') {
      try {
        visual = await readVisualContext({ evidence, versionIds: versions });
      } catch (error) {
        visual = null;
      }
    }

    // The optional Project Context is carried to the interpretation as
    // additional recorded intent, so the writer can use it to explain the
    // project. It is NOT added to required_saved_reasons, so the coverage
    // gate never hard-blocks a generation on a free-text note.
    const interpretationIntent = (typeof projectContext === 'string' && projectContext.trim())
      ? [...(Array.isArray(recordedIntent) ? recordedIntent : []), `project_context: ${projectContext.trim()}`]
      : (Array.isArray(recordedIntent) ? recordedIntent : []);
    writerInput = buildDesignIntentWriterInput({
      pack,
      designContext: buildIntentDesignContext({
        engineeringSnapshot,
        project,
        versions,
        clientBrief,
        designerNotes,
        recordedIntent: interpretationIntent,
        pack,
      }),
      geometryContext: geometry,
      visualContext: visual,
      recordedDesignReasons: recordedIntent,
      projectContext: (typeof projectContext === 'string' && projectContext.trim()) ? projectContext.trim() : null,
    });
    assertWriterInputCarriesNoLiveState(writerInput);

    // OBSERVABILITY ONLY, and never a second evidence path: a caller that wants to
    // report which frozen pack this attempt wrote from is handed the very objects the
    // writer was given, after they were built and before the provider is called. It
    // cannot change the attempt — the callback's own failure is swallowed and nothing
    // it returns is read — so reporting can never fail a writing attempt.
    if (typeof onEvidencePack === 'function') {
      try {
        onEvidencePack({ pack, writerInput });
      } catch (error) {
        // Reporting must never fail a writing attempt.
      }
    }
  } catch (error) {
    return refusal(DESIGN_INTENT_REFUSAL.NO_EVIDENCE, error?.message || 'The frozen evidence pack could not be built.');
  }

  // ── PREPARE ONLY: the frozen evidence and the contract, and no writing ──
  // The one place the pack and the scoped writer input exist together is here, so
  // a caller that needs them without a generation takes them from here. Nothing
  // downstream of this line runs: no provider is called, no record is built and
  // nothing is written.
  if (prepareOnly === true) {
    return {
      ok: true,
      prepared: true,
      pack,
      writerInput,
      geometry: geometry || null,
      visual: visual || null,
      project,
      flag,
    };
  }

  // 4. The provider call. A timeout, a refusal or an empty answer is a result.
  // 4. The provider call. A timeout, a refusal or an empty answer is a result. The
  // pictures, where there are any, are attached to this one call: no second model is
  // asked to look at them, and no image is ever uploaded, copied or re-stored.
  let provider = await callWriterProvider({
    invokeLLM,
    input: writerInput,
    model: flag?.model ?? null,
    fileUrls: visualContextSources(visual),
  });
  if (provider.provider_error || !provider.received) {
    return {
      ...refusal(DESIGN_INTENT_REFUSAL.PROVIDER_FAILED, provider.provider_error || 'The provider returned no output.'),
      visual_fingerprint: visualFingerprintOf(visual),
      visual_context: visualContextIdentity(visual),
      record: buildDesignIntentRecord({
        status: DESIGN_INTENT_STATUS.FAILED,
        sourceFingerprints,
        evidencePackFingerprint: pack.pack_fingerprint ?? null,
        inputFingerprint: writerInput.input_fingerprint ?? null,
        geometryFingerprint: geometryFingerprintOf(geometry),
        visualFingerprint: visualFingerprintOf(visual),
        visualContext: visualContextIdentity(visual),
        providerIdentity: {
          provider: provider.provider ?? null,
          model: provider.model ?? null,
          promptVersion: writerInput.prompt_version ?? null,
          contractVersion: writerInput.contract_version ?? null,
          durationMs: provider.duration_ms ?? null,
        },
        generatedAt: now,
        generatedBy: user?.full_name || user?.email || null,
        rejection: { code: DESIGN_INTENT_REFUSAL.PROVIDER_FAILED, detail: provider.provider_error || null },
      }),
    };
  }

  // 5. ONE canonical parsed draft, made once and then used by BOTH the validator
  // and the acceptance read. The provider may return its draft as JSON text
  // (sometimes fenced) or as an already-parsed object, and the validator accepts
  // either — so a second, string-only parse at acceptance read null for a
  // perfectly good object draft and refused it as `accepted_text_missing`. The
  // draft is normalised here, the validator is given that normalised draft, and
  // the accepted text is read from the SAME object, so one response can never be
  // read two ways.
  let canonicalDraft = canonicalDesignIntentDraft(provider.output);
  let validation = validate({ input: writerInput, output: canonicalDraft });
  let coverage = null;
  let correction = null;
  const checkCoverage = async () => {
    if (validation?.valid !== true) return;
    coverage = await reviewDesignIntentCoverage({
      input: writerInput, text: designIntentTextFromOutput(canonicalDraft) || '',
      invokeLLM, model: flag?.model ?? null,
    });
    if (!coverage.valid) validation = { ...validation, valid:false,
      violations:[...(validation.violations || []), ...coverage.violations] };
  };
  await checkCoverage();

  // Reuse the existing bounded correction call: one correction, same model,
  // same frozen input, followed by ALL engineering and coverage checks again.
  const failures = validation?.violations || [];
  const correctable = failures.length > 0 && failures.every(entry =>
    entry.code === CONTEXT_COVERAGE_MISSING || isEligibleForWordingCorrection([entry]).eligible);
  if (correctable) {
    const initialValidation = validation;
    const block = buildCorrectionPromptBlock({ initialOutput:canonicalDraft, violations:failures })
      + '\nDESIGN INTENT ONLY: where a missing saved reason is flagged, add its complete causal meaning in natural prose, using design_intent_scope.required_saved_reasons. The whole decision_summary passage is flagged for that insertion. Keep all other supported meaning, evidence and section structure. Never convert an intended benefit into an achieved result. Remove generic filler if needed to fit the word limit.';
    const corrected = await callWriterProvider({
      invokeLLM, input:writerInput, model:flag?.model ?? null,
      fileUrls:visualContextSources(visual), correction:{ needed:true, block },
    });
    correction = { attempted:true, initial_validation:initialValidation, succeeded:false };
    if (corrected.received && !corrected.provider_error) {
      provider = corrected;
      canonicalDraft = canonicalDesignIntentDraft(provider.output);
      validation = validate({ input:writerInput, output:canonicalDraft });
      coverage = null;
      await checkCoverage();
      correction.succeeded = validation?.valid === true;
    } else {
      validation = { ...initialValidation, valid:false, violations:[{
        code:'design_intent_correction_failed', section:'decision_summary',
        detail:'The writer could not complete the required correction. No narrative was accepted.',
      }] };
    }
  }
  // The validator reports the sections it READ — their word counts and citations —
  // and hands no prose back, so `validation.output` does not exist. A validator
  // that does normalise an output is still honoured first, exactly as before.
  const acceptedDraft = validation?.output ?? canonicalDraft;
  // Read only after the draft has passed every gate: the presence of a text field
  // is never on its own an acceptance.
  const text = validation?.valid === true ? designIntentTextFromOutput(acceptedDraft) : null;
  const provenance = validatorProvenance();

  const providerIdentity = {
    provider: provider.provider ?? null,
    model: provider.model ?? null,
    promptVersion: writerInput.prompt_version ?? null,
    contractVersion: writerInput.contract_version ?? null,
    validatorFingerprint: provenance?.validator_rules_fingerprint ?? null,
    durationMs: provider.duration_ms ?? null,
  };

  if (!text) {
    // WHICH GATE REFUSED IT is stated by the refusal code itself. A draft that
    // passed with no violations and carried no readable section text is an
    // acceptance failure, not a validation failure — so a record can never again
    // read "validation failed" beside a validation that passed.
    const passedValidation = validation?.valid === true;
    const first = Array.isArray(validation?.violations) ? validation.violations[0] : null;
    const code = passedValidation
      ? DESIGN_INTENT_REFUSAL.ACCEPTED_TEXT_MISSING
      : DESIGN_INTENT_REFUSAL.VALIDATION_FAILED;
    const detail = passedValidation
      ? `The validator passed this draft with no violations, but no text could be read for the ${DESIGN_INTENT_SECTION} section, so nothing was saved.`
      : (first ? `${first.rejection || first.code || 'rejected'}${first.detail ? `: ${first.detail}` : ''}` : 'The draft was not validated.');

    return {
      ...refusal(code, detail),
      validation_errors: validation?.violations || [],
      // ── The refused attempt, kept whole so it can be read back ──
      // The exact validation response and the draft it refused travel back with
      // the refusal, so a later reading of it states the rule, the offending
      // sentence, the evidence reference and the draft itself rather than a
      // summary of them. Diagnostics only: neither is stored, neither is
      // displayed, nothing is read back out of either, and the caller alone
      // decides who may be shown them.
      validation: validation || null,
      coverage,
      correction,
      draft: provider.output ?? null,
      provider_identity: providerIdentity,
      visual_fingerprint: visualFingerprintOf(visual),
      visual_context: visualContextIdentity(visual),
      evidence_pack_fingerprint: pack.pack_fingerprint ?? null,
      input_fingerprint: writerInput.input_fingerprint ?? null,
      record: buildDesignIntentRecord({
        status: DESIGN_INTENT_STATUS.REJECTED,
        sourceFingerprints,
        evidencePackFingerprint: pack.pack_fingerprint ?? null,
        inputFingerprint: writerInput.input_fingerprint ?? null,
        // The geometry this attempt was written from, recorded even where the draft
        // was refused: what an attempt read is part of what happened.
        geometryFingerprint: geometryFingerprintOf(geometry),
        visualFingerprint: visualFingerprintOf(visual),
        visualContext: visualContextIdentity(visual),
        providerIdentity,
        generatedAt: now,
        generatedBy: user?.full_name || user?.email || null,
        rejection: { code, detail },
      }),
    };
  }

  const record = buildDesignIntentRecord({
    status: DESIGN_INTENT_STATUS.ACCEPTED,
    text,
    sourceFingerprints,
    evidencePackFingerprint: pack.pack_fingerprint ?? null,
    inputFingerprint: writerInput.input_fingerprint ?? null,
    // THE FROZEN GEOMETRY, saved with the accepted narrative: the room and the seat
    // coordinates the explanation of this design's seating was written from. A
    // narrative written before a seat or a wall moved is never presented as current.
    geometryFingerprint: geometryFingerprintOf(geometry),
    // THE PICTURES the narrative was written from, frozen with the words: which
    // renders, at which revision of each file, stood for this design when it was
    // written. A narrative written from an earlier image set is never presented as
    // current once the designer has replaced them.
    visualFingerprint: visualFingerprintOf(visual),
    visualContext: visualContextIdentity(visual),
    providerIdentity,
    generatedAt: now,
    generatedBy: user?.full_name || user?.email || null,
  });

  record.design_context_coverage = coverage;
  record.correction = correction;
  return {
    ok: true,
    coverage,
    correction,
    validation,
    code: null,
    reason: null,
    detail: null,
    text,
    record,
    validation_errors: validation?.violations || [],
    evidence_pack_fingerprint: pack.pack_fingerprint ?? null,
    input_fingerprint: writerInput.input_fingerprint ?? null,
    geometry_fingerprint: geometryFingerprintOf(geometry),
    visual_fingerprint: visualFingerprintOf(visual),
    visual_context: visualContextIdentity(visual),
    prompt_version: writerInput.prompt_version ?? null,
    contract_version: writerInput.contract_version ?? null,
    provider: provider.provider ?? null,
    model: provider.model ?? null,
    duration_ms: provider.duration_ms ?? null,
  };
}

export default runReportDesignIntent;