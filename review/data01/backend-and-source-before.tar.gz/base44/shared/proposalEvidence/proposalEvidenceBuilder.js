/**
 * proposalEvidenceBuilder.js (shared)
 * -----------------------------------
 * THE builder of the frozen proposal evidence pack.
 *
 * Input:  the saved-report evidence of each selected version, exactly as
 *         `readProposalReportEvidence` returns it (that reader reads each
 *         version's own Visual and Technical Report snapshots and nothing else).
 * Output: one frozen pack carrying the facts, the deterministic classification of
 *         every major design area, the materiality note behind each difference,
 *         the claims a writer may make, the claims it may not, and the decision
 *         framing the evidence supports.
 *
 * What this builder deliberately does NOT do:
 *   - it does not read the live project, a session handoff or browser storage;
 *   - it does not call an LLM, and no part of this pack is written by one;
 *   - it does not calculate, estimate or infer any engineering result.
 * Every fact it carries is copied from the report evidence it was given, and
 * every claim it allows was classified from that evidence first. A writer's job
 * is to turn this pack into prose, and to claim nothing else.
 *
 * Four safety rules are enforced here and nowhere else:
 *
 *   1. every client-facing version name comes from the saved report evidence
 *      (proposalEvidenceIdentity), and a version whose evidence states no name
 *      blocks the pack rather than being named from live state;
 *   2. the room is classified explicitly — same, different or not comparable —
 *      from the room facts the reports state (proposalEvidenceClassification);
 *   3. the decision framing is allowed only where the whole shared design is
 *      confirmed and P20 does not contradict it (proposalEvidenceDesignClaims);
 *   4. no prohibited seat-to-seat bass consistency wording survives anywhere in
 *      the pack, and the pack is not returned until that is proven
 *      (proposalEvidenceWording).
 *
 * Pure: no React, no SDK, no runtime-specific APIs.
 */

import { optionLabel } from '../comparisonEvidence.js';
import {
  BLOCK_REASON,
  PROPOSAL_EVIDENCE_SCHEMA_VERSION,
  PROPOSAL_EVIDENCE_AREAS,
} from './evidencePackSchema.js';
import {
  ASSUMED_PARAMETER_LABEL,
  EXCLUDED_CLIENT_PARAMETER_CODES,
  buildExcludedParameterPolicy,
  buildRequestedAssumptionRule,
} from '../clientFacingParameterAuthority.js';
import { buildOptionFacts } from './proposalEvidenceFacts.js';
import { buildNarrativePriorityRows } from '../narrativePriorityAuthority.js';
import { readScopedSeatLevels } from '../seatScopeNarrativeAuthority.js';
import { summaryFromReportEvidence } from '../strengthImportance.js';
import { buildClientStoryPillars } from '../narrativePillarGrouping.js';
import {
  buildProposalNarrativeContext,
  designContainmentFromFacts,
  readDesignShape,
  resolveBriefIntent,
} from '../proposalNarrativeContext.js';
import { classifyAreas } from './proposalEvidenceClassification.js';
import {
  buildAllowedClaims,
  buildBlockedClaims,
  buildMaterialityNotes,
} from './proposalEvidenceClaims.js';
import {
  buildBassClaims,
  buildDecisionFraming,
  buildDesignClaims,
  emptyBassClaims,
} from './proposalEvidenceDesignClaims.js';
import { buildScopedSeatClaims } from './proposalEvidenceSeatScopes.js';
import { buildProposalStrengthStories } from './proposalStrengthStories.js';
import { buildSupportingResultClaims } from './proposalSupportingResults.js';
import { assertBassWordingSafe } from './proposalEvidenceWording.js';

/** Deterministic key order, so the same content always serialises identically. */
function canonicalise(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value ?? null);
  if (Array.isArray(value)) return `[${value.map(canonicalise).join(',')}]`;
  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalise(value[key])}`).join(',')}}`;
}

/** A stable 32-bit fingerprint of a string. */
function fnv1a(text) {
  let hash = 0x811c9dc5;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, '0');
}

/**
 * The DIRECT published evidence of one version, keyed by parameter: the result each
 * parameter states, with the seat scopes the saved reports themselves state.
 *
 * This is what the narrative grouping reads to decide whether a result EXISTS. It
 * creates nothing: a parameter whose row states no level and whose scope states none
 * is absent rather than filled in, and a level is copied exactly as the report
 * published it.
 *
 * @param {Object|null} reportEvidence — one version's frozen Project Report evidence
 * @param {Object|null} seatScopes — that evidence's own `seat_scopes` block
 * @returns {Object} map of parameter key → { level, value, seat results }
 */
function parameterEvidenceFrom(reportEvidence = null, seatScopes = null) {
  const out = {};
  for (const row of (Array.isArray(reportEvidence?.parameters) ? reportEvidence.parameters : [])) {
    const id = Number(row?.parameter_id);
    if (!Number.isFinite(id)) continue;
    out[`p${id}`] = {
      key: `p${id}`,
      level: /^L[1-4]$/.test(String(row?.level ?? '')) ? String(row.level) : null,
      value: row?.value ?? null,
    };
  }
  for (const [key, scoped] of Object.entries(readScopedSeatLevels(seatScopes))) {
    const entry = out[key] || (out[key] = { key, level: null, value: null });
    entry.primary_seat_result = scoped.primary ?? null;
    entry.secondary_seat_result = scoped.secondary ?? null;
    entry.all_seat_result = scoped.all ?? null;
    entry.seat_count = scoped.seat_count || null;
    // A parameter the reports assess at the seats has a published result even where
    // its own row states the narrower one.
    if (entry.level == null && scoped.all) entry.level = scoped.all;
  }
  return out;
}

/**
 * The pack's content fingerprint. It covers the evidence and the reading of it,
 * never the time the pack was minted, so the same evidence always produces the
 * same fingerprint and any change to the evidence changes it.
 */
export function proposalEvidenceFingerprint(pack) {
  if (!pack || typeof pack !== 'object') return null;
  const { generated_at: _generatedAt, pack_fingerprint: _fingerprint, ...content } = pack;
  return fnv1a(canonicalise(content));
}

/**
 * Build the frozen proposal evidence pack.
 *
 * @param {Object} input
 * @param {Array<Object>} input.versions — readProposalReportEvidence output, in
 *   report order (Option A first)
 * @param {string} [input.generatedAt] — the timestamp to record (an ISO string)
 * @param {Object} [input.requestContext] — the designer's explicit requests
 *   ({ clientBrief, narrativeBrief, dealerNotes }) or an already resolved
 *   exclusion policy. It is the ONLY thing that can admit an assumed parameter
 *   (P8, P15, P21), and only as a labelled assumption.
 * @returns {Object} the frozen pack
 */
export function buildProposalEvidence({
  versions = [],
  generatedAt = null,
  requestContext = null,
  narrativeContext = null,
} = {}) {
  const list = (Array.isArray(versions) ? versions : []).filter(Boolean);
  if (list.length === 0) {
    throw new Error('No version report evidence was supplied. Select at least one version with a current Project Report.');
  }

  // THE PROJECT'S OWN CONTEXT, read once for the whole pack: the declared intent, the
  // room type, the subjects the brief and the steer name, and the subjects the steer
  // keeps out. Without one the context is empty and the classification falls back to
  // its own defaults — a pack built with no context is never given an invented one.
  const context = narrativeContext ? { ...narrativeContext } : buildProposalNarrativeContext({});
  // The seating subject the designer steered away, where they did. It silences the
  // seating rationale and the seat-consistency claim together, and it silences
  // nothing else: the bass output, depth and control results are untouched.
  const seatingSubjectSuppressed = (Array.isArray(context.suppressed_areas) ? context.suppressed_areas : [])
    .includes('client_experience');

  // The ONE assumed-parameter admission rule for this proposal. With no request
  // context every assumed parameter stays excluded, exactly as before.
  const policy = typeof requestContext?.allows === 'function'
    ? requestContext
    : buildExcludedParameterPolicy(requestContext || {});

  const options = list.map((entry, index) => buildOptionFacts(entry, optionLabel(index), { policy }));

  // ── RANKED STRENGTH STORIES (the ONE shared authority) ──
  // Each version's strengths are read from its canonical Project Report evidence
  // by the same authority the report page uses. The writer is GIVEN this ranked
  // list: it never decides which parameters matter. Ranking, canonical weights and
  // internal tier labels stay inside the authority — only the ordered stories,
  // their evidence and one claim each travel onward.
  const storyClaims = [];
  const storiesByVersion = new Map();
  list.forEach((entry, index) => {
    const reportEvidence = entry?.evidence?.project || null;
    const { strength_stories, omitted_stories } = buildProposalStrengthStories(reportEvidence);
    const option = options[index];
    const claims = strength_stories.map((story) => {
      const claim = {
        claim_id: `claim_story_${story.story_id}_01`,
        area: story.category || 'design',
        label: story.title,
        kind: 'strength_story',
        statement: story.statement,
        option: { version_id: option.version_id, version_name: option.version_name, label: option.label },
        favours: false,
        scope: story.scope,
        seat_count: null,
        level: story.level,
        wording_class: 'strength',
        wording: story.statement,
        basis: { levels: story.level ? [story.level] : [] },
      };
      story.allowed_claim_ids = [claim.claim_id];
      return claim;
    });
    storiesByVersion.set(option.version_id, { strength_stories, omitted_stories });
    storyClaims.push(...claims);
  });

  // ── ONE STORY PER PILLAR, FROM THE EVIDENCE BENEATH IT (the ONE shared grouping) ──
  // The ranked stories above are evidence FRAGMENTS: several of them describe the
  // same experience the client is choosing, and the three pillars — Dynamic Range,
  // Spatial Resolution and Timbre Matching — are what that evidence is told
  // through. The bass is the clearest case: output, depth, control and consistency
  // are ONE Dynamic Range story, so the writer never writes a paragraph per
  // parameter. This reads the same classified evidence as the ranking, and it
  // changes no figure, level, scope or claim: the stories' own claim IDs travel
  // with the pillar they belong to.
  //
  // TWO SOURCES, EACH THE AUTHORITY FOR ITS OWN HALF. The classified rows decide
  // emphasis, relevance and role, read under THIS project's intent, room type and
  // steer. The direct parameter evidence — the published result of each parameter,
  // with the seat scopes the reports themselves state — decides whether a result
  // exists and what it states. A priority can therefore say "say little about this";
  // it can never say "this published result does not exist".
  // The supporting results are minted from the options' frozen facts before the
  // pillars are read, so Dynamic Range can cite its output evidence (Parameters
  // 12, 13 and 14) whether or not a headline story or the brief names them.
  const supporting = buildSupportingResultClaims({ options, requestContext });

  const pillarsByVersion = new Map();
  const contextByVersion = new Map();
  let narrativeReading = null;
  list.forEach((entry, index) => {
    const reportEvidence = entry?.evidence?.project || null;
    const option = options[index];
    const stories = (storiesByVersion.get(option.version_id) || {}).strength_stories || [];
    const shape = readDesignShape(option.facts, reportEvidence);
    const intent = resolveBriefIntent({
      declaredIntent: context.declared_intent,
      roomType: context.room_type,
      briefText: context.brief_text,
      facts: option.facts,
      shape,
    });
    const seatScopes = reportEvidence?.seat_scopes || null;
    const { rows, brief } = buildNarrativePriorityRows({
      summary: summaryFromReportEvidence(reportEvidence),
      intent,
      subjects: context.subjects,
      briefText: context.brief_text,
      design: designContainmentFromFacts(option.facts),
      excludedTopics: context.excluded_topics,
      suppressedAreas: context.suppressed_areas,
      seatScopes,
    });
    const parameterEvidence = parameterEvidenceFrom(reportEvidence, seatScopes);
    const reading = buildClientStoryPillars({
      rows,
      stories,
      parameterEvidence,
      supportingClaims: supporting.claims.filter((claim) => claim?.option?.version_id === option.version_id),
      context: {
        intent,
        room_type: context.room_type,
        intended_use: context.declared_intent,
        suppressedAreas: context.suppressed_areas || [],
      },
    });
    pillarsByVersion.set(option.version_id, reading.pillars);
    // The seating design rationale (RP22 P1): the reason the seating sits where it
    // does, grounded by the seating story's own claim where the pack mints one, and
    // suppressed entirely when the designer steered the seating subject away.
    const seatingClaimIds = stories
      .filter((story) => /seating|clearance/i.test(`${story?.story_id || ''} ${story?.title || ''}`))
      .flatMap((story) => (Array.isArray(story?.allowed_claim_ids) ? story.allowed_claim_ids : []));
    contextByVersion.set(option.version_id, {
      intent,
      intent_basis: shape,
      room_type: context.room_type,
      intended_use: context.declared_intent,
      preferred_topics: context.preferred_topics || [],
      excluded_topics: context.excluded_topics || [],
      suppressed_areas: context.suppressed_areas || [],
      brief_relevance: brief?.byArea || null,
      brief_reasons: brief?.reasons || null,
      source: context.source || null,
    });
    const rationale = reading.design_rationale || null;
    option.design_rationale = rationale ? { ...rationale, claim_ids: seatingClaimIds } : null;
    if (!narrativeReading) narrativeReading = contextByVersion.get(option.version_id);
  });

  // ── THE SUPPORTING RESULTS THE BRIEF ASKED FOR ──
  // A brief that asks for a result — the bass extension, the screen-channel
  // output, the difference between the front and rear rows — is asking for a
  // result the saved reports already state, which the ranked strength stories
  // correctly leave out when it is not one of the design's strongest. Those
  // results are minted here, from the frozen facts alone, at the exact scope and
  // status the reports record, and they are never strengths. A request the
  // evidence cannot answer mints nothing and is recorded as omitted.
  const compared = options.length >= 2;

  const classification = compared ? classifyAreas(options.map((option) => option.areas)) : [];
  const decisionFraming = compared
    ? buildDecisionFraming(classification, options)
    : { allowed: false, reason: 'single_option', text: null, evidence: {} };

  // The area claims first, then the whole-design claims, which rest on them: a
  // credibility claim on the shared format, a recommendation on the framing.
  const allowedClaims = [
    ...(compared
      ? [
        ...buildAllowedClaims(classification, options),
        ...buildDesignClaims(classification, options, decisionFraming),
      ]
      : []),
    // The scoped seat-group claims: a result the saved evidence states for the
    // primary or the secondary seats, at a level that carries a positive
    // adjective. Minted per option for EVERY proposal, single or compared: the seats
    // the client actually uses are stated whichever way the design was chosen, and a
    // scope is only ever claimed where the evidence states that scope's own level
    // and the scope holds at least two seats. An all-seat result mints nothing here,
    // so a whole-room consistency claim can never be written from a seat-group one.
    // A scoped claim for the subject the designer steered away is dropped with the
    // rest of that subject's narrative: the seat-consistency claim belongs to the
    // seating subject, so a seating do-not-discuss states it nowhere.
    ...options.flatMap((option, index) => buildScopedSeatClaims(option, index))
      .filter((claim) => !(claim.area === 'p20' && seatingSubjectSuppressed)),
    // One claim per ranked strength story, for every option. A story claim is the
    // sentence a writer may state for that story, and its ID is the only claim ID
    // that story carries.
    ...storyClaims,
    // The results the brief asked for, at their own scope and status. Stated
    // because the client asked for them, never presented as strengths.
    ...supporting.claims,
  ];

  const bassClaims = compared
    ? buildBassClaims(classification, options, allowedClaims)
    : emptyBassClaims();
  const blockedClaims = buildBlockedClaims(classification, options, decisionFraming, bassClaims);

  // The assumed-parameter rule, minted once: an assumed or administrative check
  // is never a performance result, a differentiator or a headline claim.
  const assumedBlocks = [{
    block_id: 'block_global_no_assumed_parameter_differentiator_01',
    scope: 'global',
    area: null,
    reason: BLOCK_REASON.NO_ASSUMED_PARAMETER_DIFFERENTIATOR,
    prohibited: policy.requested.length === 0
      ? 'Never reference an assumed or administrative parameter (P8 upfiring/elevation speakers, P15 background noise floor, P21 early reflections): none was requested for this proposal.'
      : `Never present ${policy.requested.join(', ')} as a performance result, a differentiator or a headline claim: ${policy.requested.length > 1 ? 'they are' : 'it is'} an ${ASSUMED_PARAMETER_LABEL} only.`,
    detail: policy.requested.length > 0 ? `requested:${policy.requested.join(',')}` : null,
  }];

  // The bass consistency rule is minted once, in the packed rule list; the bass
  // contract points at that same block instead of minting a second id for it.
  const bass = {
    ...bassClaims,
    blocked: (bassClaims.blocked || []).map((entry) => ({
      ...entry,
      block_id: blockedClaims.find((block) => block.area === 'p20' && block.reason === entry.reason)?.block_id
        || entry.block_id,
    })),
    removed_wording: options.flatMap((option) => (option.wording_removed || [])
      .map((entry) => ({ version_id: option.version_id, ...entry }))),
  };

  const pack = {
    schema_version: PROPOSAL_EVIDENCE_SCHEMA_VERSION,
    generated_at: generatedAt || new Date().toISOString(),
    mode: compared ? 'comparison' : 'single',
    areas: PROPOSAL_EVIDENCE_AREAS.map((area) => ({
      area: area.key,
      label: area.label,
      kind: area.kind,
      structure: area.structure,
    })),
    options: options.map((option) => ({
      version_id: option.version_id,
      version_name: option.version_name,
      label: option.label,
      version_name_source: option.version_name_source,
      facts: option.facts,
      // The ranked strength stories this version's canonical Project Report
      // supports, and the deterministic record of the strengths it deliberately
      // did not state, each with its reason. No weight, tier or score travels.
      strength_stories: (storiesByVersion.get(option.version_id) || {}).strength_stories || [],
      omitted_stories: (storiesByVersion.get(option.version_id) || {}).omitted_stories || [],
      // The pillar stories this version's evidence tells: one entry per pillar, the
      // same results the ranked stories rest on, read together. The ranking still
      // decides emphasis; this decides only what is told as one story.
      client_story_pillars: pillarsByVersion.get(option.version_id) || [],
      // The seating design rationale (RP22 P1): why the seating sits where it does,
      // available whether its result is high or low, and suppressed entirely when the
      // designer steered the seating subject away. It is a design reason, never a
      // performance result.
      design_rationale: option.design_rationale || null,
      // The context this version's evidence was classified under, so a reader can see
      // WHY a result was weighted as it was: the intent, the room type, the brief
      // relevance of each area and the subjects the steer kept out.
      narrative_context: contextByVersion.get(option.version_id) || null,
    })),
    classification,
    // Which supporting results the brief asked for, which of them the frozen
    // facts stated, and which of them the evidence could not answer, with the
    // reason. A request that mints nothing is visible here rather than silent.
    supporting_results: supporting.audit,
    materiality_notes: buildMaterialityNotes(allowedClaims, { p20Note: bass.note }),
    allowed_claims: allowedClaims,
    blocked_claims: policy.requested.length > 0 ? [...blockedClaims, ...assumedBlocks] : blockedClaims,
    // The assumed-parameter rule this pack was built under: which of P8, P15 and
    // P21 the designer explicitly asked for, and how they may be used. Every
    // proposal-facing boundary reads this rather than deciding for itself. It is
    // carried only when something WAS requested, so a pack built with no request
    // is byte-identical to the pack that excludes the three by default.
    ...(policy.requested.length > 0 ? {
      assumed_parameter_policy: {
        assumed: [...EXCLUDED_CLIENT_PARAMETER_CODES],
        excluded: policy.excluded.map((entry) => entry.code),
        requested: [...policy.requested],
        label: ASSUMED_PARAMETER_LABEL,
        rule: buildRequestedAssumptionRule(policy.requested),
      },
    } : {}),
    bass_claims: bass,
    decision_framing: decisionFraming,
    // The audit spine of the pack: which saved reports it was built from, where
    // each client-facing version name came from, and the fingerprints those
    // reports were generated against. Every name is the saved evidence's own.
    evidence_basis: {
      sources: ['saved-report-evidence'],
      version_names: options.map((option) => ({
        version_id: option.version_id,
        ...(option.version_name_source || {}),
      })),
      report_snapshot_ids: options.map((option) => ({
        version_id: option.version_id,
        project_report_snapshot_id: option.facts?.report_snapshot_ids?.project ?? null,
        visual_report_snapshot_id: option.facts?.report_snapshot_ids?.visual ?? null,
        technical_report_snapshot_id: option.facts?.report_snapshot_ids?.technical ?? null,
      })),
      fingerprints: options.map((option) => ({
        version_id: option.version_id,
        engineering: option.facts?.fingerprints?.engineering ?? null,
        visual_evidence: option.facts?.fingerprints?.visual_evidence ?? null,
        technical_evidence: option.facts?.fingerprints?.technical_evidence ?? null,
      })),
    },
  };

  // The pack's final gate. Every report-sourced string has already been cleaned,
  // and this proves the pack as a whole carries no prohibited bass claim — its
  // own rule text included — before it can reach a writer.
  return assertBassWordingSafe({ ...pack, pack_fingerprint: proposalEvidenceFingerprint(pack) });
}

export default buildProposalEvidence;