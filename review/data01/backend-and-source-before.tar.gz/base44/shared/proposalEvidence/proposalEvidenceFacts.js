/**
 * proposalEvidenceFacts.js (shared)
 * ---------------------------------
 * The FACTS half of the frozen proposal evidence pack.
 *
 * Every fact here is copied from one version's saved-report evidence — the
 * snapshot `readProposalReportEvidence` assembles from that version's own
 * Visual and Technical Report snapshots. It reads nothing else: no live project
 * record, no browser-session handoff, no recalculation, no fallback to another
 * module's idea of the design. If a report does not state something, the fact is
 * null, and the area it belongs to is then not comparable rather than filled in.
 *
 * Excluded parameters (P8, P15, P21) are filtered out here, by the existing
 * report rule, so they cannot enter the pack at all.
 *
 * Two further rules apply before a fact is frozen:
 *
 *   - the version name comes from the saved report evidence, never from live
 *     project state (see proposalEvidenceIdentity);
 *   - no prohibited seat-to-seat bass consistency wording survives anywhere in a
 *     fact, wherever a report wrote it (see proposalEvidenceWording).
 *
 * Pure: no React, no SDK, no runtime-specific APIs.
 */

import { isReportParameter, structureForParameter, plainLanguageName } from '../adiReportEvidenceRules.js';
import {
  ASSUMED_PARAMETER_LABEL,
  isAssumedAdministrativeParameter,
} from '../clientFacingParameterAuthority.js';
import { readCapabilityFields } from '../parameterCapabilityFields.js';
import { savedVersionIdentity } from './proposalEvidenceIdentity.js';
import { stripBassWordingDeep } from './proposalEvidenceWording.js';
import { frozenClientSystemFormat } from '../clientSystemFormat.js';

const NONE = 'None specified';

function asText(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

/** An evidence value as readable text. Never stringifies a wrapped object. */
function valueText(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'object') {
    return asText(value.statement) || asText(value.display_value) || asText(value.formatted_value);
  }
  return String(value);
}

/** A stated number, or null. An unstated dimension is never read as zero. */
function numericOrNull(value) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

/** The room as the Visual Report states it: its dimensions, and the text for them. */
function roomReading(room) {
  const dimensions = room?.dimensions || {};
  const values = [dimensions.length_m, dimensions.width_m, dimensions.height_m].map(numericOrNull);
  const stated = asText(room?.dimensions_text);
  const text = stated || (values.every((value) => value !== null) ? `${values.join(' x ')} m` : null);
  if (!text) return null;
  return {
    text,
    dimensions: { length_m: values[0], width_m: values[1], height_m: values[2] },
  };
}

/**
 * The short system format as the client reads it ("9.3.6" — the design's own
 * bed, subwoofer and overhead channels), never the decoder notation.
 *
 * The configuration's own client-facing text is the statement; the decoder
 * layout is only the fallback for a report saved before the format existed.
 * Nothing internal changes: the decoder layout stays on the design and in the
 * analysis, it is simply not the format the client is told.
 */
function formatText(system) {
  return frozenClientSystemFormat(system)
    || asText(system?.configuration?.text)
    || asText(system?.configuration?.dolby_config);
}

/** The screen as the Visual Report states it, in the comparison table's words. */
function screenText(screen) {
  if (screen?.display_type === 'tv') return asText(screen.display_label);
  if (screen?.manual_dimensions === true && screen?.manual_width_m) {
    return screen.manual_height_m
      ? `${screen.manual_width_m}m x ${screen.manual_height_m}m (manual)`
      : `${screen.manual_width_m}m (manual)`;
  }
  if (screen?.size_inches) {
    return screen.aspect_ratio ? `${screen.size_inches}" (${screen.aspect_ratio})` : `${screen.size_inches}"`;
  }
  return null;
}

/** The seating as the Visual Report states it, or its own seat and row counts. */
function seatingText(seating) {
  const interpretation = asText(seating?.interpretation);
  if (interpretation) return interpretation;
  const seats = Number(seating?.seat_count);
  const rows = Number(seating?.row_count);
  if (!Number.isFinite(seats) || seats <= 0) return null;
  const rowText = Number.isFinite(rows) && rows > 0 ? ` in ${rows} row${rows === 1 ? '' : 's'}` : '';
  return `${seats} seat${seats === 1 ? '' : 's'}${rowText}`;
}

/** The client-facing system format, with its discrete channel count when the report states it. */
function layoutText(system) {
  const text = frozenClientSystemFormat(system)
    || asText(system?.configuration?.text)
    || asText(system?.configuration?.dolby_config);
  const total = Number(system?.channel_layout?.total_discrete);
  const channels = Number.isFinite(total) && total > 0 ? `${total} discrete channels` : null;
  if (!text) return channels;
  return channels ? `${text} (${channels})` : text;
}

/** The amplification this version specifies, or null when the report states none. */
function amplificationText(system) {
  const value = system?.amplification;
  if (!value) return null;
  if (value.specified === true && Number.isFinite(Number(value.power_w))) return `${Number(value.power_w)} W`;
  return null;
}

/** The loudspeaker each position is delivered with, from the report's own roles. */
function roleText(system) {
  const roles = Array.isArray(system?.product_roles) ? system.product_roles : [];
  const lines = [];
  for (const role of roles) {
    // A role that states its own equipment wording (the dual-centre cabinets
    // count and what they are) prints that wording rather than the bare model.
    const model = asText(role?.model_statement)
      || asText(role?.model_label) || asText(role?.model_key) || asText(role?.model);
    if (!model) continue;
    const label = asText(role?.role_description) || asText(role?.role);
    const line = label ? `${label}: ${model}` : model;
    if (!lines.includes(line)) lines.push(line);
  }
  return lines.length > 0 ? lines.join(' · ') : null;
}

/**
 * The screen stage when the design builds its centre channel from two physical
 * cabinets.
 *
 * Stated as its own fact, in physical terms, so the one centre channel a Dolby
 * layout has can never be read as one centre loudspeaker of the left/right
 * model: two cabinets, one channel, layout unchanged. Null for every other
 * design, so nothing is added to a single-centre pack.
 */
function frontStageFact(system) {
  const roles = Array.isArray(system?.product_roles) ? system.product_roles : [];
  const centre = roles.find((role) => asText(role?.structure) === 'dual-centre'
    || (Number(role?.cabinet_count) > 1 && asText(role?.role) === 'centre'));
  if (!centre) return null;
  const leftRight = roles.find((role) => asText(role?.role) === 'front_left_right');
  const cabinets = Number(centre.cabinet_count) || 2;
  return {
    structure: 'dual_centre',
    physical_centre_cabinets: cabinets,
    logical_centre_channels: Number(centre.channel_count) || 1,
    left_right: asText(leftRight?.model_statement) || asText(leftRight?.model_label) || null,
    centre: asText(centre.model_statement) || asText(centre.model_label) || null,
    screen_positions: [
      { position: 'front_left_right', model: asText(leftRight?.model_statement) || asText(leftRight?.model_label) || null },
      { position: 'centre', model: asText(centre.model_statement) || asText(centre.model_label) || null },
    ].filter((position) => position.model),
    note: `${cabinets} physical centre cabinets are fed from ONE logical centre channel. The centre is not a second channel, the left and right channels keep their own model, and the layout is unchanged.`,
  };
}

/** The printed Products Selected rows, exactly as the Technical Report states them.
 *  A layer the design does not have states no product, so its row is omitted
 *  entirely: the proposal is never told to describe a category the system was
 *  never specified with, and never states "None specified". */
function productRows(snapshot) {
  const rows = snapshot?.system?.products_selected?.rows;
  return (Array.isArray(rows) ? rows : [])
    .map((row) => ({
      key: row?.key || null,
      area: asText(row?.area) || asText(row?.key) || null,
      value: asText(row?.value) || null,
    }))
    .filter((row) => row.value && row.value !== NONE);
}

/**
 * The report's parameter rows. Excluded parameters (P8, P15, P21) are filtered
 * out here, by the existing report rule, so they cannot enter the pack at all —
 * unless the designer explicitly asked for one, in which case it is carried as a
 * labelled assumption and never as a client-facing result.
 */
function parameterRows(snapshot, policy = null) {
  const rows = Array.isArray(snapshot?.report_parameters) ? snapshot.report_parameters : [];
  return rows
    .map((row) => {
      const id = Number(row?.parameter_id);
      if (!Number.isFinite(id)) return null;
      const assumedRequested = isAssumedAdministrativeParameter(id)
        && policy?.allows?.(`P${id}`) === true;
      if (!isReportParameter(id) && !assumedRequested) return null;
      const level = asText(row.level);
      const value = valueText(row.value);
      const entry = {
        parameter_id: id,
        key: asText(row.key) || `P${id}`,
        label: plainLanguageName(id, row.title),
        structure: assumedRequested ? null : structureForParameter(id),
        level,
        value,
        text: asText(row.text) || [level, value].filter(Boolean).join(' · ') || null,
        // The scope, the state and the authority the report states this result
        // at, copied exactly and carried as its own fields. A supporting result
        // states its scope and its prediction status from these, so a
        // reference-position result can never be written as a seat-wide one.
        // The row's own free-text context is NOT carried: it holds the grade
        // ladder's other values, which are not this design's results.
        scope: asText(row.scope),
        state: asText(row.state),
        authority_source: asText(row.source),
        definition: asText(row.title),
        // The authoritative capability fields, present only where the report states them.
        ...readCapabilityFields(row),
      };
      // An assumed parameter carries no client-facing structure, so it can never
      // be classified, can never become a difference between options, and is
      // always stated with the assumption label it was admitted under.
      if (assumedRequested) {
        entry.kind = 'assumed_parameter';
        entry.assumption_label = ASSUMED_PARAMETER_LABEL;
      }
      return entry;
    })
    .filter(Boolean);
}

/**
 * The reading each major design area carries for this one version, or null where
 * the reports do not state it. This is what the classification compares.
 */
function areaReadings({ room, screen, seating, viewing, system, parameters, products }) {
  const byLayer = new Map(products.map((row) => [row.key, row.value]));
  const byParameter = new Map(parameters.map((row) => [`p${row.parameter_id}`, row]));

  const readings = {
    room: roomReading(room),
    screen_size: screenText(screen),
    system_layout: layoutText(system),
    seating: seatingText(seating),
    speakers: roleText(system),
    amplification: amplificationText(system),
  };

  readings.rp23_viewing = viewing?.available === true && asText(viewing?.summary)
    ? { level: asText(viewing?.primary_floor), text: asText(viewing.summary) }
    : null;

  for (const key of ['lcr', 'surrounds', 'overheads', 'subwoofers', 'acoustic_treatment']) {
    readings[key] = byLayer.get(key) || null;
  }

  for (const [key, row] of byParameter) {
    readings[key] = { level: row.level, value: row.value, text: row.text };
  }

  return readings;
}

/**
 * One option's facts, as the pack freezes them.
 *
 * @param {Object} entry — one readProposalReportEvidence result
 * @param {string} label — the option label this version is given ("Option A")
 * @returns {{ version_id, version_name, version_name_source, label, facts, areas, wording_removed }}
 */
export function buildOptionFacts(entry, label, { policy = null } = {}) {
  const snapshot = entry?.snapshot;
  const versionId = entry?.version_id || snapshot?.identity?.versionId || null;
  if (!versionId) throw new Error('A selected version could not be identified from its report evidence.');
  if (!snapshot) throw new Error(`No saved report evidence was supplied for version ${versionId}.`);

  // The name this version is described by is the name its saved reports were
  // generated under. It is never read from the live ProjectVersion record, and a
  // version whose saved evidence states no name is not put in a pack at all.
  const versionIdentity = savedVersionIdentity(entry, versionId);
  const versionName = versionIdentity.version_name;

  const identity = snapshot.identity || {};
  const room = snapshot.room || {};
  const screen = room.screen || {};
  const seating = room.seating || {};
  const viewing = snapshot.viewing || {};
  const system = snapshot.system || {};
  const parameters = parameterRows(snapshot, policy);
  const products = productRows(snapshot);
  const perSeat = Array.isArray(viewing.per_seat) ? viewing.per_seat : [];

  // Internal only: the raw readings the classification compares. The frozen pack
  // carries the classification and the facts, never this working copy.
  const readings = areaReadings({ room, screen, seating, viewing, system, parameters, products });

  const frozen = {
    version_id: versionId,
    version_name: versionName,
    label: label || null,
    areas: readings,
    facts: {
      version_id: versionId,
      version_name: versionName,
      label: label || null,
      // The report's own identity statement. It is never the live project record.
      report_identity: {
        project_name: asText(identity.project_name),
        client_name: asText(identity.client_name),
        project_reference: asText(identity.project_reference),
        dealer_name: asText(identity.dealer_name),
      },
      report_snapshot_ids: {
        project: identity.projectReportId || null,
        visual: identity.visualReportId || null,
        technical: identity.technicalReportId || null,
      },
      fingerprints: {
        engineering: identity.engineeringFingerprint || null,
        visual_evidence: identity.visualEvidenceFingerprint || null,
        technical_evidence: identity.technicalEvidenceFingerprint || null,
        evidence_generated_at: identity.generatedAt || null,
      },
      room: {
        length_m: room.dimensions?.length_m ?? null,
        width_m: room.dimensions?.width_m ?? null,
        height_m: room.dimensions?.height_m ?? null,
        volume_m3: room.volume_m3 ?? null,
        dimensions_text: asText(room.dimensions_text),
        interpretation: asText(room.interpretation),
        acoustic_treatment: room.acoustic_treatment ?? null,
      },
      screen: {
        size_inches: screen.size_inches ?? null,
        display_type: screen.display_type ?? null,
        display_label: screen.display_label ?? null,
        // A projection screen is never stated by its diagonal: the convention is
        // viewable width and aspect ratio alone, so the writer's frozen pack
        // carries no diagonal for one. The authoritative display_label carries
        // the phrase; the viewable width and height carry the geometry.
        diagonal_inches: screen.display_type === 'tv' ? (screen.diagonal_inches ?? null) : null,
        aspect_ratio: asText(screen.aspect_ratio),
        screen_type: asText(screen.screen_type),
        viewable_width_cm: screen.viewable_width_cm ?? null,
        viewable_height_cm: screen.viewable_height_cm ?? null,
        manual_dimensions: screen.manual_dimensions === true,
        manual_width_m: screen.manual_width_m ?? null,
        manual_height_m: screen.manual_height_m ?? null,
        interpretation: asText(screen.interpretation),
      },
      seating: {
        interpretation: asText(seating.interpretation),
        seat_count: seating.seat_count ?? null,
        row_count: seating.row_count ?? null,
        per_seat: perSeat.map((seat) => ({
          seat_id: seat?.seatId || null,
          label: asText(seat?.label),
          row: seat?.row ?? null,
          distance_m: seat?.distance_m ?? null,
          horizontal_angle_deg: seat?.horizontal_angle_deg ?? null,
          vertical_angle_deg: seat?.vertical_angle_deg ?? null,
          rp23_level: asText(seat?.level),
        })),
      },
      viewing: {
        available: viewing.available === true,
        summary: asText(viewing.summary),
        primary_floor: asText(viewing.primary_floor),
      },
      system: {
        layout: layoutText(system),
        // The short format ("9.1.6") as the reports state it, so a claim can
        // name the format the design is built to without recomposing it.
        format: formatText(system),
        channel_layout: {
          bed_channels: system.channel_layout?.bed_channels ?? null,
          overhead_channels: system.channel_layout?.overhead_channels ?? null,
          dolby_subwoofer_channels: system.channel_layout?.dolby_subwoofer_channels ?? null,
          total_discrete: system.channel_layout?.total_discrete ?? null,
          subwoofer_count: system.channel_layout?.subwoofer_count ?? null,
        },
        products,
        products_by_layer: system.products_selected_by_layer || {},
        product_roles: roleText(system),
        front_stage: frontStageFact(system),
        subwoofer_strategy: system.subwoofer_strategy || null,
        amplification: amplificationText(system),
        acoustic_treatment: Array.isArray(system.acoustic_treatment) ? system.acoustic_treatment : [],
      },
      parameters,
      bass: {
        available: snapshot.bass?.available === true,
        subwoofer_strategy_summary: asText(snapshot.bass?.subwoofer_strategy_summary),
      },
    },
  };

  // The assumed parameters the designer explicitly asked for, carried only as
  // labelled assumptions: they support no performance claim, are never a
  // client-facing result and are never a difference between options. Added only
  // when one was requested, so a pack built with no request is unchanged.
  const assumed = frozen.facts.parameters.filter((row) => row.kind === 'assumed_parameter');
  if (assumed.length > 0) {
    frozen.facts.assumed_parameters = assumed.map((row) => ({
      parameter_id: row.parameter_id,
      key: row.key,
      label: row.label,
      level: row.level,
      value: row.value,
      text: row.text,
      assumption_label: row.assumption_label,
    }));
  }

  // The scoped seat-group results, added only where the saved evidence states
  // them: per parameter and per scope, with the number of seats each scope holds,
  // copied exactly and never aggregated. A version whose evidence states no
  // scoped summary carries no such fact at all — so a pack built from unscoped
  // evidence is unchanged, and no scoped claim can be minted from it.
  if (snapshot.seat_scopes) {
    frozen.facts.seat_scopes = snapshot.seat_scopes;
  }
  // The seat-priority set the report's scoped results were computed from, so a
  // scoped claim can state the scope authority it rests on.
  if (identity.seatingFingerprint) {
    frozen.facts.fingerprints.seating_scope = identity.seatingFingerprint;
  }

  // No prohibited bass claim may reach the pack, wherever a report wrote it: one
  // pass over the facts and the readings removes the phrase, keeps the rest of
  // the line it appeared in, and records the path and the rule that removed it —
  // never the sentence itself, which the pack must not carry either.
  const stripped = stripBassWordingDeep(frozen);

  return {
    version_id: versionId,
    version_name: versionName,
    label: label || null,
    version_name_source: {
      source: 'saved-report-evidence',
      from: versionIdentity.from,
      stated_by: versionIdentity.stated_by,
      reports_agree: versionIdentity.reports_agree,
    },
    areas: stripped.value.areas,
    facts: stripped.value.facts,
    wording_removed: stripped.removed,
  };
}