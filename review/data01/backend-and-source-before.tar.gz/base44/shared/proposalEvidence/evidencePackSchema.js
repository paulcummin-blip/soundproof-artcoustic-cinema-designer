/**
 * evidencePackSchema.js (shared)
 * ------------------------------
 * The frozen proposal evidence pack: its version, its shape and its vocabulary.
 *
 * Sound Proof is the engineering authority. The pack is the only thing a writer
 * is given, and this module names what the pack may say: the five
 * classifications (same, different, materially different, not materially
 * different, not comparable), the six allowed claim kinds, and the reasons a
 * claim is blocked.
 *
 * The area list is deliberately NOT a second opinion. It is the canonical
 * comparison area order and the printed area names from comparisonTable.js, so a
 * proposal, a comparison table and this pack all speak about one set of areas
 * with one set of words.
 *
 * CLAIM ID STRUCTURE
 * ------------------
 *   allowed claim   claim_<area>_<kind>_<nn>     e.g. claim_p12_material_gain_01
 *   blocked claim   block_<scope>_<reason>_<nn>  e.g. block_global_no_changed_values_01
 *   scoped claim    claim_<area>_<scope>_<wording_class>_<nn>
 *                   e.g. claim_p20_primary_consistency_01
 *                        claim_p5_primary_spacing_01
 *                        claim_p10_secondary_consistency_01
 *
 * A scoped claim is a result the saved evidence states for ONE seating scope
 * (the primary seats or the secondary seats) rather than for every seat. It is
 * minted only where that scope's own summary exists in the saved reports, so a
 * draft can be positive about one group while the whole-seat result stays lower,
 * and it can never be promoted to a wider scope.
 *
 * <area>  is a canonical area key (p12, system_layout, subwoofers, ...), or
 *         'design' for a claim about the design as a whole (credibility,
 *         recommendation);
 * <kind>  is a CLAIM_KIND value;
 * <scope> is 'global' for a rule that applies to the whole proposal, or an area
 *         key for a rule about that area;
 * <nn>    is a two-digit sequence. A claim kind occurs once per area, so the
 *         sequence is 01 today; it exists so a future rule can mint a second
 *         claim of the same kind without changing an ID that is already stored.
 *
 * An ID is derived from the evidence alone, so the same pack always mints the
 * same IDs and a generated sentence can always be traced to the claim behind it.
 *
 * Pure: no React, no SDK, no runtime-specific APIs.
 */

import { COMPARISON_ROW_ORDER, ROW_LABELS } from '../comparisonTable.js';
import { structureForParameter } from '../adiReportEvidenceRules.js';

/**
 * The pack payload generation. A pack of another generation is never read.
 * v2 adds the room classification, the saved-evidence version-name rule, the
 * strengthened framing guard, the bass wording rule and the whole-design claims.
 */
export const PROPOSAL_EVIDENCE_SCHEMA_VERSION = 2;

/** Every classification a design area may carry. A writer reasons only in these. */
export const CLASSIFICATION = Object.freeze({
  SAME: 'same',
  DIFFERENT: 'different',
  MATERIALLY_DIFFERENT: 'materially_different',
  NOT_MATERIALLY_DIFFERENT: 'not_materially_different',
  NOT_COMPARABLE: 'not_comparable',
});

/** How the evidence for an area is read, which decides how it is classified. */
export const AREA_KIND = Object.freeze({
  /** An RP22 result or the RP23 viewing floor: graded L1 to L4. */
  GRADED: 'graded',
  /** An item of equipment: a change of model is a change of equipment. */
  EQUIPMENT: 'equipment',
  /** The room, screen, seating or system format: a stated design choice. */
  STRUCTURAL: 'structural',
  /** The room itself: the dimensions the reports state, compared directly. */
  ROOM: 'room',
});

/** The claims a writer may make from this pack. */
export const CLAIM_KIND = Object.freeze({
  /** A material result for one option: the higher-graded option. */
  MATERIAL_GAIN: 'material_gain',
  /** An option's own stated result where no material difference exists. */
  MODEST_RESULT: 'modest_result',
  /** An area every option states identically. */
  SHARED_RESULT: 'shared_result',
  /** A stated difference that is a change of equipment or geometry, not a gain. */
  FACTUAL_CHANGE: 'factual_change',
  /** A design that takes no material gain is still a credible design in itself. */
  CREDIBILITY: 'credibility',
  /** The stronger option where maximum performance and headroom are the priority. */
  RECOMMENDATION: 'recommendation',
  /** A result the saved evidence states for one seating scope, not for every seat. */
  SCOPED_RESULT: 'scoped_result',
  /**
   * A result the CLIENT BRIEF asked for and the saved evidence states, which the
   * ranked strength stories do not carry because it is not one of the design's
   * strongest results. It is stated because the client asked for it, at the exact
   * scope and status the reports record, and it is never a strength, a gain or a
   * comparison.
   */
  SUPPORTING_RESULT: 'supporting_result',
});

/** Why a claim is blocked. Each reason carries its own client-safe sentence. */
export const BLOCK_REASON = Object.freeze({
  NO_INVENTED_BENEFITS: 'no_invented_benefits',
  NO_CHANGED_VALUES: 'no_changed_values',
  NO_UNSELECTED_PRODUCTS: 'no_unselected_products',
  NO_RECALCULATION: 'no_recalculation',
  NO_REDESIGN_RECOMMENDATION: 'no_redesign_recommendation',
  NO_UNIVERSAL_IMPROVEMENT: 'no_universal_improvement',
  NO_DECISION_FRAMING: 'no_decision_framing',
  NO_CLAIMED_CHANGE: 'no_claimed_change',
  NO_CLAIMED_IMPROVEMENT: 'no_claimed_improvement',
  NO_ADDED_CHANNELS: 'no_added_channels',
  NO_SCREEN_CHANGE: 'no_screen_change',
  NO_SEATING_CHANGE: 'no_seating_change',
  NO_SOLVED_BASS_CONSISTENCY: 'no_solved_bass_consistency',
  /** An assumed or administrative parameter presented as a result or a differentiator. */
  NO_ASSUMED_PARAMETER_DIFFERENTIATOR: 'no_assumed_parameter_differentiator',
  NOT_COMPARABLE: 'not_comparable',
});

/**
 * The levels that make a difference material. This is the report's own
 * "positive result" set (P20_POSITIVE_LEVELS) and the same line the client
 * meaning authority draws when it refuses to sell an L1 or L2 result as a
 * strength. A difference between two low-grade results is therefore a stated
 * difference, never a material gain.
 */
export const MATERIAL_RESULT_LEVELS = Object.freeze(['L3', 'L4']);

/** The dynamic-range results that can carry a decision framing. */
export const DECISION_FRAMING_PARAMETER_KEYS = Object.freeze(['p12', 'p13', 'p14']);

/** The equipment areas whose change supports a decision framing. */
export const DECISION_FRAMING_EQUIPMENT_KEYS = Object.freeze([
  'speakers',
  'lcr',
  'surrounds',
  'overheads',
  'subwoofers',
  'amplification',
  'acoustic_treatment',
]);

/** The areas that are not RP22 parameters, with how each one is read. */
const NON_PARAMETER_KINDS = Object.freeze({
  screen_size: AREA_KIND.STRUCTURAL,
  system_layout: AREA_KIND.STRUCTURAL,
  seating: AREA_KIND.STRUCTURAL,
  rp23_viewing: AREA_KIND.GRADED,
  speakers: AREA_KIND.EQUIPMENT,
  lcr: AREA_KIND.EQUIPMENT,
  surrounds: AREA_KIND.EQUIPMENT,
  overheads: AREA_KIND.EQUIPMENT,
  subwoofers: AREA_KIND.EQUIPMENT,
  acoustic_treatment: AREA_KIND.EQUIPMENT,
  amplification: AREA_KIND.EQUIPMENT,
});

/** The RP22 design structure an area belongs to, or null for a non-parameter. */
function structureOf(key) {
  if (key === 'rp23_viewing') return 'Viewing';
  const match = /^p(\d+)$/.exec(key);
  return match ? structureForParameter(Number(match[1])) : null;
}

/**
 * The major design areas the pack classifies, in the canonical comparison order.
 * Excluded parameters (P8, P15, P21) are absent by construction: they are not in
 * the canonical order and never reach a client-facing surface.
 */
/**
 * The room itself. It is not a comparison row: it is classified from the room
 * facts both reports state, so no framing can describe two different rooms as
 * one shared design.
 */
const ROOM_AREA = Object.freeze({
  key: 'room',
  label: 'Room',
  kind: AREA_KIND.ROOM,
  structure: null,
});

export const PROPOSAL_EVIDENCE_AREAS = Object.freeze([
  ROOM_AREA,
  ...COMPARISON_ROW_ORDER.map((key) => Object.freeze({
    key,
    label: ROW_LABELS[key] || key,
    kind: NON_PARAMETER_KINDS[key] || AREA_KIND.GRADED,
    structure: structureOf(key),
  })),
]);

/** The area definition for a key, or null. */
export function areaByKey(key) {
  return PROPOSAL_EVIDENCE_AREAS.find((area) => area.key === key) || null;
}

/** The stable ID of an allowed claim. */
export function buildClaimId(areaKey, kind, index = 1) {
  return `claim_${areaKey}_${kind}_${String(index).padStart(2, '0')}`;
}

/** The stable ID of a blocked claim. */
export function buildBlockId(scope, reason, index = 1) {
  return `block_${scope}_${reason}_${String(index).padStart(2, '0')}`;
}

/**
 * The stable ID of a scoped claim: a result the evidence states for one seating
 * scope ("claim_p20_primary_consistency_01"). The scope and the wording class are
 * part of the ID, so a generated sentence can be traced to the scope it was
 * allowed at.
 */
export function buildScopedClaimId(areaKey, scope, wordingClass, index = 1) {
  return `claim_${areaKey}_${scope}_${wordingClass}_${String(index).padStart(2, '0')}`;
}