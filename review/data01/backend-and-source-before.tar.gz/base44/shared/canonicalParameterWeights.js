/**
 * canonicalParameterWeights.js (base44/shared — CANONICAL)
 * -------------------------------------------------------
 * THE ONE canonical Artcoustic System Design Rating importance table, plus the
 * parameters that are permanent design ASSUMPTIONS rather than results.
 *
 * The Project Report's ADI Design Highlights selector and the proposal writer's
 * strength selection both rank by this table, so a proposal can never sell a set
 * of strengths the report does not state. There is no second importance table,
 * and no surface may add one.
 *
 * INTERNAL ONLY. A weight is never printed, never sent to a client and never
 * named in client-facing copy.
 *
 * Dependency-free, so both runtimes read the same bytes:
 *   · this file IS the canonical implementation — backend functions import it
 *     directly, and every frontend/backend re-export path resolves back to it
 *     (`shared/canonicalParameterWeights.js` and
 *     `src/shared/canonicalParameterWeights.js` are thin re-exports, and the
 *     Room Designer's ASDR module re-exports this same table).
 *
 * Artcoustic System Design Rating — proprietary Sound Proof logic. It is NOT
 * CEDIA RP22 or RP23.
 */

/** Fixed V1 importance weights per parameter. */
export const PARAM_WEIGHTS = Object.freeze({
  p1: 6, p2: 8, p3: 3, p4: 5, p5: 6, p6: 5, p7: 4,
  p8: 2, p9: 5, p10: 5, p11: 4, p12: 8, p13: 7, p14: 9,
  p15: 3, p16: 5, p17: 5, p18: 12, p19: 9, p20: 9, p21: 3,
  screen: 7,
});

/** Sum of all configured importance weights (derived from PARAM_WEIGHTS). */
export const TOTAL_WEIGHT = Object.values(PARAM_WEIGHTS).reduce((a, b) => a + b, 0);

/**
 * The ASDR performance multipliers per level — the scoring half of the SAME
 * authority as the weight table above, defined once here so the rating engine, the
 * narrative priority authority and every derived contribution read one table.
 * A parameter's contribution is its multiplier times its weight, and its maximum
 * is the L4 multiplier times that weight. Nothing else is a contribution.
 */
export const LEVEL_MULTIPLIERS = Object.freeze({
  L4: 12, L3: 8, L2: 4, L1: 2, FAIL: -5,
});

/**
 * The parameters that are permanent design assumptions, never a measured result:
 * P8 (design/administrative), P15 (background noise) and P21 (early reflections).
 * They are excluded from every strength selection and from every client-facing
 * surface, whatever level they happen to carry.
 */
export const ASSUMED_PARAMETER_KEYS = Object.freeze(['p8', 'p15', 'p21']);

/**
 * The parameters that are assessed for each seat rather than once for the room.
 * This mirrors the canonical publication's own `scope` on each parameter entry,
 * and the frozen report evidence's own per-parameter `parameter_scope`; it is a
 * classification, never a weight.
 */
export const SEAT_SCOPED_PARAMETER_KEYS = Object.freeze([
  'p1', 'p4', 'p5', 'p6', 'p9', 'p10', 'p16', 'p17', 'p20', 'screen',
]);

export default PARAM_WEIGHTS;