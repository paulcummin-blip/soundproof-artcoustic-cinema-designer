/**
 * comparisonTable.js (shared)
 * ---------------------------
 * The calculated System Design Comparison table.
 *
 * Every cell is read from a version's frozen Engineering Snapshot. The AI never
 * writes a comparison value: it writes only the prose around the table, and for
 * the single-report table the experience cell of each row.
 *
 * Row rules:
 *   - EVERY assessed comparison area is carried: a row appears whenever every
 *     version has a reliable value, whether or not the values differ. An area
 *     the versions share is a comparison result and states "No change" rather
 *     than being dropped, so a client is never shown a partial picture of two
 *     systems that also agree in places. The table is never truncated;
 *   - the differences lead, then the areas the versions share, each group in
 *     performance order;
 *   - P8, P15, P21, assumed parameters, and unavailable, stale, unreliable or
 *     unassessed results never appear, because the evidence rules never supply
 *     them. Bass consistency (P20) appears when the P20 rule admits it, which is
 *     what lets a comparison show one bass layout as more even across seats;
 *   - the internal Design Index is never a row: it is a designer diagnostic, not
 *     a client-facing result, and a table stored before that rule existed has
 *     its Design Index rows dropped before it reaches a writer;
 *   - the change column is DERIVED from the values, never written by the model.
 *
 * Columns:
 *   2 versions  → Performance area | Option A | Option B | What changes
 *   3+ versions → Performance area | Option A | Option B | Option C
 *                 (the change column is omitted: with three options a single
 *                  "what changes" cell would have to choose a pairing)
 *
 * Pure: no React, no side effects.
 */

import { isDesignIndexRow } from './reportWritingStyleContract.js';
import comparisonClientMeaning from './comparisonClientMeaning.js';
import { excludeExcludedClientParameterRows } from './clientFacingParameterAuthority.js';

export const COMPARISON_ROW_ORDER = Object.freeze([
  'screen_size',
  'rp23_viewing',
  'system_layout',
  // The equipment is a comparison area in its own right: two systems can be
  // graded alike and still be built from different speakers and subwoofers.
  'speakers',
  'lcr',
  'surrounds',
  'overheads',
  'subwoofers',
  // The acoustic treatment a version specifies is part of its product
  // specification, so it is compared alongside the equipment.
  'acoustic_treatment',
  'amplification',
  'seating',
  'p2',
  'p4',
  'p5',
  'p7',
  'p9',
  'p10',
  'p12',
  'p13',
  'p14',
  'p16',
  'p17',
  'p18',
  'p19',
  'p20',
]);

/** The printed area name for each comparison key. Exported so the frozen
 *  proposal evidence pack labels an area with the same words this table does. */
export const ROW_LABELS = Object.freeze({
  screen_size: 'Screen size',
  rp23_viewing: 'Viewing angle / RP23',
  system_layout: 'System layout',
  speakers: 'Speaker package',
  lcr: 'LCR',
  surrounds: 'Surrounds / wides',
  overheads: 'Overheads',
  subwoofers: 'Subwoofers',
  acoustic_treatment: 'Acoustic treatment',
  amplification: 'Amplification',
  seating: 'Seating',
  p2: 'Discrete channels (P2)',
  p4: 'Screen consistency (P4)',
  p5: 'Horizontal spacing (P5)',
  p7: 'Front wide position (P7)',
  p9: 'Overhead spacing (P9)',
  p10: 'Overhead level consistency (P10)',
  p12: 'Screen Dynamic Range (P12)',
  p13: 'Non-screen Dynamic Range (P13)',
  p14: 'LFE and subwoofer Dynamic Range (P14)',
  p16: 'Screen timbre (P16)',
  p17: 'Surround and overhead timbre (P17)',
  p18: 'Bass extension (P18)',
  p19: 'Bass response (P19)',
  p20: 'Bass consistency (P20)',
});

/** The reliable value one version carries for a row, or null. */
function readRowValue(evidence, rowKey) {
  if (!evidence?.available) return null;
  if (/^p\d+$/.test(rowKey) && evidence.report_parameters) {
    return evidence.report_parameters.find((row) => row.parameter_id === Number(rowKey.slice(1)))?.text || null;
  }

  if (rowKey === 'screen_size') {
    const screen = evidence.screen_data || {};
    if (screen.manual_dimensions && screen.manual_width_m) {
      return screen.manual_height_m
        ? `${screen.manual_width_m}m × ${screen.manual_height_m}m (manual)`
        : `${screen.manual_width_m}m (manual)`;
    }
    if (screen.size_inches) {
      // The aspect ratio is written in brackets so the inch value stays a clean,
      // comparable measure for the change column.
      return screen.aspect_ratio
        ? `${screen.size_inches}" (${screen.aspect_ratio})`
        : `${screen.size_inches}"`;
    }
    return null;
  }

  if (rowKey === 'rp23_viewing') {
    const viewing = evidence.rp23_results || {};
    if (!viewing.available || !viewing.summary) return null;
    if (/not calculated/i.test(String(viewing.summary))) return null;
    // The achieved floor leads, so a change between floors reads as a level
    // change rather than as a re-print of two long summaries.
    return viewing.primary_floor
      ? `${viewing.primary_floor} · ${viewing.summary}`
      : String(viewing.summary);
  }

  if (rowKey === 'system_layout') return evidence.system_format_short || evidence.system_format || null;

  if (rowKey === 'speakers') {
    // The speakers each version is actually specified with, position by
    // position: the package is a comparison area, not background detail.
    const roles = Array.isArray(evidence.speaker_package) ? evidence.speaker_package : [];
    const lines = [];
    for (const role of roles) {
      const model = role?.model || null;
      if (!model) continue;
      const label = role.role_description || role.role || null;
      const line = label ? `${label}: ${model}` : String(model);
      if (!lines.includes(line)) lines.push(line);
    }
    return lines.length > 0 ? lines.join(' · ') : null;
  }

  // The product rows state exactly what THIS version's Technical Report states in
  // its "Products Selected" list — the model and quantity of each layer, read
  // from that version's own frozen report source. The per-role package below is
  // the fallback for a snapshot that predates that authority.
  const selectedProducts = evidence.products_selected || null;
  const selectedValue = selectedProducts ? selectedProducts[rowKey] : null;
  if (Array.isArray(selectedValue) && selectedValue.length > 0) return selectedValue.join(', ');

  // The screen stage keeps its own positions: a dual-centre design states the
  // left/right pair and the centre cabinets separately, and the fallback must
  // carry all four keys rather than lose the centre.
  const packageRoles = {
    lcr: ['lcr', 'centre_soundbar', 'front_left_right', 'centre'],
    surrounds: ['surround', 'rear_surround', 'front_wide'],
    overheads: ['overhead'],
  };
  if (packageRoles[rowKey]) {
    const models = (evidence.speaker_package || []).filter((role) => packageRoles[rowKey].includes(role.role)).map((role) => role.model).filter(Boolean);
    return [...new Set(models)].join(' · ') || null;
  }

  if (rowKey === 'subwoofers') {
    const subwoofers = evidence.subwoofer_package || {};
    return subwoofers.strategy || subwoofers.summary || null;
  }

  if (rowKey === 'amplification') return evidence.amplification || null;

  if (rowKey === 'seating') return evidence.seating_data?.interpretation || null;

  if (rowKey === 'p14') return evidence.bass_evidence_if_reliable?.p14?.text || null;
  if (rowKey === 'p18') return evidence.bass_evidence_if_reliable?.p18?.text || null;
  if (rowKey === 'p19') return evidence.bass_evidence_if_reliable?.p19?.text || null;
  if (rowKey === 'p20') return evidence.comparison_p20?.text || evidence.bass_evidence_if_reliable?.p20?.text || (evidence.rp22_results || []).find((row) => Number(row.parameter_id) === 20)?.text || null;

  const parameterId = Number(rowKey.replace('p', ''));
  if (!Number.isFinite(parameterId)) return null;
  const row = (evidence.rp22_results || []).find((entry) => Number(entry.parameter_id) === parameterId);
  return row?.text || null;
}

export function parseLevel(value) {
  // Accepts both the parameter form ("L4") and the RP23 floor form ("Level 4").
  const match = /^\s*(?:L([1-4])|Level\s*([1-4]))\b/i.exec(String(value || ''));
  if (!match) return null;
  return `L${match[1] || match[2]}`;
}

function parseMeasure(value) {
  const body = String(value || '').replace(/^\s*L[1-4]\s*[·\-]?\s*/i, '');
  const match = /(-?\d+(?:\.\d+)?)\s*([a-zA-Z%"°]+(?:\s?[a-zA-Z]+)?)?/.exec(body);
  if (!match) return null;
  const amount = Number(match[1]);
  if (!Number.isFinite(amount)) return null;
  return { amount, unit: (match[2] || '').trim() };
}

const isTolerance = (value) => /±/.test(String(value || ''));

/**
 * Derive the change between two option values from the values themselves.
 * Deterministic, data-only: it never invents a number or a claim.
 */
export function describeChange(firstValue, secondValue) {
  const first = String(firstValue ?? '').trim();
  const second = String(secondValue ?? '').trim();
  if (!first || !second) return null;
  if (first === second) return null;

  const firstLevel = parseLevel(first);
  const secondLevel = parseLevel(second);
  if (firstLevel && secondLevel && firstLevel !== secondLevel) {
    return `${firstLevel} → ${secondLevel}`;
  }

  if (!isTolerance(first) && !isTolerance(second)) {
    const firstMeasure = parseMeasure(first);
    const secondMeasure = parseMeasure(second);
    const pureNumber = (value) => /^-?\d+(?:\.\d+)?$/.test(value);
    // A numeric difference is stated only when the two values are genuinely
    // comparable: the same unit, or two plain numbers. Otherwise the change is
    // stated as the two values, which is honest and cannot mislead.
    const comparable = firstMeasure && secondMeasure
      && firstMeasure.unit === secondMeasure.unit
      && (firstMeasure.unit !== '' || (pureNumber(first) && pureNumber(second)));
    if (comparable) {
      const delta = Math.round((secondMeasure.amount - firstMeasure.amount) * 100) / 100;
      if (delta !== 0) {
      const sign = delta > 0 ? '+' : '-';
      // A unit that is a word is spaced from the number (-8 Hz). A symbol
      // attaches to it, so an inch or a degree change never prints detached.
      const unit = firstMeasure.unit
        ? (/^[a-zA-Z]/.test(firstMeasure.unit) ? ` ${firstMeasure.unit}` : firstMeasure.unit)
        : '';
      return `${sign}${Math.abs(delta)}${unit}`;
      }
    }
  }

  return `${first} → ${second}`;
}

/**
 * Build the comparison rows from every selected version's evidence.
 *
 * @param {Array<Object>} versions — buildSelectedVersionEvidence output, in
 *   report order (Option A first)
 * @returns {{ rows: Array, versions: Array<{ version_id, label, version_name }> }}
 */
export function buildComparisonTable(versions) {
  const list = Array.isArray(versions) ? versions : [];
  const columns = list.map((version, position) => ({
    version_id: version.version_id || null,
    label: version.label || `Option ${String.fromCharCode(65 + position)}`,
    version_name: version.version_name || null,
    source_identity: version.source_identity || {},
  }));

  // A comparison needs at least two versions with evidence to be a comparison.
  const usable = list.length >= 2 && list.every((version) => version?.available === true);
  if (!usable) return { rows: [], versions: columns };

  const compared = [];
  for (const key of COMPARISON_ROW_ORDER) {
    const values = list.map((version) => readRowValue(version, key));
    // A row needs a reliable value for EVERY version: a version that was not
    // assessed for this area is omitted rather than printed as a blank cell.
    if (values.some((value) => !value)) continue;
    const normalised = values.map((value) => String(value).trim());
    const identical = new Set(normalised).size < 2;

    compared.push({
      key,
      area: ROW_LABELS[key] || key,
      values: normalised,
      // A row both versions share is stated once, as itself: an unchanged area
      // is a real comparison result, not a missing one, so it says so in the
      // change column rather than being dropped from the table.
      identical,
      // The change column is derived from two comparable values. With more than
      // two options a single change cell would have to choose a pairing, so the
      // column stays empty there and the client reads the values themselves.
      change: identical
        ? 'No change'
        : (normalised.length === 2 ? describeChange(normalised[0], normalised[1]) : null),
    });
  }

  // Every assessed area is carried and no row is truncated: a table that showed
  // only some of the assessed areas left the client reading a whole system from
  // a partial table. The differences lead, because they are what the comparison
  // is for, and each group stays in performance order (the compared list is
  // built by walking COMPARISON_ROW_ORDER, so filtering preserves that order).
  const ordered = [...compared.filter((row) => !row.identical), ...compared.filter((row) => row.identical)];

  // The internal Design Index is never a client-facing row, and neither is an
  // assumed or administrative parameter (P8, P15, P21), whatever a stored table
  // carries. The stored record is never modified.
  const clientFacing = excludeExcludedClientParameterRows(ordered.filter((row) => !isDesignIndexRow(row)));
  return { rows: clientFacing.map(row => ({
    ...row, client_meaning: comparisonClientMeaning(row),
  })), versions: columns };
}

/**
 * The table as prompt text, so the writer knows exactly what the table says and
 * never restates or contradicts it with a different number.
 */
export function formatComparisonTableForPrompt(table) {
  // A table stored before the rule existed may still carry the internal Design
  // Index, so its rows are dropped here too: a regenerated section must never
  // see the index, and must never be able to restate it.
  const rows = excludeExcludedClientParameterRows((table?.rows || []).filter((row) => !isDesignIndexRow(row)));
  if (rows.length === 0) {
    return '=== COMPARISON TABLE ===\nNo calculated differences were found between the selected versions. Explain what stays the same and do not claim a difference.';
  }

  const labels = (table.versions || []).map((column, index) => column.label || `Option ${String.fromCharCode(65 + index)}`);
  const lines = [
    '=== COMPARISON TABLE (calculated by Sound Proof, already final) ===',
    `Columns: Performance area | ${labels.join(' | ')}${rows[0].change !== null ? ' | What changes' : ''}`,
  ];

  for (const row of rows) {
    const cells = row.values.join(' | ');
    lines.push(`${row.area} | ${cells}${row.change !== null ? ` | ${row.change}` : ''}`);
  }

  lines.push(
    '',
    'This table is built from each version\'s frozen engineering evidence. Do not add, remove or reorder a row, and never state a value that is not in it.',
  );
  return lines.join('\n');
}

/** The comparison highlights reply carries the introduction only. */
export const COMPARISON_HIGHLIGHTS_SCHEMA = {
  type: 'object',
  properties: {
    intro_html: { type: 'string' },
  },
  required: ['intro_html'],
};

/**
 * The prompt for the introduction to a calculated comparison table. No value,
 * cell or row is written by the model: the table is already built.
 */
export function buildComparisonHighlightsPrompt() {
  return [
    'Write the introduction to the Key Differences section of a System Design Comparison, which compares multiple system options rather than describing one system.',
    '',
    'The comparison table below is already calculated by Sound Proof, one column per selected version. It follows your introduction in the report.',
    '',
    'Return intro_html only: 1 or 2 short sentences, as simple HTML with a <p> tag, written in the design-led voice defined in the style contract.',
    '',
    'RULES:',
    '- Do not write a table, a row or a value.',
    '- Do not restate a table value and do not describe a difference the table does not show.',
    '- Do not say which option is better here: this is the introduction only, and the section that follows explains the differences in order (what changes, what the room gains or gives up, and what stays the same).',
    '- Never say the options are the same, equivalent or unchanged where the table shows a difference, and never state a difference the table does not show.',
    '- State in one clause what the options share, then say where the differences lie: system scale, loudspeaker and subwoofer specification, and the performance that follows. Frame the decision, never describing equipment for its own sake.',
    '- Write to the decision: what the client is choosing between, in short direct sentences.',
  ].join('\n');
}