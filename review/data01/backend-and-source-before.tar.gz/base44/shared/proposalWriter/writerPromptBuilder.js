/**
 * writerPromptBuilder.js (shared)
 * --------------------------------
 * THE Phase 6 writer prompt: the one request the writer is sent.
 *
 * The prompt carries three things and nothing else — the Sound Proof writing
 * authority, the Phase 2 writer input exactly as `buildWriterInput` assembled it,
 * and the instruction to return that contract's JSON and no prose. The input is
 * passed in whole and is never augmented, so the writer cannot be handed a live
 * Project, a live ProjectVersion, a product catalogue, a report page or an
 * unvalidated value: there is no parameter here through which one could arrive.
 *
 * `assertWriterInputCarriesNoLiveState` proves that last claim rather than
 * asserting it: it scans the assembled input for the keys live design state is
 * carried under (room dimensions, seating, selected speakers, subwoofer
 * instances, design_state, publication pointers) and refuses to send a prompt
 * that carries one. The pack's own vocabulary — an area named "subwoofers", a
 * subwoofer model name, a printed dimension in a sentence — is evidence and is
 * left alone; the check is on key names, not on prose.
 *
 * The frozen pack itself is the one sanctioned carrier of those names. It holds
 * report evidence — including a screen's `manual_width_m` and `manual_height_m`
 * when the designer sized the screen by hand — and every fact in it is frozen
 * evidence, proved pack-side by the Phase 1 guard and its own tests. So the scan
 * skips the pack subtree and checks everything the writer input and the request
 * carry around it: a live Project, a live ProjectVersion, or any other live
 * design state riding alongside the pack still refuses the prompt.
 *
 * Pure: no React, no SDK, no runtime-specific APIs. No provider call is made
 * here.
 */

import { buildDesignIntentWritingAuthority, buildProposalWritingAuthority } from '../soundProofWritingAuthority.js';
// THE CLIENT NARRATIVE PRIORITY, section by section: which client question each
// section answers and what its copy leads on. The proposal authority already
// carries the priority itself; this adds only the per-section emphasis, and it
// changes no section structure, no word limit and no evidence rule.
import { clientSectionEmphasisLines } from '../clientNarrativePriority.js';
import { SOUND_PROOF_DESIGN_PHILOSOPHY } from '../designPhilosophyAuthority.js';
import { clientStoryPillarLines } from '../narrativePillarGrouping.js';
// The Sound Proof Natural Writing Standard: the editorial instructions this
// prompt is held to. The house style, the sentence craft, the recommendation
// language, the repetition rule and the whole-document review come from that one
// module, so the phrases the writer is told to avoid are the same phrases the
// validator refuses.
import {
  NATURAL_ALOUD_RULE,
  NATURAL_MEASURED_LANGUAGE_RULE,
  NATURAL_PARAMETER_REFERENCE_RULE,
  NATURAL_QUALITATIVE_ACCURACY_RULE,
  NATURAL_PRINCIPLE_EXPLANATION_RULE,
  NATURAL_RECORDED_REASON_RULE,
  NATURAL_RECOMMENDATION_RULE,
  NATURAL_REPETITION_RULE,
  NATURAL_SECTION_RESPONSIBILITY_RULE,
  NATURAL_EDITORIAL_REVIEW_RULE,
  NATURAL_SELECTION_RULE,
  NATURAL_SENTENCE_RULE,
  NATURAL_VOICE_RULE,
  NATURAL_WRITING_REVIEW,
  naturalWritingReferenceBlock,
} from './writerNaturalWritingStandard.js';
import {
  WRITER_CONTRACT_VERSION,
  WRITER_OUTPUT_MODE,
  WRITER_SECTION_IDS,
} from './writerContractSchema.js';

/** The provider the writer is called on. Never named in the browser. */
export const WRITER_PROVIDER = 'base44-ai-gateway';

/**
 * THE model the Sound Proof proposal writer runs on, named explicitly so a draft
 * never depends on the gateway's own unstated default. A master admin's flag
 * override, where one is set, still takes precedence — see writerModelFor.
 */
export const WRITER_DEFAULT_MODEL = 'gpt_6_astra';

/**
 * Keys that carry live design state. None of them may appear anywhere in a
 * writer input: every fact a draft stands on comes from the frozen evidence pack.
 */
export const LIVE_STATE_KEYS = Object.freeze([
  'roomdims',
  'room_length',
  'room_width',
  'room_height',
  'room_orientation',
  'screen_wall',
  'screen_size',
  'screen_height_from_floor',
  'manual_width_m',
  'manual_height_m',
  'seating_positions',
  'row_spacing_m',
  'seats_per_row_by_row',
  'selected_speakers',
  'selected_speakers_by_role',
  'spl_speaker_nodes',
  'room_elements',
  'subwooferinstances',
  'front_subs_cfg',
  'rear_subs_cfg',
  'spl_config',
  'dolby_config',
  'target_spl',
  'amplifier_power',
  'design_state',
  'active_version_id',
  'published_fingerprint',
  'applied_calibration',
  'rsp_mode',
  'manual_rsp_y_m',
  'manual_rsp_x_m',
  'designated_rsp_seat_id',
  'viewing_priority',
  'acoustic_treatment_enabled',
  'selected_abfuser_qty',
  'commercial_tier',
  'lifecycle_status',
  'dealer_account_id',
]);

/**
 * The one root key whose subtree is the frozen evidence pack itself. Its facts
 * are evidence — a saved report's own screen, seating and system values — so the
 * live-state scan does not descend into it. Nothing else is exempt.
 */
export const LIVE_STATE_SCAN_SKIP_ROOTS = Object.freeze(['evidence_pack']);

/**
 * Every path in a value whose key carries live design state.
 *
 * @param {*} value
 * @param {Array<string>} [forbidden]
 * @param {Object} [options]
 * @param {Array<string>} [options.skipRootKeys] — root subtrees left unscanned
 * @returns {Array<string>} offending key paths, e.g. 'project.roomDims'
 */
export function findLiveStateKeyPaths(value, forbidden = LIVE_STATE_KEYS, { skipRootKeys = [] } = {}) {
  const found = [];

  const walk = (node, path) => {
    if (node === null || typeof node !== 'object') return;
    if (Array.isArray(node)) {
      node.forEach((entry, index) => walk(entry, `${path}[${index}]`));
      return;
    }
    for (const key of Object.keys(node)) {
      const next = path ? `${path}.${key}` : key;
      if (!path && skipRootKeys.includes(key)) continue;
      if (forbidden.includes(String(key).toLowerCase())) found.push(next);
      walk(node[key], next);
    }
  };

  walk(value, '');
  return found;
}

/**
 * Prove a writer input carries the evidence and the contract only.
 *
 * @throws when any live design-state key is present outside the frozen pack
 */
export function assertWriterInputCarriesNoLiveState(input) {
  const offending = findLiveStateKeyPaths(input, LIVE_STATE_KEYS, { skipRootKeys: LIVE_STATE_SCAN_SKIP_ROOTS });
  if (offending.length > 0) {
    throw new Error(
      `The writer input carries live design state and was not sent: ${offending.slice(0, 5).join(', ')}. `
      + 'A draft may only ever be written from the frozen evidence pack.',
    );
  }
  return input;
}

/**
 * The output, as a JSON schema the provider enforces. It is derived from the
 * Phase 2 contract — the three top-level keys, the three section keys and the
 * nine section IDs — so the request cannot describe a shape the validator would
 * then refuse.
 */
export function writerOutputJsonSchema() {
  return {
    type: 'object',
    properties: {
      contract_version: { type: 'integer', enum: [WRITER_CONTRACT_VERSION] },
      pack_fingerprint: { type: 'string' },
      sections: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            section: { type: 'string', enum: [...WRITER_SECTION_IDS] },
            text: { type: 'string' },
            claim_ids: { type: 'array', items: { type: 'string' } },
          },
          required: ['section', 'text', 'claim_ids'],
          additionalProperties: false,
        },
      },
    },
    required: ['contract_version', 'pack_fingerprint', 'sections'],
    additionalProperties: false,
  };
}

/**
 * The prompt. The writer input arrives whole and is serialised verbatim: this
 * function adds instructions, never facts.
 *
 * @param {Object} input
 * @param {Object} input.input — buildWriterInput output
 * @returns {string}
 */
export function buildWriterPrompt({ input, briefRevision = null, correction = null } = {}) {
  if (!input || typeof input !== 'object' || !input.evidence_pack?.pack_fingerprint) {
    throw new Error('A writer input built from the frozen evidence pack is required: the writer is given no other source.');
  }

  // THE DESIGN INTENT GENERATION PATH uses its own writing authority: the shared
  // Sound Proof authority WITHOUT the proposal-sales instructions, so the Design
  // Intent is not briefed as a sales document and does not inherit proposal-stage
  // voice guidance that conflicts with its own purpose. The proposal path and
  // every other proposal section are unchanged.
  const isDesignIntent = !!input.design_intent_scope;
  const writingAuthority = isDesignIntent
    ? buildDesignIntentWritingAuthority()
    : buildProposalWritingAuthority();

  const recommendationAuthority = input.editorial_rules?.recommendation_authority
    || NATURAL_RECOMMENDATION_RULE;
  const naturalVoiceRule = recommendationAuthority.startsWith('RECOMMENDATION AUTHORITY:')
    ? NATURAL_VOICE_RULE.replace('presenting a considered recommendation', 'presenting a carefully considered design')
    : NATURAL_VOICE_RULE;

  return [
    ...(isDesignIntent ? [
      'You are the Sound Proof Design Intent writer: an experienced professional cinema designer explaining this design to the client in the Project Report.',
    ] : [
      'You are the Sound Proof proposal writer.',
    ]),
    'You do not calculate, measure, estimate or infer anything. You turn the frozen evidence you are given into client-facing narrative copy, and you claim nothing it does not support.',
    '',
    // The authority this writer is held to: the shared Sound Proof writing
    // authority. For the Design Intent, the proposal-sales authority is excluded
    // so the block is briefed as design intent, not as a sales document.
    writingAuthority,
    '',
    // THE PROFESSIONAL JUDGEMENT the copy is allowed to explain: the Sound Proof
    // design philosophy, carried whole as its own block. It adds no claim, changes
    // no rule and states no figure: the frozen evidence still governs every fact.
    SOUND_PROOF_DESIGN_PHILOSOPHY,
    '',
    '=== THE WRITER INPUT (your only source) ===',
    'This JSON carries the frozen evidence pack, every section you must write with its own word limit and requirement, the verified design interpretation, the designer\'s brief, the writing rules, the claims you may make, the claims that are blocked, the bass contract, the grounding rule and the exact output schema. The pack is the only source of every fact, figure, Performance Level and product name.',
    '',
    JSON.stringify(input),
    '',
    '=== HOW TO WRITE ===',
    // The stage discipline: this writer is at the PROPOSAL stage, where the
    // engineering analysis is complete and frozen and the job is to describe what
    // the finished design will deliver. The design stage diagnoses and the report
    // stage evidences; neither voice belongs here, and nothing is written as
    // though the performance had already been demonstrated in the room.
    ...(isDesignIntent ? [
      'You are writing the Project Report\'s Design Intent: an experienced cinema designer explaining this design to the client. The engineering analysis is complete and frozen, and this block is the design team\'s own account of the design — not a sales document, not a recommendation and not a proposal. Sound like an experienced home cinema designer presenting a completed design, not an engineer auditing it and not a salesperson selling it.',
    ] : [
      'You are writing at the PROPOSAL stage. The engineering analysis is complete and frozen: this proposal describes the design that has been specified and what it will deliver, not a design whose performance has already been demonstrated in the room. Sound like an experienced home cinema designer presenting a completed design, not an engineer auditing it.',
    ]),
    'DESIGN INTERPRETATION: design_interpretation carries the verified ADI interpretation of this design: the room and its intended use, the display and the seating, the system architecture, the constraints, the reasons behind the important design decisions, the strongest engineering characteristics, the results that are reliable evidence, and what is deliberately not stated. Read it first: it is why the design is what it is, and the copy is written from it. It explains the design and is never a source of figures: every figure, level, parameter and product still comes from the evidence pack and its own claims, and where the two differ the frozen evidence governs. Where the interpretation is unavailable, refused or silent, invent nothing.',
    'SEATING CLEARANCE (RP22 Parameter 1): design_interpretation may carry a seating_clearance block: where the seating actually sits, read from the saved geometry, the principle behind that distance and the trade the seating makes. Use it only where that block marks itself relevant to this design, and only in the section that already explains the seating: explain what the distance does for the listener rather than what it measures, keep the distance to the nearest boundary and the distance to the wall behind the seating as two separate measurements that are never read from one another, and state the balance plainly where the room or the layout takes one. The block states no Performance Level and no measured result, so never attach a level or a promise to it, and never write it as a paragraph repeated across sections.',
    'COMPARISON READING: comparison_reading carries the Stage 1 interpretation of what the options share and what changes between them. It is supplied only for a comparison proposal (supplied: true). Alongside the designer\'s brief, it is the primary authority for the NARRATIVE PURPOSE of the comparison: what each design is for, how the room would be used, and what the viewing and listening experience would be like. For each version, explain what the design is intended to achieve, how the room would be used, what the viewing and listening experience would be like, which saved design decisions create that experience, and the relevant engineering strengths and practical trade-offs. Engineering evidence remains the authority for every technical and performance claim: never attach a figure, a level or a product to the comparison reading. Do not recommend one option over another because it has higher RP22 scores, a larger speaker system, a larger screen or a higher price: a genuine engineering difference is stated objectively and never makes one option universally preferable. Recommend one option only where the designer\'s stated brief gives a clear priority that supports it; where it does not, present the options as credible alternatives without choosing a winner. The designer\'s text is context and guidance, never wording to copy, and no client preference, room use, design feature or performance claim is ever invented. Where comparison_reading is not supplied (a single-option proposal, or a comparison whose reading is absent), write nothing about it and follow the single-option or comparison rules as they stand.',
    'CLIENT INTENT COMPLETENESS: Read every editorial_brief.material_objectives instruction and address its full meaning. Named alternative TV sizes and screen sizes in the brief are proposed display choices, not output capability claims: retain the choices and their daily/movie uses. A stated accessible Level 1–2 specification is designer positioning, not a claim that every parameter achieves those levels. Explain it as that positioning. Where the brief asks for Levels 1–4 financial consultation, explicitly discuss the range and its investment choices for clients, without claiming unassessed upgrades or guaranteed performance. Do not replace these specifics with vague accessible-system or performance-level wording. Check each objective before returning the draft.',
    'EDITORIAL BRIEF: editorial_brief carries the designer\'s own client brief and notes. Treat them as instructions about what to emphasise and what needs explaining. They never override the evidence, they never change a figure, a level, a product or a claim, and they are never copied: no note, instruction, filename or caption from them appears in the draft.',
    'EDITORIAL HIERARCHY: follow this order of authority. (1) Technical truth and evidence integrity: every figure, level, product and performance claim must come from the frozen evidence pack and its allowed claims, and nothing overrides this. (2) The designer\'s Steering Brief: its explicit, supported instructions govern the project\'s purpose, narrative emphasis and the design considerations the proposal must explain. Establish what the project is for from the brief, and address each material, supported instruction in the section responsible for it. (3) Each section\'s own responsibility and required content. (4) The ranked engineering strength stories, which choose which additional technical achievements deserve emphasis around the brief\'s objectives, never instead of them. (5) General writing-style preferences. The brief governs purpose and emphasis; the evidence governs facts and claims. The brief never authorises a fabricated performance result, an invented specification or an unsupported engineering conclusion: where a brief instruction has no supporting evidence, state what the evidence supports and nothing more.',
    // THE COMPARISON ATTRIBUTION DISCIPLINE. The option_evidence_summary in
    // evidence lists, for each option, its saved version name, its products and
    // quantities, its RP22 parameter values and levels, and the exact claim IDs
    // that belong to it. The writer reads that summary to attribute a product or
    // a result only to the option whose evidence it is, and to cite only the
    // specific claim IDs that support the sentence it is writing. This is a
    // presentation discipline: it adds no claim, no figure and no product.
    ...((input?.section_structure?.proposal_mode === 'comparison' || input?.evidence?.mode === 'comparison') ? [
      'COMPARISON ATTRIBUTION: evidence.option_evidence_summary lists each option\'s products, RP22 parameter values and levels, and the exact claim IDs that belong to that option, split into own_claim_ids (this option\'s result) and shared_claim_ids (a result every option shares). Name each option only by its saved version name from that summary — for example "Original Design" or "120\\" Projector" — and never by its internal "Option A/B" label in client-facing prose, so a product or a result is always read as the option it belongs to. Attribute a product or a parameter result only to the option whose summary lists it: never transfer a product or a result between options. Each substantive performance sentence cites only the specific option-and-parameter claim IDs that support it — use own_claim_ids for an option-specific result, shared_claim_ids for a result both options share — and never attach an unrelated shared claim ID to a sentence that is really about one option\'s own result.',
      'TIMBRE ATTRIBUTION: P16 and P17 are seat-to-seat tonal results, one loudspeaker group each. For a tonal statement about an option, cite only that option\'s own P16/P17 claim IDs from the summary (own_claim_ids, or shared_claim_ids where the result is shared). Never cite a bass claim (P14, P18, P19, P20) to support a tonal consistency sentence, and never infer seat-to-seat tonal consistency from bass consistency or any other parameter.',
      'DYNAMIC RANGE ATTRIBUTION: keep the parameter families distinct. A supported P12 screen-stage difference may be explained, but cite only the P12 claim IDs for that sentence and keep P13, P16 and any other parameter\'s claims with their own separate sentences. Use "screen stage" or "front stage" (two words) for the screen-channel capability, never a hyphenated form such as "screen-channel", so the capability is read as Dynamic Range language and never as a change to screen consistency or screen timbre. Never imply an improvement in P13, P16 or any other parameter from a P12 difference.',
    ] : []),
    'RP22 DESIGN CONTEXT: rp22_design_context carries the established RP22 design principles that apply to this project. It is professional design context for explaining WHY a decision suits this room, never engineering evidence: it states no figure, level, product or result, and it never establishes the reason this designer chose a configuration. Use it to explain WHY an approach is used, confidently and in the client\'s own terms: an established principle does not need a strong result in this project to be explained positively, and it is never weakened because a result is weak. It states no reason for a configuration and no result of this design, so never turn a channel, overhead or subwoofer count into a reason for a decision, and never present a principle as a project-specific guarantee. Acoustics stay restrained: acoustic absorption, reflection decay, background noise and sound isolation are not prominent subjects here, never imply that specified acoustic treatment has already achieved an acoustic result, never present an assumed P15 or P21 level as measured, and never claim an improved P19 or P20 result from treatment.',
    'CLARIFICATION ANSWERS: clarification_answers carries the designer\'s own answers to ADI\'s clarification questions: decisions the frozen evidence records no reason for. Weave each answer into the section it belongs to (its belongs_to), as the reason or intent behind that decision, in your own words and in the document\'s professional voice. Never print the question, an answer label or the answer as a standalone statement, never list them, and never treat an answer as measured engineering evidence: it is design intention, it changes no figure, level, product or claim, and the frozen evidence governs wherever the two differ. Understand the technical meaning of each answer and develop it properly with established acoustic knowledge, so the reasoning behind the decision is explained confidently and usefully rather than paraphrased: an intention is never weakened, hedged or apologised for because a parameter scored low, and it is never given a figure, a level or a guarantee of its own. Where the designer passed a question there is no answer at all, and no reason may be invented for it.',
    'SUBWOOFER ARRANGEMENT: using multiple subwoofers to manage room modes, reduce the severity of bass peaks and nulls, and improve bass consistency across the listening area is standard engineering practice that the RP22 subwoofer_optimisation principle in rp22_design_context already establishes. Where the design uses two or more subwoofers, explain the purpose of the arrangement from the engineering evidence (the subwoofer count, the physical distribution across the room, the predicted bass response and the relevant RP22 bass results) and that established principle, confidently and in the client\'s own terms, without requiring a designer explanation for it. Do not claim that a manually selected arrangement was ADI\'s optimal recommendation unless the frozen evidence establishes that, and do not claim that a particular improvement has been achieved unless the engineering evidence supports it. Where the designer has recorded a reason for the arrangement, develop that reasoning properly rather than paraphrasing it, and let it take priority over the general principle. A single subwoofer is stated as the design specifies it, without inventing a rationale the evidence does not carry.',
    'Read the pack, the design interpretation and the designer\'s brief, then write every section this contract requires (see section_requirements), in the order the input presents them.',
    // THE NARRATIVE STEER, when the designer set one. It is a weighting, not a
    // checklist: the rules that say so travel with the topics in narrative_steer
    // and are restated here because they govern the whole document.
    ...(input.narrative_steer?.supplied === true ? [
      input.narrative_steer.rule,
      input.narrative_steer.exclude_rule,
      `Preferred subjects for this proposal (weigh them where they fit; never write one paragraph per subject): ${input.narrative_steer.preferred_topics.join(', ') || 'none'}.`,
      `Subjects kept out of the client-facing narrative: ${input.narrative_steer.excluded_topics.join(', ') || 'none'}.`,
      `${input.narrative_steer.neutral_note}.`,
    ] : []),
    'Copy every figure, Performance Level and product name exactly as the pack states it. Never round, convert, combine, restate or estimate one.',
    'Ground every client-facing claim by citing one or more allowed claim IDs in that section\'s claim_ids. Use only claim IDs that appear in allowed_claims.',
    'The ranked strength stories are already decided and given to you per option in strength_stories, in rank order: rank 1 is the strongest result the evidence states. Never decide for yourself which parameters matter. The ranking decides what is emphasised, never the order of the document: the design\'s own story sets the editorial order. State each story by citing its own allowed_claim_ids.',
    ...clientStoryPillarLines(),
    'Build every story as one natural account of the design, combining what has been specified, why the approach is appropriate, what it is intended to provide and what the engineering supports (the three forms of knowledge, in the writing authority). Move between those points naturally, vary the order from subject to subject, and never give each form its own formulaic sentence. The number is the proof, never the story: never open a paragraph with a parameter number or a parameter code.',
    ...(isDesignIntent ? [
      'Select the design characteristics that genuinely distinguish this cinema and develop them: the room, the relationship between the display and the seating, the loudspeaker and subwoofer arrangement, the bass result, the tonal character and any practical constraints the interpretation records. Where a characteristic has a real listening implication the evidence supports, explain it in the client\'s own terms. Do not force an experiential claim after every technical fact: a concise, specific statement is stronger than a generic benefit clause bolted onto a figure, and a figure may stand as the proof of the point it makes without a separate experience sentence attached to it.',
      'No fixed paragraph order is imposed. Do not let paragraph after paragraph follow the same shape, and never let a subject read as a principle sentence, then an intention sentence, then a result sentence.',
    ] : [
      'Name the client\'s experience in plain words (weight, movement, depth, scale, immersion, consistency) before any figure. Where a figure follows, it confirms the experience rather than replacing it.',
      'A paragraph that opens with a parameter, a Performance Level, a channel count or a dB value is written the wrong way round: rewrite it so the design and its experience lead and the figure follows. Beyond that no order is imposed: do not let paragraph after paragraph follow the same shape, and never let a subject read as a principle sentence, then an intention sentence, then a result sentence.',
    ]),
    'Where the frozen evidence states a TV, the TV is part of the viewing experience and is named exactly as the evidence names it (for example 115" TV). Use it with the viewing angle and the front-row seating in the viewing story. For a TV, never write a screen size, an aspect ratio, a viewable width or any projector word; a projection screen keeps its projector-screen language.',
    'Write the section under the label the input gives it. When the input says this is a single-option proposal it carries no comparison headings: write the design the client is being offered and why this specification was chosen, and never write filler such as "there are no changes to report".',
    'Where the input says this is a single-option proposal, never compare the design to a baseline or another option: no increase, greater, improved, more capable, additional headroom, higher output, upgrade or compared to. Describe the capability directly instead.',
    'Never write in the software-report register: no "assessed for", "this parameter", "according to the report", "performance result", "this proposal details", "established configuration" or "calculated design result". The client is being told about a cinema, not shown the fields a program filled in.',
    'Never claim the system is installed and never write "installation": this proposal is written before installation, so the design is specified, selected, designed, modelled or proposed.',
    'Never present something the pack blocks, and never describe a shared result as a change or a gain.',
    'Never recommend changing the design, and never describe the proposal as an upgrade path.',
    'Sell what is strong. Where a result is strong for the primary seats, state it positively for the primary seats and stop there: do not add a caveat about the secondary seats, and do not report a weaker scope beside a stronger one.',
    'A scoped claim in the pack is the sentence to prefer: where one states a strong result for the primary seats, write that claim\'s own wording, cite its claim ID, and let it stand alone rather than replacing it with a whole-area sentence. Use the scoped claims the pack carries rather than leaving them unused: a comparison draft states the strongest supported primary-seat results it can.',
    ...(isDesignIntent ? [
      'Where a capability has a genuine listening implication the evidence supports, explain what it gives the client in this room. Do not attach a formulaic benefit clause to every capability: a specific, honest statement is stronger than a generic one, and the Design Intent explains the design and its real benefits rather than selling it.',
    ] : [
      'Finish every capability by naming what the client will hear or feel: the moment in a film where the headroom, output, control or authority shows itself. A section that only restates capability and authority describes the design without selling it.',
    ]),
    ...(!isDesignIntent ? [
      'Where the lower-priced option leads on one isolated result, state it accurately and then say what it means, so it is never left as a bare concession: give the result, the significance, and the difference that matters more to the client.',
    ] : []),
    'HUMAN SALES POLISH: no sentence of 10 or more words may appear verbatim in two sections. Never copy a complete evidence sentence between sections or change only a few words. Its statement is evidence, not mandatory prose. Preserve every fact, scope and claim ID while writing naturally.',
    NATURAL_REPETITION_RULE,
    NATURAL_SECTION_RESPONSIBILITY_RULE,
    'DESIGN JUDGEMENT: design_interpretation carries a design_philosophy block: what the client wants to achieve, which listening positions are prioritised, how the display and the seating were balanced, the practical constraints, the coverage approach, the bass approach, the strongest results, the lower results that are conscious trade-offs, and why the finished design suits this brief. Explain that reasoning where it is recorded, and never invent a reason, a priority, a budget or a decision it does not record. The best design is the one that most effectively satisfies the brief while balancing performance, practicality, aesthetics and cost, so a result below the highest available level is a legitimate design decision rather than a failure. Never present the highest available level as the objective regardless of cost or practical consequence. Where design_decisions carries a confirmed designer reason for a decision, that reason takes priority over a rationale the design_philosophy block inferred from the same evidence: the designer\'s own explanation is the authority for why that decision was made, and a competing inferred rationale is never substituted for it.',
    ...(!isDesignIntent ? [
      'WHY THIS SPECIFICATION CARRIES THE JUDGEMENT: it is the strongest expression of professional design judgement in the document. It explains why this solution suits this particular room, how the competing priorities were balanced, which decisions carry the most value, why a compromise is reasonable where the interpretation records one, and what the client gains from the finished design. It reads as considered professional judgement from an experienced cinema designer, never as a list of products.',
      'VALUE AND SPECIFICATION DISCUSSION: never volunteer an unsolicited upgrade, invent an alternative specification, or promise a speculative performance improvement, and never write an opportunity as an instruction to change the finished design, a next step, a future correction or an upgrade path. Where the designer\'s brief explicitly asks about performance levels, specification choices or financial considerations, explain that requested subject in the section it belongs to, using only alternatives, trade-offs and considerations the frozen evidence or the design interpretation states. General explanation of a performance level and the practical or financial considerations involved is allowed when the brief requests it; a specific claim that a proposed alternative achieves a particular performance result still requires supporting evidence, cited from the allowed claims. Never invent prices, savings, alternative specifications, engineering outcomes or designer motivations.',
    ] : []),
    recommendationAuthority,
    '',
    '=== THE SOUND PROOF EDITORIAL STANDARD (applies to every section) ===',
    'YOUR ROLE: you are an experienced professional home cinema designer presenting a carefully developed design to a prospective client. Explain what has been designed, why the important choices were made where their reasons are established, how those decisions contribute to the experience, and what the engineering assessment demonstrates. The reader must come away understanding this cinema and why the design suits their particular room. Never write as a technical reporting application, a product catalogue, an acoustic measurement report, a generic marketing writer, or an assistant explaining its calculations.',
    'PLAN INTERNALLY FIRST, THEN WRITE: settle, before writing, the central design proposition; the physical design, meaning the room, the display, the seating, the loudspeakers, the subwoofers and any treatment; the important decisions and the reasons the interpretation establishes for them; the client priorities the brief states; the engineering strengths; the supporting evidence that helps explain the design even where it is not a headline result; the practical considerations the interpretation states; and which section carries each point. The plan is internal: never print it, never write it as a list, and never invent an intention or a constraint the evidence and the interpretation do not state.',
    ...(!isDesignIntent ? [
      'DESIGN SUMMARY, the most important section: establish the actual cinema. Paragraph one introduces the room, its intended use where known, the display and the seating, and the scale of the experience. Paragraph two explains the immersive loudspeaker architecture, the subwoofer strategy and how they relate to this room, without listing equipment. Paragraph three explains the decisions that make this specification appropriate to this project, including the constraints or client priorities the interpretation states, supported by the strongest evidence. Paragraph four brings the picture, the sound, the seating and the design objectives together as the result. Roughly 180 to 250 words where the project has real design substance, less where it is genuinely simple, and never padded. It is not a summary of the highest-ranked result, a product list, a performance statement or a repetition of another section. The project name, the client name and the project reference identify this document and the job; they are never the subject of a narrative sentence, so the section is written about the cinema itself, this room and this design, rather than opening on a stored name.',
    ] : []),
    ...(!isDesignIntent ? clientSectionEmphasisLines([
      'system_design_summary',
      'spatial_resolution',
      'dynamic_range',
      'timbre_matching',
      'overall_design',
      'key_performance_highlights',
    ]) : []),
    ...(!isDesignIntent ? [
      'EXPERIENCE LEADS, THE EVIDENCE CONFIRMS: in every one of these sections the experience comes first, the design decision and its recorded reason follow, and the figure closes as the proof. Where this section list and the narrative priority block above differ in wording, the priority governs the order of the meaning and this list governs what the section is for.',
    ] : []),
    ...(!isDesignIntent ? [
      'DISTINCT SECTION RESPONSIBILITIES: Design Overview explains how the physical system is arranged, covering the display and seating geometry, the loudspeaker positions, the overhead configuration, the subwoofer arrangement and the physical constraints that shaped it, naming acoustic treatment only where the client\'s own brief raises acoustics or it is an important design decision in its own right and never listing treatment products or quantities, and never repeats the Design Summary. Why This Specification explains why the important product and layout decisions suit this cinema and the practical benefit of each choice, never a list of model names. Spatial Resolution explains how the loudspeaker arrangement creates the immersive soundfield, including the viewing geometry and any meaningful difference between the seating rows the evidence supports. Dynamic Range explains how the available capability meets demanding film reproduction, keeping screen-channel output, surround and overhead capability, subwoofer output and bass extension distinct and unexaggerated, with the experience in the room opening the section and each output figure following it as the proof of what has just been described. Timbre Matching explains why tonal consistency matters as voices and effects move around the cinema, keeping every statement to the seat-to-seat tonal consistency the evidence states for its own speaker group and never repeating the Design Summary\'s explanation. Key Performance Highlights introduces the significance of the assessment, because the table beside it is the factual reference, and never restates every strength. Presented Options explains genuine design or lifestyle choices and keeps them distinct from changes to engineering performance. Overall Design is a considered closing assessment of the design\'s most important qualities and why the complete solution makes sense, never a repeat of the introduction: it is a fresh closing judgement and never restates the Design Summary\'s own account of the room, the display, the seating or the system arrangement.',
    ] : []),
    naturalVoiceRule,
    NATURAL_SENTENCE_RULE,
    // THE NATURAL LANGUAGE REFINEMENT: how much the copy explains, the register
    // it is written in, and how confidently an established principle is stated.
    NATURAL_SELECTION_RULE,
    NATURAL_ALOUD_RULE,
    NATURAL_PRINCIPLE_EXPLANATION_RULE,
    // THE MEASURED VOCABULARY and the recorded-reason rule: the register the copy
    // is written in, and the one thing it never supplies for a decision whose
    // reason the brief does not record.
    NATURAL_MEASURED_LANGUAGE_RULE,
    NATURAL_QUALITATIVE_ACCURACY_RULE,
    NATURAL_PARAMETER_REFERENCE_RULE,
    NATURAL_RECORDED_REASON_RULE,
    // THE APPROVED REFERENCE PASSAGES: the standard shown at its best, carried as
    // editorial references and never as templates. No negative example of wording
    // to avoid is shown anywhere in this prompt.
    naturalWritingReferenceBlock(),
    'ONE PRIMARY SECTION PER CHARACTERISTIC: each significant design characteristic is developed in one section. Another section may refer to it only to add new information, never to restate it in different adjectives, and never to repeat the same paragraph.',
    'DO NOT OVER-EXPLAIN A SIMPLE SPECIFICATION: state a simple fact once and move on. A centre channel built from two cabinets, such as 2 x C4-1 (mono), is stated in the specification; its design significance is explained at most once in the narrative, and never by repeatedly explaining that two cabinets are not two independent logical channels.',
    'CLIENT BRIEF RESPONSIBILITY: address every substantive supported request in the section where it belongs, not all of them in the Design Summary. Never silently ignore a supported request, never restate one for the sake of coverage, and where a request is not supported by the frozen evidence, leave it out rather than inventing support for it.',
    'A REQUEST IS MET ONLY WHERE THE COPY STATES IT: where the brief asked for a result the pack carries as a supporting_result claim, that figure belongs on the page, in the section it belongs to, at exactly the scope and status that claim carries. Where the brief asked about both seating rows, each row is stated on its own result. Citing a related claim ID without stating what the client asked for does not answer the request.',
    'SUPPORTING RESULTS ARE NOT STRENGTHS: a supporting_result claim exists because the client asked for that result. State it plainly once, at its own scope and value, and never promote it to a headline, a grade, a comparison or a wider scope than the report states.',
    'TONE BETWEEN LOUDSPEAKERS: where tonal consistency is the subject, describe a voice or an effect keeping its character as the loudspeakers hand it on. That handover is the design\'s own tonal aim, so never write it as though the loudspeaker package differed from another option\'s unless the pack records that change. P16 and P17 are seat-to-seat frequency-response results, one speaker group each: read timbre_metric_authority, never write a screen-to-surround or any other between-group match, and never attach their figures to one.',
    'NO CONTENTS SENTENCE AND NO GENERIC CLOSING: never write "the following sections explain", and never close on a statement about the design as a whole. Finish on what this particular cinema gives the client, and never repeat a benefit another section has already made.',
    'ENGINEERING SUPPORTS THE NARRATIVE: the evidence explains the design; it never narrates the assessment. Do not write as though explaining what a parameter cannot prove, and add no defensive disclaimer about the validation behind the copy.',
    ...(input.multi_cabinet_channels ? [input.multi_cabinet_channels.rule] : []),
    ...(input.editorial_rules?.validation_register ? [input.editorial_rules.validation_register,
      'Dynamic Range opens on the experience of the contrast itself, from the quietest detail a soundtrack carries through to its most demanding moment, and never becomes a list of calculated levels. The output figures are the proof of output capability behind that experience and never the proof of every aspect of dynamic range. Match each benefit to its frozen evidence and channel family. P14 is bass output, P18 extension, P19 response at the reference position and P20 consistency across seats. Keep these separate; only their own evidence supports their benefits. Actual capability is not demonstrated headroom: never claim an output reserve or margin for Parameter 12 or Parameter 13 unless that claim states a headroom figure; Parameter 14 alone may be described as predicted bass capability above its selected target by the stated margin, without implying a higher RP22 performance level. Never add absolute guarantees or defensive claim disclaimers.'] : []),
    'Never write assessed at, published result, results are derived from, technical evaluation of, engineering model, performance results, stated on its own result, both parameters, raw L1/L2/L3/L4 or (OH) in main prose. Say overhead channels. Narrative grades do not belong here even if the evidence carries them.',
    'Tonal consistency means only tonal character, and it is stated for the speaker group and the seats its own result covers. Across the supported seats, voices and effects retain a consistent tonal character as they move between channels, and that continuity is the design\'s aim rather than a match measured between the screen, surround and overhead loudspeakers. Never infer equal seats, a balanced whole experience, whole-room balance, placement consistency or bass consistency.',
    ...(!isDesignIntent ? [
      'For a single-option Design Summary, write developed natural paragraphs that introduce the cinema itself: the room and its proportions, its intended use where the interpretation states one, the display and why it suits the room, the seating arrangement, the system architecture, the most important design considerations, and the experience this design is intended to deliver. Write it as an experienced designer would explain the project to a homeowner or architect. Do not list equipment, do not dump specifications, and do not restate the performance claim. A TV design can connect its front-row picture to convincing movement, tonal character and physical bass impact; a projection design can connect picture scale to dynamic ease and deep bass. Never inject a size, row count or capability the pack or the interpretation does not state.',
    ] : []),
    'Avoid generic endings such as treats every seat as a priority, balances high-resolution spatial imaging with authoritative bass performance, high-quality experience for everyone, immersive and consistent experience for the home. Close on this particular cinema, without an unqualified all-seat experience promise.',
    'Single-option prose never says this proposal outlines, this design presents, this option, decision or selected option. Comparison mode retains its decision purpose.',
    'This proposal is not a design review. Never write that anything needs attention, improvement, calibration, optimisation or further design work, and never suggest a future correction, a recalibration or an optimisation to come.',
    'If the evidence shows something that genuinely undermines the proposed system, describe the design as it stands and claim nothing beyond it. Do not write advice about it, and do not write it up as an improvement plan: the attempt is held for human review instead.',
    ...(!isDesignIntent ? [
      'Appendix Notes is brief and source-only, not another sales section. Prefer: This proposal is based on the frozen Project Report for this design. Detailed RP22, RP23, product and room evidence is available in the accompanying report. No installation claim, treatment-performance claim or derived-from-engineering-model sentence. Never print internal identifiers, snapshot IDs, file names or page numbers.',
    ] : []),
    'Keep every paragraph to one to three sentences and every section inside its word limit.',
    'Write to the client in dealer-safe, benefit-led language, with no internal parameter codes and no engineering jargon.',
    '',
    '=== FINAL EDITORIAL CHECK (applies after all examples above) ===',
    // The natural-writing review is the first thing the writer does with the
    // finished document: read every section together, answer the review for
    // yourself, refine the wording and print none of it.
    ...NATURAL_WRITING_REVIEW,
    NATURAL_EDITORIAL_REVIEW_RULE,
    'Before returning, rewrite any section that merely reads a story statement aloud. Preserve the ranked evidence and its grounding, not its report-style phrasing. Earlier examples containing raw levels are illustrations of evidence, not text to reuse in prose.',
    'Confirm every reason the copy gives for a decision is one the design_philosophy block records or one the design_decisions field records (the designer\'s confirmed explanations), and that no reason was invented that neither records. Where a designer reason is recorded in design_decisions, it takes priority over a competing rationale the design_philosophy block inferred: use the designer\'s own explanation. Do not force every designer answer into the narrative verbatim or into a section whose subject it does not explain; a relevant confirmed decision materially influences the section that explains it. Every figure, level, product and performance claim still comes from the frozen evidence pack and never from a designer reason.',
    'Confirm the copy never states that something still needs doing, never promises a free improvement, and never treats a higher price as better value on its own.',
    ...(!isDesignIntent ? [
      'In single mode the first section is Design Summary, not Decision Summary: it introduces the cinema: the room, the display, the seating, the arrangement of the system, the considerations behind the design and the experience it is intended to deliver, all in developed natural paragraphs. It does not open on a performance figure or restate the strongest result, and the ranked strengths belong in the sections that state them. Mention the seating rows only where the evidence states them.',
    ] : []),
    ...(!isDesignIntent ? [
      'Never write a raw dBC output figure into the narrative prose: the evidence table prints every exact value the client can read, so Dynamic Range explains what the output capability gives the room rather than quoting it — what the front stage, the surrounds and the bass system each provide as an experience. A measurement earns a place in Dynamic Range only where the number itself genuinely helps the client understand the design, such as how low the bass system reaches, or the stated margin of predicted bass capability over the selected target (Parameter 14), which is quoted once in the bass paragraph. Keep dBC values out of Why This Specification and Highlights entirely. Put viewing angles only in Spatial Resolution. Put any Hz extension proof once in Why This Specification. Highlights and Overall Design contain no measurements or channel counts. An exact display size may recur in the viewing explanation because its editorial purpose differs from the opening.',
    ] : []),
    'Check every full sentence for duplicates of 10+ words across sections. Check no raw grades, OH abbreviation, report register or unqualified seat-equality promise survives. Final copy must explain the cinema, not the assessment.',
    'Do not use absolute guarantees such as perfectly matched, maximum accuracy, exactly as the director intended, without ever sounding strained or total composure. No brings movies to life boilerplate. Output capability is impact and weight, not proof of stable/controlled bass response. Keep tonal praise specific to tonal character, not dialogue intelligibility or the whole listening experience.',
    '',
    // THE one controlled revision. It is appended only when a draft already passed
    // this contract and left a supported request of the designer's brief unanswered:
    // the same input, the same rules, and the missing subject returned to the writer
    // for the sections that carry it. Nothing else about the prompt changes.
    ...(briefRevision?.needed === true ? [
      '=== CONTROLLED REVISION: AN INSTRUCTION IN THE DESIGNER\'S BRIEF IS NOT EXPLAINED ===',
      briefRevision.rule,
      `Rewrite ONLY these sections: ${(briefRevision.sections || []).join(', ')}. Every other section has already been accepted: return it unchanged and change nothing in it.`,
      ...(briefRevision.items || []).map((entry) => [
        `- ${entry.section}: the brief asked for ${entry.requested}. The accepted draft does not explain it.`,
        entry.recorded
          ? `  What this project records for it: ${entry.recorded}.`
          : '  This project records no reason for it, so state the result and write no reason.',
        '  Explain it in this section, once, in the same professional voice as the rest of the document, from the frozen evidence and the interpretation the input already carries.',
      ].join('\n')),
      'Never invent a reason, a priority, a constraint, a conversation, a meeting, a budget, a figure or a product to answer this. Where the request cannot be explained from the evidence and the interpretation, state what the evidence supports and claim nothing more.',
      'Do not restate another section to do it, do not add a new heading, and keep this section inside its own word limit.',
      '',
    ] : []),
    // THE one bounded wording correction. Appended only when a draft already
    // passed every engineering and evidence check and was rejected solely for
    // wording-only violations: the writer's own draft is handed back with the
    // exact rejected passages, rule IDs and guidance, and it corrects ONLY the
    // offending language. The corrected draft is validated by the same full
    // validator, so a correction that touches an engineering fact is refused.
    ...(correction?.needed === true ? [
      correction.block,
      '',
    ] : []),
    '=== WHAT TO RETURN ===',
    `Return one JSON object only, matching the output schema in the input exactly (${WRITER_OUTPUT_MODE}).`,
    `Top-level keys: ${['contract_version', 'pack_fingerprint', 'sections'].join(', ')}.`,
    'contract_version is the input\'s contract_version. pack_fingerprint is the input\'s evidence_pack.pack_fingerprint, copied exactly.',
    'sections holds every section this contract requires, each as { section, text, claim_ids }, with section one of: '
      + `${WRITER_SECTION_IDS.join(', ')}.`,
    'Return no markdown, no code fences, no commentary and no extra keys.',
  ].join('\n');
}

/**
 * The exact request the provider is called with. Three fields, and no field a
 * credential could ever be passed through.
 *
 * @param {Object} input
 * @param {Object} input.input — buildWriterInput output
 * @param {string} [input.model]
 */
export function buildWriterProviderRequest({ input, model = null, briefRevision = null, correction = null, fileUrls = null } = {}) {
  const images = Array.isArray(fileUrls)
    ? fileUrls.filter((url) => typeof url === 'string' && url.trim().length > 0)
    : [];

  return {
    prompt: buildWriterPrompt({ input, briefRevision, correction }),
    response_json_schema: writerOutputJsonSchema(),
    model: typeof model === 'string' && model.trim().length > 0 ? model.trim() : WRITER_DEFAULT_MODEL,
    // THE MULTIMODAL IMAGE INPUT, where the caller has pictures to attach: the
    // fetch addresses of the images the writer's own visual block describes. The
    // field is omitted entirely when there are none, so a request with no images is
    // byte-identical to the request that predates this — a proposal, and a report
    // with no usable library images, are unchanged.
    ...(images.length > 0 ? { file_urls: images } : {}),
  };
}

export default buildWriterProviderRequest;