/** SHA-256 of the bundled validator sources; regenerated with every rules edit. */
export const VALIDATOR_SOURCE_MANIFEST = Object.freeze({
  'base44/shared/proposalWriter/writerOutputValidator.js': '9abc142f30279dc77f186b95d430b6f13916997492e19f8b086f11bedca0284c',
  'base44/shared/proposalWriter/writerProseScanner.js': '341f6e039708f6c356f15169d62d1425a19cd898eeac1ca66a4691e9265f2a38',
  'base44/shared/proposalWriter/writerOutputTextRules.js': 'ab466312229102216109229586a07a9e6401820ba3a548f726ee6c5c2618ed74',
  // The established-principle register: which sentences are design reasoning (an
  // established principle, or the designer's recorded intention) rather than a claim
  // of achieved performance, and the absolute guarantees about the room's own
  // behaviour that are never reasoning. Hashed so a draft can always be traced to the
  // exact boundary it was read against.
  'base44/shared/proposalWriter/writerPrincipleRegister.js': '14cd7139d5667f70843ea8a604d5282dd2df6372e901818970e4b7d7ff8a0957',
  'base44/shared/proposalWriter/writerEditorialRules.js': '08776775a8a4bdd2f2a167804809d5db51d750c4a01a1ac8ee23830761475324',
  'base44/shared/proposalWriter/writerSalesPolishRules.js': '2e8d0a0c206141d99d9af0c48b24a565002bd7f63497dedffc431b14b4ae8825',
  'base44/shared/proposalWriter/writerProductScope.js': '2e1bd48eec1fc597878a3478c5ed550a92695a6aeb87c19bd55770cfbd318032',
  'base44/shared/proposalWriter/writerVocabulary.js': '53b036a5ffa43d63c12fdebac504562345ce40852869fc365f0321db46e792b5',
  'base44/shared/proposalWriter/writerClausePrecision.js': '92cb1f4cc600bb50c2790e3c1b4b08b5e35b10f8adfefa19a95ff70a895dd092',
  'base44/shared/proposalWriter/writerViolationAudit.js': '4cc361d1c96a101fc29330d740cef2184ae5650fd3cc64e253892d004efdb0b9',
  'base44/shared/proposalWriter/writerDesignStageRules.js': 'a26d5ff98a2eaf4f6de929cc62cba7e7bc2632540f12d44ded72e8cb7f8bdbb7',
  'base44/shared/proposalWriter/writerContractSchema.js': 'd09b33dae94d1e129f11226ab3fdd8cc1dd880856bee0950be3e617c2947c536',
  'base44/shared/proposalWriter/writerMultiCabinetRules.js': '3712df21bd72353af0a9d8ab75a1efa20755856d65229887a1f8dc5bad29b172',
  'base44/shared/proposalGeneration/generationStatuses.js': '2273b2e8408a426eeb137d9ae2f34c428a8e934dc0529134e9889aae75103b28',
  'base44/shared/proposalWriter/writerCabinetLanguage.js': '18e37edb21bd8422c6293c5fde809984d185e7188d0fe4a12fa2ff352d4b72c7',
  'base44/shared/proposalWriter/writerValidationRegister.js': '634502ab07c0bf1b13cfe0879d1e2ca2e85f0419c94f377b266a977c38c07b96',
  'base44/shared/proposalWriter/writerInputBuilder.js': '47377f31a9494f70f0deff1da3bc9f0a5124cbabd1c50a196650d4a61c31ea63',
  // The client narrative register: the story the client is buying, never the
  // mechanism that produces it. It states the instruction the writer reads and the
  // phrasing the narrative sanitizer removes, so a draft can always be traced to the
  // exact register it was written and read under.
  'base44/shared/clientNarrativeRegister.js': '0b8a572d3c594ecc91c2396940cc96685f9b48282197db6e2a245fbed1adb7d9',
  // The performance language register: the strength of the client-facing language
  // is decided by the Performance Level the evidence states. It holds the register
  // the shared strength statements are composed from and the rules the writer is
  // held to, so a draft can always be traced to the exact language authority it was
  // written under.
  'base44/shared/performanceLanguageAuthority.js': '0e815b1800fb1e7dc4eb1f56b7b7024ab6ed410ee84b4b61ebe2f7ac8cae56d2',
  // The narrative steer: the designer's three-state preference over the topics ADI
  // offers. It carries the rule the writer reads — a preference is an ingredient,
  // never a section plan — so a draft can always be traced to the exact steer it was
  // written under. Beside it is the exclusion backstop: the module that removes a
  // sentence about an excluded topic from the client-facing narrative, and touches
  // no evidence, no result and no table while doing it.
  'base44/shared/proposalWriter/writerNarrativeSteerRules.js': '1fa28842cc3550cdd01e9c0130b584d1615c981c67a889ee38690d7eb7e14cf0',
  'base44/shared/proposalNarrativeExclusions.js': '5a16e430aa88673e48e72c8fb4ff1b68c0283e7da10eb0199f9ffe37fd035f76',
  // The Design Summary brief for a TV media room: it states the requirement and
  // the word limit the section is written and validated under, so a draft can be
  // traced to the exact brief it was read against.
  'base44/shared/proposalWriter/designSummaryBrief.js': '9b300ce91d14fbada0065ccbdf9458b01f4cd7253d5ca687c9f753ddb8e57a95',
  'base44/shared/proposalWriter/writerOptionEvidenceSummary.js': '7b503c07645b7437940de705ec809f4da5ddbccaf0c6d5b7212c516589c79524',
  'base44/shared/proposalWriter/writerPromptBuilder.js': '11ecdbd8ba57a0ece96cfd75f81fd9ebdf32250ee4fe7016f88b4a02efcf6403',
  'base44/shared/proposalWriter/writerSectionMapping.js': '822e2cb2b7fea7df336628bdf9e0438faecb93d6c300fc240297235df14d900d',
  'base44/shared/proposalWriter/writerDesignContext.js': 'affbd97cf327a4e569f81d5c59da0bf6565c17423c32a34b0ff58b98e1866912',
  'base44/shared/proposalEdit/completeDocumentValidation.js': '5eaeab43e6af2b8792bd400b022e710c1624256b301465e31849850ee863d159',
  'base44/shared/proposalWriter/validatorProvenance.js': '9ed8e45b5803a199edf6d75ddb1c0e225b27ac6a63d1986c4607cdd93be21dd5',
  'base44/shared/proposalEvidence/proposalEvidenceWording.js': 'f9b5c6ceb3063240ab6ba3374c38b96f9abf95dcdb87892510f3815192ef5594',
  'base44/shared/proposalEvidence/evidencePackSchema.js': '2b25a3401a24a65944a441741b47e8ca5fff25271bb7d364c8b834ed04303631',
  // The supporting results the brief asked for: what the pack may state because
  // the client asked for it, at the scope and status the reports record.
  'base44/shared/proposalEvidence/proposalBriefRequests.js': '006dc2c68897fabaedd4c35e02f34e76fa39ab372789860f12099dfeebd18b13',
  'base44/shared/proposalEvidence/proposalSupportingResults.js': '0d8265bcb32df1e05ced4b6405df02978bfccf2afadd88f36b38f042eb2ff65e',
  // The design philosophy: the judgement behind the recommendation, carried by
  // Stage 1 and by the writer's editorial instructions. It states no figure and
  // changes no acceptance; it is hashed so a draft can be traced to the exact
  // reasoning authority it was written under.
  'base44/shared/designPhilosophyAuthority.js': '1a4ba9bfd86d5bd17cabac52e6dab78359f601f92b14e0a63703d679915179fc',
  'base44/shared/adiDesignPhilosophy.js': 'cd275e6c1ba1c768378b701e5494f10042b550727e806ca1f24716d0c06103cc',
  'base44/shared/adiProjectInterpretation.js': '8a58dc33c6547ea3b1c6baed5a9b7605ab8f18f8f780b4b5864caef1b3971fae',
  // The check between the saved interpretation and the frozen evidence, which now
  // also holds the design philosophy's own statements to it.
  'base44/shared/proposalWriter/writerInterpretationEvidenceCheck.js': '2e88d5c9c5b3bc2e9000adaf528dc98e52c073c7c92fecc02c2030199fc412a0',
  // The verification-disclaimer rule: the wording a proposal never carries. A
  // capability is stated confidently and is never made conditional on a future
  // process, while internal accuracy stays exactly where it was.
  'base44/shared/proposalWriter/writerVerificationDisclaimerRules.js': 'cb706afc82111b4370968a063d440bfd04ef2a86d2a8ac5d6ca35f894364baa9',
  // The client-facing calibration language the proposal voice is written under:
  // hashed so a draft can always be traced to the language authority it was
  // written against.
  'base44/shared/clientFacingCalibrationLanguage.js': 'd11e628655ac5efec828f303a6a5361996c409226ceeae424def051d752f4578',
  // The Sound Proof Natural Writing Standard: the editorial instructions the
  // proposal is written to, and the approved reference passages it shows instead
  // of any example of wording to avoid. Hashed so a draft can always be traced to
  // the standard it was written under.
  'base44/shared/proposalWriter/writerNaturalWritingStandard.js': '96ca771c8aa860e7105b2436c6a967f519990f4b50da25655d87864d49456f04',
  // The deterministic half of that standard: the punctuation rule, the stock
  // connectives, the mechanical repeated opener and the generic claim phrases.
  'base44/shared/proposalWriter/writerNaturalWritingRules.js': 'e1ea352c89ca451359785e853d46345c2c8b9cb3ec146a98b2946b36f9c99aa5',
  // The RP22 professional design context: the established v1.2 principles offered to
  // the Stage 1 interpretation and to the writer, each with the section reference it
  // was read under, its applicability, what it does not establish and its safe use.
  // Hashed so a draft can always be traced to the exact professional context, and the
  // exact applicability rule, it was written against.
  'base44/shared/rp22DesignContext.js': '5e1057e2548fcdb5c8c40f2d961b1004b2d3dd8c13ed4b64fb3b787c2d331661',
  // The check between a saved interpretation and the frozen evidence, which removes
  // only the statements the evidence actually contradicts.
  'base44/shared/proposalClarification/verifiedInterpretation.js': '86d6c7038393d25b4ee9bdcfedd6202cb7e3e7072409dd070001d32b030caf34',
  // WHAT P16 AND P17 ACTUALLY MEASURE. The two tonal results are seat-to-seat
  // frequency-response variances, one loudspeaker group each, so a seat-to-seat
  // figure is never written as a match between loudspeaker groups. Hashed so a
  // draft can always be traced to the exact metric authority it was written under.
  'base44/shared/proposalWriter/writerTimbreMetricAuthority.js': '5d2066a278b8433dd8fdd70f6e98a2dacf64b87e602164beb221bfd7c37277ff',
});