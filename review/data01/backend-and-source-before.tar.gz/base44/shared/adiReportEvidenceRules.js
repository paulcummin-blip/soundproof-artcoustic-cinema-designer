/**
 * adiReportEvidenceRules.js (shared)
 * ----------------------------------
 * The evidence rules for ADI-authored client-facing reports (System Design
 * Summary and System Design Comparison).
 *
 * Reports are structured around the three RP22 design structures:
 *   Spatial Resolution, Dynamic Range, Timbre Matching.
 *
 * A parameter is never the point of the writing. Parameters appear only as
 * evidence inside those structures, and only when the result is reliable.
 * This module decides which results are allowed to appear, and which
 * structure each one supports.
 *
 * Bass seat-to-seat consistency (P20) is NOT excluded. It is admitted
 * conditionally: a current, positive (L3 or L4) consistency result is genuine
 * client evidence for the chosen bass layout. A weak, provisional or
 * unhelpful one is omitted rather than reported, because a client-facing
 * report explains the selected design and never criticises it.
 *
 * It reads the frozen Engineering Snapshot passively. It never calculates,
 * grades, regroups or invents a result: it only excludes, labels and sorts
 * what the snapshot already states.
 *
 * Pure: no React, no side effects, no runtime-specific APIs.
 */

import { readCapabilityFields } from './parameterCapabilityFields.js';

/** The three RP22 design structures, in report order. */
export const REPORT_STRUCTURES = Object.freeze([
  'Spatial Resolution',
  'Dynamic Range',
  'Timbre Matching',
]);

/**
 * Parameters that are never referenced in a client-facing report, whatever the
 * snapshot contains. Each carries the reason so the exclusion is auditable.
 */
export const EXCLUDED_PARAMETERS = Object.freeze({
  8: 'not used',
  15: 'not used',
  21: 'not used',
});

/**
 * Which design structure each parameter supports in a client-facing report.
 *
 * This is the REPORT mapping, deliberately set by the report design and not
 * copied from the compliance surfaces. P4, P6 and P10 are consistency results:
 * they are evidence for how evenly sound is presented across the room, so they
 * support Spatial Resolution in this narrative, alongside the geometry results.
 */
export const PARAMETER_STRUCTURE = Object.freeze({
  1: 'Spatial Resolution',
  2: 'Spatial Resolution',
  3: 'Spatial Resolution',
  4: 'Spatial Resolution',
  5: 'Spatial Resolution',
  6: 'Spatial Resolution',
  7: 'Spatial Resolution',
  9: 'Spatial Resolution',
  10: 'Spatial Resolution',
  11: 'Spatial Resolution',
  12: 'Dynamic Range',
  13: 'Dynamic Range',
  14: 'Dynamic Range',
  16: 'Timbre Matching',
  17: 'Timbre Matching',
  18: 'Timbre Matching',
  19: 'Timbre Matching',
  20: 'Timbre Matching',
});

/** Plain-language name for each result, used in prose and in the table. */
export const PARAMETER_PLAIN_LANGUAGE = Object.freeze({
  1: 'Seat-to-wall distance',
  2: 'Discrete channels',
  3: 'Screen speaker placement',
  4: 'Screen consistency',
  5: 'Horizontal spacing',
  6: 'Surround level consistency',
  7: 'Front wide position',
  9: 'Overhead spacing',
  10: 'Overhead level consistency',
  11: 'Surround speaker placement',
  12: 'Screen Dynamic Range',
  13: 'Non-screen Dynamic Range',
  8: 'Upfiring speaker allowance',
  14: 'LFE and subwoofer Dynamic Range',
  15: 'Background noise assumption',
  16: 'Screen timbre',
  17: 'Surround timbre',
  18: 'Bass extension',
  19: 'Bass response',
  20: 'Bass consistency',
  21: 'Early reflection assumption',
});

/**
 * Level and status values that mean the result is not usable as evidence.
 * Nothing here is ever inferred: an unusable result is simply omitted.
 */
const UNUSABLE_LEVELS = new Set(['', 'N/A', 'NA', 'NONE', 'NOT CALCULATED', 'NOT_ASSESSED', 'NOT_CONFIGURED']);
const UNUSABLE_STATUS = /unreliable|provisional|stale|waiting|excluded|not[_ ]?calculated|pending|incomplete|assumed|unknown/i;

/**
 * Strip the Engineering Authority { statement, confidence, source } wrapper.
 * Plain values pass through unchanged.
 */
export function statement(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value.statement ?? null;
  return value;
}

/** True when this parameter may appear in a client-facing report at all. */
export function isReportParameter(parameterId) {
  const id = Number(parameterId);
  if (!Number.isFinite(id)) return false;
  if (EXCLUDED_PARAMETERS[id]) return false;
  return Boolean(PARAMETER_STRUCTURE[id]);
}

/** True when the result is reliable enough to be used as report evidence. */
export function isReliableResult(entry) {
  if (!entry) return false;
  const level = typeof entry.achieved_level === 'string'
    ? entry.achieved_level.trim().toUpperCase()
    : entry.achieved_level == null
      ? ''
      : String(entry.achieved_level).trim().toUpperCase();
  if (UNUSABLE_LEVELS.has(level)) return false;
  const status = entry.status ?? entry.reliability ?? entry.authority_status ?? null;
  if (typeof status === 'string' && UNUSABLE_STATUS.test(status)) return false;
  // A level with no readable value is still usable evidence when it is an
  // assessed level (for example a pass or fail level with no dB figure).
  return true;
}

/** The level and value of a result, or null when it is not reliable. */
export function readReliableResult(entry) {
  if (!isReliableResult(entry)) return null;
  const level = entry.achieved_level ? String(entry.achieved_level).trim() : null;
  const raw = entry.formatted_value ?? entry.display_value ?? entry.raw_value ?? entry.formatted ?? null;
  const value = raw == null ? null : String(raw).trim();
  if (!level && !value) return null;
  return {
    level,
    value,
    text: [level, value].filter(Boolean).join(' · '),
    ...readCapabilityFields(entry),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// P20: bass seat-to-seat consistency, admitted conditionally
// ─────────────────────────────────────────────────────────────────────────────

/** The levels a report may use as positive bass consistency evidence. */
export const P20_POSITIVE_LEVELS = Object.freeze(['L3', 'L4']);

/** Plain-language rule text, reused by the prompts and the audit log. */
export const P20_USE_RULE = [
  'Bass consistency may be used only when it is assessed, current, positive (L3 or L4) and useful across more than one seat.',
  'Where it is used it explains the chosen bass layout: more even bass across the seating area, and less difference between the strongest and weakest seat.',
  'It is explanation only. It never becomes a redesign suggestion, a placement change or a new recommendation.',
].join(' ');

/** Plain-language rule text for the case where P20 cannot be used. */
export const P20_OMIT_RULE = 'Bass consistency is used only when the result is current, positive and useful. Where it is weak, provisional or missing it is left out of the report rather than reported as a limitation.';

const P20_REASONS = Object.freeze({
  not_assessed: 'Not assessed for this design.',
  not_current: 'Not current (provisional, stale or waiting).',
  not_positive: 'Not used in this report unless the result is strong.',
  single_seat: 'Not useful for a single-seat room.',
});

function p20Level(source) {
  // The frozen snapshot states the consistency floor as project_floor /
  // primary_floor; the generic achieved_level / level names are also read so the
  // rule works on a headline row or a raw result entry.
  const raw = source?.project_floor ?? source?.primary_floor ?? source?.secondary_floor
    ?? source?.achieved_level ?? source?.level ?? null;
  if (raw == null) return '';
  return String(raw).trim().toUpperCase();
}

function p20SeatRows(snapshot) {
  const rows = snapshot?.bass?.p20?.per_seat;
  return Array.isArray(rows) ? rows : [];
}

/**
 * Decide whether this design's bass seat-to-seat consistency may be used.
 *
 * Usable only when all four hold: the result is assessed, it is current (never
 * provisional, stale or waiting), it is positive (L3 or L4) and the room has
 * more than one seat for consistency to mean anything.
 *
 * @param {Object} snapshot — frozen Engineering Snapshot
 * @param {Object} [entry] — an explicit result entry (defaults to snapshot.bass.p20)
 * @returns {{ usable: boolean, level: string|null, value: string|null, reason: string|null }}
 */
export function assessP20(snapshot, entry = null) {
  const source = entry || snapshot?.bass?.p20 || null;
  const level = p20Level(source);
  if (!level || UNUSABLE_LEVELS.has(level)) {
    return { usable: false, level: null, value: null, reason: P20_REASONS.not_assessed };
  }
  if (UNUSABLE_STATUS.test(String(source?.status ?? ''))) {
    return { usable: false, level: null, value: null, reason: P20_REASONS.not_current };
  }
  // Per-seat results carry their own status: when none of them is current the
  // room-level figure is not current either.
  const seats = p20SeatRows(snapshot);
  if (seats.length > 0 && !seats.some((seat) => !UNUSABLE_STATUS.test(String(seat?.status ?? '')))) {
    return { usable: false, level: null, value: null, reason: P20_REASONS.not_current };
  }
  const seatCount = Array.isArray(snapshot?.seats) && snapshot.seats.length > 0
    ? snapshot.seats.length
    : seats.length;
  if (seatCount < 2) {
    return { usable: false, level: null, value: null, reason: P20_REASONS.single_seat };
  }
  if (!P20_POSITIVE_LEVELS.includes(level)) {
    return { usable: false, level: null, value: null, reason: P20_REASONS.not_positive };
  }
  const raw = source.formatted_value ?? source.display_value ?? source.raw_value ?? source.formatted ?? null;
  return { usable: true, level, value: raw == null ? null : String(raw).trim(), reason: null };
}

/** The structure a parameter supports, or null when it is excluded. */
export function structureForParameter(parameterId) {
  const id = Number(parameterId);
  if (!isReportParameter(id)) return null;
  return PARAMETER_STRUCTURE[id] || null;
}

/** Plain-language name for a parameter, falling back to its supplied title. */
export function plainLanguageName(parameterId, fallbackTitle) {
  const id = Number(parameterId);
  return PARAMETER_PLAIN_LANGUAGE[id] || fallbackTitle || `P${id}`;
}

function parameterRows(snapshot) {
  const list = snapshot?.rp22?.parameter_headlines;
  return Array.isArray(list) ? list.filter((row) => row && row.parameter_id != null) : [];
}

/**
 * Split the snapshot's parameter results into the three design structures,
 * plus the list of results that are deliberately not used.
 *
 * @param {Object} snapshot — frozen Engineering Snapshot
 * @returns {{
 *   byStructure: { [structure: string]: Array<Object> },
 *   used: Array<Object>,
 *   omitted: Array<{ parameter_id: number|null, label: string, reason: string }>,
 * }}
 */
export function splitParameterEvidence(snapshot) {
  const byStructure = {
    'Spatial Resolution': [],
    'Dynamic Range': [],
    'Timbre Matching': [],
  };
  const used = [];
  const omitted = [];

  for (const row of parameterRows(snapshot)) {
    const id = Number(row.parameter_id);
    const label = row.title || plainLanguageName(id);

    if (EXCLUDED_PARAMETERS[id]) {
      // Plain language only: an excluded result is never named by its
      // parameter code in anything the writer reads.
      omitted.push({ parameter_id: id, label: plainLanguageName(id, label), reason: EXCLUDED_PARAMETERS[id] });
      continue;
    }
    const structure = structureForParameter(id);
    if (!structure) {
      omitted.push({ parameter_id: id, label, reason: 'No client-facing structure.' });
      continue;
    }
    // Bass consistency passes its own conditional rule, never the generic one.
    if (id === 20) {
      const assessment = assessP20(snapshot, row);
      if (!assessment.usable) {
        omitted.push({ parameter_id: id, label, reason: assessment.reason });
        continue;
      }
      const p20Entry = {
        parameter_id: id,
        structure,
        label,
        level: assessment.level,
        value: assessment.value,
        text: [assessment.level, assessment.value].filter(Boolean).join(' · '),
      };
      byStructure[structure].push(p20Entry);
      used.push(p20Entry);
      continue;
    }
    const result = readReliableResult(row);
    if (!result) {
      omitted.push({ parameter_id: id, label, reason: 'Not reliable or not calculated.' });
      continue;
    }
    const entry = {
      parameter_id: id,
      structure,
      label: plainLanguageName(id, row.title),
      level: result.level,
      value: result.value,
      text: result.text,
      ...readCapabilityFields(result),
    };
    byStructure[structure].push(entry);
    used.push(entry);
  }

  return { byStructure, used, omitted };
}

/**
 * The bass results, with their reliability stated rather than assumed.
 *
 * P14, P18 and P19 are usable only when the snapshot states a reliable result
 * for them. P20 is admitted by its own rule (assessP20): a current, positive
 * consistency result is evidence for the chosen bass layout, and anything
 * weaker is omitted with the reason recorded.
 *
 * @param {Object} snapshot
 * @returns {{
 *   p14: Object|null, p18: Object|null, p19: Object|null, p20: Object|null,
 *   usable: Array<Object>,
 *   omitted: Array<{ parameter_id: number, label: string, reason: string }>,
 * }}
 */
export function resolveBassEvidence(snapshot) {
  const bass = snapshot?.bass || {};
  const omitted = [];
  const pick = (id, entry, extra = null) => {
    const source = extra ? { ...entry, ...extra } : entry;
    const result = readReliableResult(source);
    const label = plainLanguageName(id);
    if (!result) {
      omitted.push({
        parameter_id: id,
        label,
        reason: entry ? 'Not reliable or not calculated.' : 'Not present in the calculated data.',
      });
      return null;
    }
    // The capability fields belong to the parameter's own row; the bass block
    // carries only the level and value, so they are read from that row.
    const row = parameterRows(snapshot).find((item) => Number(item.parameter_id) === id);
    return {
      parameter_id: id, label, level: result.level, value: result.value, text: result.text,
      ...readCapabilityFields(row),
      ...readCapabilityFields(result),
    };
  };

  const p14 = pick(14, bass.p14);
  const p18 = pick(18, bass.p18);
  const p19 = pick(19, bass.p19?.rsp, bass.p19?.rsp
    ? { achieved_level: bass.p19.rsp.level, formatted_value: bass.p19.rsp.display_value ?? bass.p19.rsp.raw_value }
    : null);

  // Bass seat-to-seat consistency is admitted by its own rule, never by
  // exclusion and never by the generic reliability test alone.
  const p20Assessment = assessP20(snapshot);
  const p20 = p20Assessment.usable
    ? {
      parameter_id: 20,
      label: plainLanguageName(20),
      level: p20Assessment.level,
      value: p20Assessment.value,
      text: [p20Assessment.level, p20Assessment.value].filter(Boolean).join(' · '),
    }
    : null;
  if (!p20) {
    omitted.push({ parameter_id: 20, label: plainLanguageName(20), reason: p20Assessment.reason });
  }

  return {
    p14,
    p18,
    p19,
    p20,
    usable: [p14, p18, p19, p20].filter(Boolean),
    omitted,
  };
}

/**
 * The Key Performance Highlights rows in report priority order.
 *
 * Only the most useful client-facing results are carried into the table, and
 * only when the calculated result is reliable. Rows for excluded parameters
 * (P8, P15, P21) and for internal scores never appear here. A bass consistency
 * row is carried only when it passed the P20 rule, so the table can never
 * carry a weak or provisional consistency result.
 *
 * The Result value is copied from the snapshot; it is never derived here.
 */
export const HIGHLIGHT_PRIORITY = Object.freeze([
  'screen_size',
  'rp23_viewing',
  'system_layout',
  'p2',
  'p4',
  'p5',
  'p7',
  'p9',
  'p12',
  'p13',
  'p14',
  'p18',
  'p19',
  'p20',
  'p16',
  'p17',
  'p6',
  'p10',
]);

/** Maximum number of client-facing highlight rows. */
export const HIGHLIGHT_ROW_LIMIT = 14;

/** Sort a set of candidate highlight rows into report priority order. */
export function orderHighlightRows(rows) {
  const rank = new Map(HIGHLIGHT_PRIORITY.map((key, index) => [key, index]));
  return [...(rows || [])].sort((a, b) => {
    const left = rank.has(a.key) ? rank.get(a.key) : HIGHLIGHT_PRIORITY.length;
    const right = rank.has(b.key) ? rank.get(b.key) : HIGHLIGHT_PRIORITY.length;
    return left - right;
  });
}