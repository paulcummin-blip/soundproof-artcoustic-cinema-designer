/**
 * designIdentityComparison.js  — SERVER MIRROR
 * -------------------------------------------
 * ONE question, answered from two publications of one project version: did the
 * DESIGN change, or only the way it is presented?
 *
 * The engineering fingerprint is a version's design identity, and a design's
 * derived display identity is presentation (see displayTypeAuthority). A report
 * frozen before that rule — or frozen against a publication written while a
 * derived field was still part of the hash — carries a fingerprint the version's
 * pointer has since moved past WITHOUT the design changing. This module
 * recognises exactly that case, from the two publications' own frozen physical
 * facts, so an unchanged design is never reported as out of date.
 *
 * Deliberately conservative: it answers true ONLY when both publications state
 * their frozen report facts and those facts are equal once the derived display
 * identity is removed. A publication that states no frozen facts, or any
 * physical difference at all, answers false — the strict verdict then stands and
 * the report is treated as needing an update.
 *
 * Mirrors src/components/report/designIdentityComparison.js for the server, which
 * cannot import the browser module: the derived-identity key list, the stable
 * serializer and the comparison are stated here in the same words, and a test
 * asserts the two agree. The server needs the same verdict because the proposal
 * gate reads the report evidence here — without it the readiness table could read
 * Current while the generation gate refused the same report as stale.
 *
 * Pure: no React, no network, no recalculation, no engineering value.
 */

import { findPublication } from './publishedEngineeringRead.js';

/**
 * THE derived display identity of a screen: which display it is PRESENTED as.
 * It is resolved from the design's own physical facts, it is presentation only,
 * and it is therefore never part of a design-identity comparison.
 */
export const DERIVED_DISPLAY_IDENTITY_KEYS = Object.freeze([
  'displayType',
  'display_type',
  'displayLabel',
  'display_label',
  'displayPhrase',
  'display_phrase',
]);

/**
 * A screen's facts with its derived display identity removed, at the screen's own
 * top level only. A declared manual display type is the designer's own choice
 * about a physical display and is left exactly as it stands.
 */
export function withoutDerivedDisplayIdentity(screen) {
  if (!screen || typeof screen !== 'object') return screen ?? null;
  // The derived keys are omitted as the facts are rebuilt, so the result is the
  // same object the in-place removal produced: every other own key, in its own
  // order, and no key removal of any kind.
  const derived = new Set(DERIVED_DISPLAY_IDENTITY_KEYS);
  const facts = {};
  for (const [key, value] of Object.entries(screen)) {
    if (!derived.has(key)) facts[key] = value;
  }
  return facts;
}

/**
 * Strip legacy subwoofer UI metadata (placementMode/isManual) that is inert
 * once subwooferInstances exist. Mirrors the client helper in
 * engineeringFingerprint.js so an equivalent design compares equal here too.
 * Accepts both camelCase (design state) and snake_case (frozen report project).
 */
export function stripLegacySubwooferUiMetadata(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return value;
  const stripCfg = (cfg) => {
    if (!cfg || typeof cfg !== 'object' || Array.isArray(cfg)) return cfg;
    const { placementMode, isManual, ...rest } = cfg;
    return rest;
  };
  const out = { ...value };
  if (out.frontSubsCfg) out.frontSubsCfg = stripCfg(out.frontSubsCfg);
  if (out.rearSubsCfg) out.rearSubsCfg = stripCfg(out.rearSubsCfg);
  if (out.front_subs_cfg) out.front_subs_cfg = stripCfg(out.front_subs_cfg);
  if (out.rear_subs_cfg) out.rear_subs_cfg = stripCfg(out.rear_subs_cfg);
  return out;
}

/**
 * Project identity and commercial metadata that live on a frozen report_project
 * but are NOT physical design facts: who the project is for and how it is priced.
 * A spelling correction to the client name, a price-mode toggle or a
 * difficulty-multiplier change must never invalidate an engineering document,
 * because none of these changes the design the document was issued against.
 * Mirrored with src/components/report/designIdentityComparison.js (a parity test
 * agrees).
 */
export const PROJECT_IDENTITY_METADATA_KEYS = Object.freeze([
  'client_name',
  'name',
  'project_reference',
  'version_name',
  'project_id',
  'version_id',
  'price_mode',
  'show_prices',
  'difficulty_multiplier',
]);

export function stripProjectIdentityMetadata(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return value;
  const removed = new Set(PROJECT_IDENTITY_METADATA_KEYS);
  const facts = {};
  for (const [key, v] of Object.entries(value)) {
    if (!removed.has(key)) facts[key] = v;
  }
  return facts;
}

/** Order-independent serialization, so two equal facts compare equal. */
export function stableStringify(value) {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : 'null';
  if (typeof value === 'string') return JSON.stringify(value);
  if (Array.isArray(value)) {
    return '[' + value.map(stableStringify).join(',') + ']';
  }
  if (typeof value === 'object') {
    const keys = Object.keys(value).sort();
    const parts = keys.map((key) => JSON.stringify(key) + ':' + stableStringify(value[key]));
    return '{' + parts.join(',') + '}';
  }
  return 'null';
}

/**
 * The physical design facts a publication froze, with the screen's derived
 * display identity removed. Null when the publication states none, in which case
 * no comparison is possible and the strict verdict must stand.
 */
export function frozenDesignFacts(publication) {
  const raw = publication?.report_snapshot?.report_project;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  if (Object.keys(raw).length === 0) return null;
  // Legacy subwoofer UI metadata (placementMode/isManual) is inert once
  // subwooferInstances exist and is excluded so an equivalent design compares
  // equal — see stripLegacySubwooferUiMetadata. Project identity and commercial
  // metadata (client name, price mode, difficulty multiplier, …) are likewise
  // excluded: a spelling correction or a pricing change is not a design change
  // and must never invalidate an engineering document — see
  // stripProjectIdentityMetadata.
  const project = stripProjectIdentityMetadata(stripLegacySubwooferUiMetadata(raw));
  const screen = project.report_screen;
  if (!screen || typeof screen !== 'object' || Array.isArray(screen)) return project;
  return { ...project, report_screen: withoutDerivedDisplayIdentity(screen) };
}

/** Whether two publications state the same physical design. */
export function samePhysicalDesign(savedPublication, currentPublication) {
  const saved = frozenDesignFacts(savedPublication);
  const current = frozenDesignFacts(currentPublication);
  if (!saved || !current) return false;
  return stableStringify(saved) === stableStringify(current);
}

/**
 * Whether the version's move from a saved publication to its current publication
 * was presentation only. False whenever either side cannot be compared.
 */
export function engineeringDifferenceIsPresentationOnly(savedPublication, currentPublication) {
  if (!savedPublication || !currentPublication) return false;
  return samePhysicalDesign(savedPublication, currentPublication);
}

/** The client-facing display identity one publication actually stated. */
export function frozenDisplayAuthority(publication) {
  const screen = publication?.report_snapshot?.report_project?.report_screen;
  if (!screen || typeof screen !== 'object' || Array.isArray(screen)) return null;
  const value = (camel, snake) => {
    const raw = screen[camel] ?? screen[snake];
    return raw == null ? null : String(raw).trim().toLowerCase();
  };
  const identity = {
    type: value('displayType', 'display_type'),
    label: value('displayLabel', 'display_label'),
    phrase: value('displayPhrase', 'display_phrase'),
  };
  return Object.values(identity).some(Boolean) ? identity : null;
}

/** A wording-only move may reuse proposal evidence; a changed Display authority may not. */
export function proposalEvidenceDifferenceIsSafe(savedPublication, currentPublication) {
  if (!engineeringDifferenceIsPresentationOnly(savedPublication, currentPublication)) return false;
  const savedDisplay = frozenDisplayAuthority(savedPublication);
  const currentDisplay = frozenDisplayAuthority(currentPublication);
  if (!savedDisplay || !currentDisplay) return false;
  return stableStringify(savedDisplay) === stableStringify(currentDisplay);
}

/**
 * The verdict for one version, from its own publication history: did the move
 * from `frozenFingerprint` to `currentFingerprint` change only presentation?
 *
 * False when either fingerprint is unstated or when they are equal (nothing
 * moved), and false when either publication is not held by the record — the
 * strict verdict stands rather than an absent comparison excusing a stale report.
 *
 * @param {Object|null} cacheRecord — the version's ProjectAnalysisCache record
 * @param {{frozenFingerprint?: string|null, currentFingerprint?: string|null}} fingerprints
 */
export function engineeringMoveIsPresentationOnly(cacheRecord, {
  frozenFingerprint = null,
  currentFingerprint = null,
} = {}) {
  if (!frozenFingerprint || !currentFingerprint) return false;
  if (frozenFingerprint === currentFingerprint) return false;
  return engineeringDifferenceIsPresentationOnly(
    findPublication(cacheRecord, frozenFingerprint),
    findPublication(cacheRecord, currentFingerprint),
  );
}

/**
 * Proposal-specific reuse verdict. It is stricter than report restoration:
 * client-facing display identity must also agree, otherwise the saved evidence
 * would let old Screen copy survive into a proposal whose authority now says TV.
 */
export function proposalEvidenceMoveIsSafe(cacheRecord, {
  frozenFingerprint = null,
  currentFingerprint = null,
} = {}) {
  if (!frozenFingerprint || !currentFingerprint) return false;
  if (frozenFingerprint === currentFingerprint) return false;
  return proposalEvidenceDifferenceIsSafe(
    findPublication(cacheRecord, frozenFingerprint),
    findPublication(cacheRecord, currentFingerprint),
  );
}

export default engineeringDifferenceIsPresentationOnly;